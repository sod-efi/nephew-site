# Nephew — your logged-in identity, in any agent sandbox

**The product in one line:** the browser profile lives with the owner and travels
across agent providers, computers and runs — *bring your logged-in identity to any
agent run.*

Nephew is the **profile layer** for the sandbox providers you already use. It
carries one logged-in browser identity — cookies, session state, a coherent
fingerprint, and a pinned egress IP — *into* Modal, Steel, and Browser Use. It is
not another sandbox, and it does not replace them: your jobs still run on your
provider, under your account. Nephew is the identity they run *as*.

Pillars: **Portable · Continuous · Yours.**

## Install

```bash
curl -fsSL https://nephew.ai/install | sh
```

The installer writes exactly two things — the app to `~/.local/lib/nephew` and a
launcher to `~/.local/bin/nephew` — after verifying the download against the
published SHA256SUMS. No sudo. Requires Node.js 22 or newer.

## Quickstart

```bash
nephew init       # 1. connect YOUR OWN provider accounts (skip any you don't use)
nephew capture    # 2. sign in once, in your own local browser → encrypted bundle
nephew run nightly-recon --provider modal     # 3. run anywhere
nephew revoke     #    destroy the bundle, with a signed deletion receipt
```

Budgets on the happy path: under 5 minutes wall clock and under 60 seconds of
human attention from install to first run, excluding the one login you choose
to capture.

### 1. `nephew init` — your accounts, your keys

Walks Modal (token pair — read from your environment or your own
`~/.modal.toml`), Steel (API key), Browser Use (API key), and Bright Data
(API token + the zone your egress is pinned to). Each provider gets one live,
read-only verification call. Skip any provider you don't use — one connected
provider is a working setup.

Keys are read from your environment only. They are never printed and never
stored: `~/.nephew/config.json` (mode 0600) records **references** — which env
var holds each key, the Bright Data customer id + zone, and whether the check
passed. There is no Nephew account and no Nephew cloud in the middle; provider
billing stays yours.

### 2. `nephew capture` — sign in once, in your own browser

Three one-idea steps:

1. **Your logins.** A seeded fingerprint-chromium window opens on your machine.
   Name the profile and its **designated human** — the person a paused run
   routes its handoff to (whoever receives that account's codes today). Log in
   to your sites the way you normally would: password manager, MFA, passkeys,
   all untouched by us. We never see your passwords.
2. **Review.** The inventory: which sites were captured, with cookie/storage
   counts. Remove any site by hostname — what you remove never enters the bundle.
3. **Where it lives.** The session (cookies + per-origin localStorage) is sealed
   into an encrypted bundle **you** hold, under a key **you** hold
   (`PROFILE_ENCRYPTION_KEY` — it never sits with the bundle). The fingerprint
   recipe — seed, user agent, timezone, screen, WebGL — is measured from the
   capture browser and pinned into the bundle, along with the designated human
   and the pinned-egress reference from your Bright Data zone.

### 3. `nephew run` — the same identity, on any provider

```bash
nephew run <job> --provider steel|browseruse|modal [--dry-run] [--bundle <dir>]
```

Every run opens with the three-line trust receipt — whose profile, the
fingerprint it must match, the egress it must come from:

```
profile     modal-proxy-20261030 · owner-held bundle · loaded from your vault
fingerprint 2ef43e20ca · seed 1000 · windows/Chrome
egress      brightdata-zone-isp_proxy3 · pinned
```

The run then measures the live browser in the provider session and checks it
against the recipe. **The fingerprint gate must accept before any state is
released** — on a mismatch the run refuses, rather than logging in as a stranger
device. When the job ends, the live session is captured back into the same
bundle: one identity, no forks.

### `nephew revoke`

```bash
nephew revoke [--bundle <dir>] [--key-file <file>] [--receipt <file>]
```

Destroys the bundle (and key material you explicitly name) and leaves an
Ed25519-signed deletion receipt you can verify independently. Demonstrated:
a throwaway bundle revoked in 289 ms, receipt verified from a separate process.

## Surfaces

- **CLI** — `nephew init / capture / run / revoke`, above.
- **MCP** — `nephew mcp` serves one tool on stdio:

  ```json
  { "tool": "profile_run",
    "args": { "job": "nightly-recon", "provider": "steel", "bundle": "/path/to/bundle" } }
  ```

  Same receipt + gate as the CLI (one shared run core). The calling model never
  sees a cookie or the bundle. A run whose carried login doesn't hold returns a
  structured **`LOGIN_REQUIRED`** pause result — status, profile, and the
  designated human — not an error.
- **TypeScript helper** — `withProfile(bundleDir, provider, fn)` in
  `src/with-profile.ts`: opens the session, gates, restores, verifies, hands
  your function the live CDP page session, then captures back. Steel +
  Browser Use only — Modal's driver runs inside its sandbox and exposes no
  host-side CDP handle, so Modal goes through `nephew run` (the limit is
  documented in the file, not papered over).

## Measured proof (runs/ has the record for every number)

- **Steel baseline:** bundle state restored + verified in a fresh session,
  0 login prompts, 0 MFA prompts, 6,366 ms.
- **Browser Use baseline:** same bundle shape, same result — 0 prompts, 7,815 ms.
- **Modal, two environments:** the same profile measured on this machine and
  inside a Modal sandbox produced **identical fingerprints — all 10 measured
  elements, canvas included** — with the pinned font pack in both environments.
- **Pinned egress in Modal:** a run egressed from exactly **91.108.223.136** —
  the profile's own dedicated Bright Data IP — gate accepted, session restored,
  0 prompts.
- **Full Modal runs:** 10–27 s in-session across the proof runs.
- **Install:** the `curl | sh` flow was exercised end-to-end against a clean
  HOME (locally served payload): install, `nephew --help`, and a Modal dry run
  all pass (`packaging/PROOF-2026-10-30.md`).
- **Managed-cloud drift, stated plainly:** in Steel and Browser Use the
  recipe-pinned elements (user agent, timezone, screen) hold; computed elements
  (canvas, WebGL, audio, fonts) drift — those providers offer no seed/binary
  controls. The gate pins what the provider can hold; the own-stack track
  (fingerprint-chromium on Modal) is where the full fingerprint holds.

## Plain limits

- **A site can still challenge a run.** When it does, the run pauses with
  `LOGIN_REQUIRED`, the designated human completes a short handoff, and the
  cleared session captures back into the same bundle. The promise is not zero
  human touches forever — it is that a rare challenge costs a short handoff,
  not a babysat login flow.
- **One dedicated IP per identity.** That pinning is the product, and it is
  per-profile by design.
- **No "works on every site" claims.** Above are the runs actually measured;
  every run writes its own metrics record in `runs/`, measured the same way.
- **Browserbase: not yet.** The CDP pattern is the same in principle; it is
  unconnected and untested.
- Proof status: the baselines, the Modal runs, pinned egress, and the install
  path are proved. One owner-designated real-account workload is still being
  proven (the Amazon gate test in `runs/`) — `runs/VERDICT.md` stays DRAFT
  until it resolves.

## Access

Nephew is in **private beta**. There is no public pricing yet — beta users
bring their own provider accounts and pay their providers directly.

## For builders picking this up cold

1. `MISSION.md` — the assignment, with a checkable DONE MEANS end state.
2. `AGENTS.md` — working rules for any agent building in this folder.
3. `docs/ARCHITECTURE.md` — components, provider adapters, profile format.
4. `docs/SECURITY_REVIEW.md` — read before touching profile data. Profiles hold
   session tokens = account access; the controls there are requirements.
5. `docs/TEST_PLAN.md` — the proof runs, measures, and the pre-committed kill
   criterion.
6. `docs/FINGERPRINT_RESEARCH_FINDINGS.md` — the fingerprint split into 3
   layers, and why the moat needs a browser build we control (own-stack),
   with the managed clouds as measured baselines.
7. `../2026-10-29-browser-profile-priority.json` — the decision record this
   scaffold implements. If this scaffold and that file disagree, that file
   wins until the owner changes it.
8. `memory.md` — durable build notes, failures included, newest first.

## Layout

```
bin/nephew.js           the installed CLI shim
src/nephew.ts           CLI dispatch
src/cli/args.ts         argument parsing (pure)
src/cli/config.ts       ~/.nephew/config.json — references only, mode 0600
src/cli/init.ts         nephew init — BYO credential checks (read-only)
src/cli/capture.ts      nephew capture — local-browser capture, 3 steps
src/cli/run-core.ts     the one run path behind CLI + MCP
src/cli/receipt.ts      the 3-line trust receipt + fingerprint gate
src/cli/run-baseline.ts steel / browseruse sessions (openers + baselines)
src/cli/run-modal.ts    modal runner (driver co-located in the sandbox)
src/cli/revoke.ts       signed deletion receipts
src/mcp/server.ts       MCP server: profile_run
src/with-profile.ts     TS helper: withProfile(bundle, provider, fn)
src/profile-store.ts    the owner-held encrypted bundle
src/state.ts            Layer 1 capture/restore (cookies + localStorage)
src/fingerprint.ts      fingerprint probe + diff (one probe everywhere)
src/providers/          provider adapters (own-stack = the moat track)
tools/modal_bridge.py   Modal SDK bridge (create / run / terminate / check)
tools/modal_driver.py   in-sandbox CDP driver
test/                   unit tests (npm test) — offline, providers faked
runs/                   one metrics record per run
packaging/              deterministic release + install.sh + site payload
```

## Development

```bash
npm ci
npm run typecheck
npm test
```

Secrets for development arrive via environment variables only — see
`.env.example`. Never commit a key, a cookie value, or a zone password.

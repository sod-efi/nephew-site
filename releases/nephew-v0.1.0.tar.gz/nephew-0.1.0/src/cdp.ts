/**
 * cdp — a minimal Chrome DevTools Protocol client over Node's built-in
 * WebSocket, plus a Chromium launcher. No dependencies: the adapters and the
 * proof scripts speak CDP directly, the way the spikes did.
 */
import { spawn, type ChildProcess } from "node:child_process";
import { setTimeout as sleep } from "node:timers/promises";

/**
 * Default ceiling for any single CDP call. A dropped connection (the Bright
 * Data relay has dropped one in every Amazon run so far) otherwise leaves
 * the reply promise pending forever and the caller hangs silently. No caller
 * may wait longer than this unless it explicitly passes a larger timeout.
 */
export const CDP_DEFAULT_TIMEOUT_MS = 30_000;

export class CdpTimeoutError extends Error {
  constructor(method: string, timeoutMs: number) {
    super(`CDP ${method} timed out after ${timeoutMs} ms`);
    this.name = "CdpTimeoutError";
  }
}

/**
 * A CDP event subscriber (Fetch.requestPaused, Page.loadEventFired, …).
 * Events are the messages WITHOUT an id: { method, params, sessionId? }.
 */
export type CdpEventHandler = (params: any, sessionId?: string) => void;

interface PendingCall {
  resolve: (msg: any) => void;
  reject: (err: Error) => void;
  timer: ReturnType<typeof setTimeout>;
}

export class CdpClient {
  private ws: WebSocket;
  private nextId = 0;
  private pending = new Map<number, PendingCall>();
  private eventHandlers = new Map<string, Set<CdpEventHandler>>();

  // Public so tests can inject a fake transport; production code uses connect().
  constructor(ws: WebSocket) {
    this.ws = ws;
    ws.onmessage = (ev: any) => {
      const msg = JSON.parse(typeof ev.data === "string" ? ev.data : ev.data.toString());
      if (msg.method) {
        // An event, not a call reply. Handlers must never break routing:
        // their exceptions are swallowed here (a handler that cares about
        // its own failures probes/records them itself).
        const handlers = this.eventHandlers.get(msg.method);
        if (handlers) {
          for (const handler of handlers) {
            try { handler(msg.params ?? {}, msg.sessionId); } catch { /* see above */ }
          }
        }
      }
      if (msg.id && this.pending.has(msg.id)) {
        const call = this.pending.get(msg.id)!;
        this.pending.delete(msg.id);
        clearTimeout(call.timer);
        call.resolve(msg);
      }
    };
  }

  /**
   * Subscribe to a CDP event (e.g. "Fetch.requestPaused"). Returns an
   * unsubscribe function. Events arrive on the same websocket as call
   * replies; with flatten-mode sessions they carry the emitting session's
   * id, which is passed to the handler.
   */
  onEvent(method: string, handler: CdpEventHandler): () => void {
    let set = this.eventHandlers.get(method);
    if (!set) {
      set = new Set();
      this.eventHandlers.set(method, set);
    }
    set.add(handler);
    return () => { set.delete(handler); };
  }

  static async connect(wsUrl: string): Promise<CdpClient> {
    const ws = new WebSocket(wsUrl);
    await new Promise<void>((resolve, reject) => {
      ws.onopen = () => resolve();
      ws.onerror = (e: any) => reject(new Error("CDP websocket error: " + (e?.message ?? e)));
    });
    return new CdpClient(ws);
  }

  async send(
    method: string,
    params: Record<string, unknown> = {},
    sessionId?: string,
    timeoutMs: number = CDP_DEFAULT_TIMEOUT_MS,
  ): Promise<any> {
    const id = ++this.nextId;
    const reply = new Promise<any>((resolve, reject) => {
      const timer = setTimeout(() => {
        this.pending.delete(id);
        reject(new CdpTimeoutError(method, timeoutMs));
      }, timeoutMs);
      this.pending.set(id, { resolve, reject, timer });
    });
    try {
      this.ws.send(JSON.stringify({ id, method, params, ...(sessionId ? { sessionId } : {}) }));
    } catch (e) {
      const call = this.pending.get(id);
      if (call) {
        clearTimeout(call.timer);
        this.pending.delete(id);
      }
      throw e;
    }
    const msg = await reply;
    if (msg.error) throw new Error(`CDP ${method} failed: ${JSON.stringify(msg.error)}`);
    return msg.result;
  }

  /** Attach to the first page target and return its sessionId. */
  async attachToFirstPage(port: number): Promise<string> {
    const targets = await (await fetch(`http://127.0.0.1:${port}/json/list`)).json();
    const page = targets.find((t: any) => t.type === "page") ?? targets[0];
    const { sessionId } = await this.send("Target.attachToTarget", { targetId: page.id, flatten: true });
    return sessionId as string;
  }

  async evaluate<T>(sessionId: string, expression: string, timeoutMs: number = CDP_DEFAULT_TIMEOUT_MS): Promise<T> {
    const r = await this.send(
      "Runtime.evaluate",
      { expression, returnByValue: true, awaitPromise: true },
      sessionId,
      timeoutMs,
    );
    if (r.exceptionDetails) {
      throw new Error("evaluate failed: " + JSON.stringify(r.exceptionDetails).slice(0, 300));
    }
    return r.result?.value as T;
  }

  close(): void {
    // Fail anything still in flight rather than leaving it to the timeout.
    for (const call of this.pending.values()) {
      clearTimeout(call.timer);
      call.reject(new Error("CDP connection closed"));
    }
    this.pending.clear();
    try { this.ws.close(); } catch { /* already closed */ }
  }
}

export interface LaunchedBrowser {
  process: ChildProcess;
  port: number;
  wsUrl: string;
  cdp: CdpClient;
  sessionId: string;
  close(): Promise<void>;
}

export async function launchChromium(
  exe: string,
  args: string[],
  port: number,
): Promise<LaunchedBrowser> {
  const proc = spawn(exe, [
    ...args,
    `--remote-debugging-port=${port}`,
    "--remote-debugging-address=127.0.0.1",
    "about:blank",
  ], { stdio: "ignore" });

  let wsUrl = "";
  for (let i = 0; i < 60 && !wsUrl; i++) {
    try {
      const r = await fetch(`http://127.0.0.1:${port}/json/version`);
      wsUrl = (await r.json()).webSocketDebuggerUrl;
    } catch { await sleep(500); }
  }
  if (!wsUrl) {
    proc.kill("SIGKILL");
    throw new Error(`Chromium did not open a CDP endpoint on port ${port}`);
  }
  const cdp = await CdpClient.connect(wsUrl);
  const sessionId = await cdp.attachToFirstPage(port);
  await cdp.send("Page.enable", {}, sessionId);
  await cdp.send("Runtime.enable", {}, sessionId);
  return {
    process: proc, port, wsUrl, cdp, sessionId,
    async close() {
      cdp.close();
      proc.kill("SIGKILL");
    },
  };
}

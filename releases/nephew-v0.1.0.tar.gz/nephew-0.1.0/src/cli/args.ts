/**
 * cli/args — argument parsing for the `nephew` CLI. Pure and unit-tested:
 * no I/O, no env reads except through the injected env map in
 * modalConnectionProblem(). The command surface is the owner's decision
 * (../2026-10-29-nephew-cli-decision.md): `nephew run` is the product.
 */

export type ProviderName = "steel" | "browseruse" | "modal";

export const PROVIDERS: readonly ProviderName[] = ["steel", "browseruse", "modal"];

export interface RunCommand {
  command: "run";
  job: string;
  provider: ProviderName;
  dryRun: boolean;
  bundleDir?: string;
}

export interface RevokeCommand {
  command: "revoke";
  bundleDir?: string;
  /** Extra copy of the signed deletion receipt to write. */
  receiptFile?: string;
  /** Key-material file to destroy together with the bundle (owner-named only). */
  keyFile?: string;
}

export interface InitCommand {
  command: "init";
}

export interface CaptureCommand {
  command: "capture";
  bundleDir?: string;
  /** Profile id (also the default bundle directory name). */
  name?: string;
  /** The profile's designated human — who a paused run calls on. */
  human?: string;
  /** Extra origins to capture localStorage for, beyond the open pages. */
  sites: string[];
  /** Fingerprint seed for the new profile (default: freshly drawn). */
  seed?: number;
}

export interface McpCommand {
  command: "mcp";
}

export type HelpTopic = "run" | "revoke" | "init" | "capture" | "mcp";

export interface HelpCommand {
  command: "help";
  topic?: HelpTopic;
}

export type CliCommand = RunCommand | RevokeCommand | InitCommand | CaptureCommand | McpCommand | HelpCommand;

export type ParseResult =
  | { ok: true; value: CliCommand }
  | { ok: false; error: string };

export const USAGE = `nephew — run agent jobs with your own portable browser profile

usage:
  nephew init [--help]                       connect your own provider accounts
  nephew capture [--name <id>] [--human <who>] [--bundle <dir>]
  nephew run <job> --provider steel|browseruse|modal [--dry-run] [--bundle <dir>]
  nephew revoke [--bundle <dir>] [--key-file <file>] [--receipt <file>]
  nephew mcp                                 MCP server (stdio) exposing profile_run
  nephew <command> --help
  nephew --help

providers:
  steel       Steel Cloud (proven baseline: bundle state restore)
  browseruse  Browser Use Cloud (proven baseline: bundle state restore)
  modal       Modal Sandbox, own-stack Chromium — needs MODAL_TOKEN_ID + MODAL_TOKEN_SECRET

options:
  --provider <name>  provider to run on (default: steel)
  --bundle <dir>     owner-held bundle directory
                     (default: $NEPHEW_BUNDLE_DIR, else ~/workspace/profile-proof-runs/default/bundle)
  --dry-run          print the trust receipt + run plan; create no session

env:
  PROFILE_ENCRYPTION_KEY  bundle decryption key (capture + live runs)
  MODAL_TOKEN_ID / MODAL_TOKEN_SECRET  Modal connection (provider: modal)
  STEEL_API_KEY / BROWSER_USE_API_KEY / BRIGHTDATA_API_KEY  provider keys (nephew init checks them)`;

export const RUN_USAGE = `usage: nephew run <job> --provider steel|browseruse|modal [--dry-run] [--bundle <dir>]

  <job>              job name (labels the run + its metrics record)
  --provider <name>  steel | browseruse | modal (default: steel)
  --bundle <dir>     owner-held bundle directory
  --dry-run          print the trust receipt + run plan; create no session`;

export const REVOKE_USAGE = `usage: nephew revoke [--bundle <dir>] [--key-file <file>] [--receipt <file>]

  Destroy the owner-held bundle and issue a signed deletion receipt
  (written next to the bundle as <bundle>.deletion-receipt.json).
  One command is the confirmation — there is no undo.

  --bundle <dir>     owner-held bundle directory
                     (default: $NEPHEW_BUNDLE_DIR, else ~/workspace/profile-proof-runs/default/bundle)
  --key-file <file>  key-material file to destroy together with the bundle
                     (only a file you name here is ever deleted)
  --receipt <file>   also write a copy of the signed deletion receipt here

env:
  NEPHEW_RECEIPT_SIGNING_KEY_FILE  owner receipt-signing key file
                     (default: ~/.nephew/receipt-signing-key.json)`;

export const INIT_USAGE = `usage: nephew init

  Connect YOUR OWN provider accounts, one at a time (skip any you don't
  use): Modal (token pair — env or your ~/.modal.toml), Steel (API key),
  Browser Use (API key), Bright Data (API token + the zone your profile's
  egress is pinned to). Each is verified with one live read-only call.

  Keys are read from your environment only and are never printed or
  stored. ~/.nephew/config.json (mode 0600) records references — which
  env var holds each key, the Bright Data customer id + zone, and whether
  the check passed.

env:
  MODAL_TOKEN_ID / MODAL_TOKEN_SECRET, STEEL_API_KEY,
  BROWSER_USE_API_KEY, BRIGHTDATA_API_KEY
  NEPHEW_CONFIG  config path (default: ~/.nephew/config.json)`;

export const CAPTURE_USAGE = `usage: nephew capture [--name <id>] [--human <who>] [--bundle <dir>] [--sites <url,url>] [--seed <n>]

  Capture a profile in your own local browser: a seeded
  fingerprint-chromium window opens, you log in to your sites normally,
  and on your confirmation the session (cookies + per-origin
  localStorage) is sealed into a NEW encrypted owner-held bundle.

  --name <id>        profile id (default: asked; bundle lands in
                     ~/.nephew/profiles/<id> unless --bundle says otherwise)
  --human <who>      the profile's designated human — the person a paused
                     run routes its LOGIN_REQUIRED handoff to
  --bundle <dir>     bundle directory to create (must not already exist)
  --sites <url,url>  extra origins to capture, beyond the pages you open
  --seed <n>         fingerprint seed (default: freshly drawn per profile)

env:
  PROFILE_ENCRYPTION_KEY  bundle encryption key (required — yours, never
                     stored with the bundle)
  OWN_STACK_CHROME_PATH   the fingerprint-chromium binary to open`;

export const MCP_USAGE = `usage: nephew mcp

  Run the Nephew MCP server on stdio. One tool:

    profile_run { job, provider: steel|browseruse|modal, bundle? }

  Same trust receipt + fingerprint gate as "nephew run". A run whose
  carried login does not hold comes back as a structured LOGIN_REQUIRED
  pause result (not an error), naming the profile's designated human.`;

/** Split "--flag=value" and "--flag value" forms uniformly. */
function flagValue(argv: string[], i: number, flag: string): { value?: string; consumed: number } {
  const a = argv[i];
  if (a === flag) return { value: argv[i + 1], consumed: argv[i + 1] !== undefined ? 2 : 1 };
  if (a.startsWith(flag + "=")) return { value: a.slice(flag.length + 1), consumed: 1 };
  return { consumed: 0 };
}

export function parseCliArgs(argv: string[]): ParseResult {
  const [first, ...rest] = argv;
  if (first === undefined || first === "--help" || first === "-h" || first === "help") {
    return { ok: true, value: { command: "help" } };
  }
  if (first === "revoke") {
    if (rest.includes("--help") || rest.includes("-h")) {
      return { ok: true, value: { command: "help", topic: "revoke" } };
    }
    let bundleDir: string | undefined;
    let receiptFile: string | undefined;
    let keyFile: string | undefined;
    for (let i = 0; i < rest.length; i++) {
      const a = rest[i];
      const target = a === "--bundle" || a.startsWith("--bundle=")
        ? "--bundle"
        : a === "--receipt" || a.startsWith("--receipt=")
          ? "--receipt"
          : a === "--key-file" || a.startsWith("--key-file=")
            ? "--key-file"
            : null;
      if (target) {
        const { value, consumed } = flagValue(rest, i, target);
        i += consumed - 1;
        if (!value) return { ok: false, error: `${target} needs a value` };
        if (target === "--bundle") bundleDir = value;
        else if (target === "--receipt") receiptFile = value;
        else keyFile = value;
      } else {
        return { ok: false, error: `unknown option "${a}" for revoke` };
      }
    }
    return { ok: true, value: { command: "revoke", bundleDir, receiptFile, keyFile } };
  }
  if (first === "init" || first === "mcp") {
    if (rest.includes("--help") || rest.includes("-h")) {
      return { ok: true, value: { command: "help", topic: first } };
    }
    if (rest.length > 0) return { ok: false, error: `unknown option "${rest[0]}" for ${first}` };
    return { ok: true, value: { command: first } };
  }
  if (first === "capture") {
    if (rest.includes("--help") || rest.includes("-h")) {
      return { ok: true, value: { command: "help", topic: "capture" } };
    }
    let bundleDir: string | undefined;
    let name: string | undefined;
    let human: string | undefined;
    let sites: string[] = [];
    let seed: number | undefined;
    for (let i = 0; i < rest.length; i++) {
      const a = rest[i];
      const target = ["--bundle", "--name", "--human", "--sites", "--seed"].find(
        (f) => a === f || a.startsWith(f + "="),
      );
      if (!target) return { ok: false, error: `unknown option "${a}" for capture` };
      const { value, consumed } = flagValue(rest, i, target);
      i += consumed - 1;
      if (!value) return { ok: false, error: `${target} needs a value` };
      if (target === "--bundle") bundleDir = value;
      else if (target === "--name") name = value;
      else if (target === "--human") human = value;
      else if (target === "--sites") sites = value.split(",").map((s) => s.trim()).filter(Boolean);
      else {
        seed = Number(value);
        if (!Number.isInteger(seed) || seed < 0) return { ok: false, error: `--seed needs a non-negative integer, got "${value}"` };
      }
    }
    return { ok: true, value: { command: "capture", bundleDir, name, human, sites, seed } };
  }
  if (first !== "run") {
    return { ok: false, error: `unknown command "${first}"` };
  }
  if (rest.includes("--help") || rest.includes("-h")) {
    return { ok: true, value: { command: "help", topic: "run" } };
  }

  let job: string | undefined;
  let provider: ProviderName = "steel";
  let dryRun = false;
  let bundleDir: string | undefined;

  for (let i = 0; i < rest.length; i++) {
    const a = rest[i];
    if (a === "--dry-run") {
      dryRun = true;
    } else if (a === "--provider" || a.startsWith("--provider=")) {
      const { value, consumed } = flagValue(rest, i, "--provider");
      i += consumed - 1;
      if (!value) return { ok: false, error: "--provider needs a value (steel|browseruse|modal)" };
      if (!(PROVIDERS as readonly string[]).includes(value)) {
        return { ok: false, error: `unknown provider "${value}" (expected steel|browseruse|modal)` };
      }
      provider = value as ProviderName;
    } else if (a === "--bundle" || a.startsWith("--bundle=")) {
      const { value, consumed } = flagValue(rest, i, "--bundle");
      i += consumed - 1;
      if (!value) return { ok: false, error: "--bundle needs a directory value" };
      bundleDir = value;
    } else if (a.startsWith("--")) {
      return { ok: false, error: `unknown option "${a}"` };
    } else if (job === undefined) {
      job = a;
    } else {
      return { ok: false, error: `unexpected extra argument "${a}"` };
    }
  }

  if (job === undefined) {
    return { ok: false, error: "missing <job> — usage: nephew run <job> --provider steel|browseruse|modal" };
  }
  return { ok: true, value: { command: "run", job, provider, dryRun, bundleDir } };
}

/**
 * The Modal connection gate (CLI v0): Modal is env-supplied only — a token
 * pair, one secret per variable. Returns the single line to print when the
 * connection is absent, or null when both halves are present. Never logs
 * values, only names.
 */
export function modalConnectionProblem(env: NodeJS.ProcessEnv): string | null {
  if (env.MODAL_TOKEN_ID && env.MODAL_TOKEN_SECRET) return null;
  return "modal is not connected — set MODAL_TOKEN_ID and MODAL_TOKEN_SECRET in the environment and retry";
}

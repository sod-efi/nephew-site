/**
 * cli/config — the customer's own Nephew config file (~/.nephew/config.json).
 *
 * What lives here: REFERENCES and non-secret facts only — which environment
 * variable holds each provider key on this machine, where a Modal config was
 * found, a Bright Data customer id + zone name, and whether the last live
 * check passed. Secret VALUES never enter this file (AGENTS.md #3,
 * docs/SECURITY_REVIEW.md rule 7): keys stay in the customer's environment /
 * provider config, exactly as `nephew run` already reads them.
 *
 * The file is still written mode 0600: it maps a customer's accounts and
 * profile layout, and 0600 is the house pattern for anything under ~/.nephew
 * (the receipt-signing key file is 0600 for the same reason).
 */
import { chmod, mkdir, readFile, writeFile } from "node:fs/promises";
import { homedir } from "node:os";
import { dirname, join } from "node:path";

export interface ProviderRef {
  /** Name of the environment variable that holds the key on this machine. */
  secretEnv?: string;
  /** Second env var name for a credential pair (Modal). */
  secretEnv2?: string;
  /** Where the credential was found at init time. */
  source: "env" | "modal-config" | "unset";
  /** Did the live read-only check pass at init time? */
  verified: boolean;
  /** ISO timestamp of that check (absent when never checked). */
  checkedAt?: string;
  /** Bright Data: the account's customer id (non-secret; appears in proxy usernames). */
  customerId?: string;
  /** Bright Data: the zone the profile's egress is pinned to (non-secret name). */
  zone?: string;
}

export interface NephewConfig {
  version: 1;
  createdAt: string;
  updatedAt: string;
  providers: {
    modal?: ProviderRef;
    steel?: ProviderRef;
    browseruse?: ProviderRef;
    brightdata?: ProviderRef;
  };
  /** Default bundle directory for run/capture when --bundle is not given. */
  defaultBundleDir?: string;
}

export function nephewConfigPath(env: NodeJS.ProcessEnv = process.env): string {
  return env.NEPHEW_CONFIG ?? join(homedir(), ".nephew", "config.json");
}

export function emptyConfig(now = new Date()): NephewConfig {
  return { version: 1, createdAt: now.toISOString(), updatedAt: now.toISOString(), providers: {} };
}

export async function loadNephewConfig(path: string): Promise<NephewConfig | null> {
  try {
    const parsed = JSON.parse(await readFile(path, "utf8")) as NephewConfig;
    if (parsed?.version !== 1 || typeof parsed.providers !== "object" || parsed.providers === null) {
      return null;
    }
    return parsed;
  } catch {
    return null;
  }
}

/** Write the config mode 0600 — including tightening a pre-existing looser file. */
export async function saveNephewConfig(path: string, config: NephewConfig): Promise<void> {
  await mkdir(dirname(path), { recursive: true });
  await writeFile(path, JSON.stringify(config, null, 2) + "\n", { mode: 0o600 });
  await chmod(path, 0o600);
}

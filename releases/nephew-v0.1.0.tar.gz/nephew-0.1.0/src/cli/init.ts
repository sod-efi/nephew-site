/**
 * cli/init — `nephew init`: connect the customer's OWN provider accounts.
 *
 * Nephew is BYO-account end to end (no Nephew cloud, no Nephew-held keys):
 * this walk takes each provider in turn, finds the credential where the
 * customer already keeps it — environment variables, or Modal's own config
 * file — verifies it with ONE live read-only call, and records only the
 * REFERENCE in ~/.nephew/config.json (cli/config.ts). Secret values are
 * read in-process for the check and never printed, logged, or written.
 *
 * The checks (all read-only, all measured against the real APIs):
 *   modal       bridge `check` action — authenticated App.lookup via the
 *               Modal SDK, which reads MODAL_TOKEN_ID/MODAL_TOKEN_SECRET
 *               or ~/.modal.toml natively (tools/modal_bridge.py).
 *   steel       GET https://api.steel.dev/v1/sessions, `steel-api-key` header.
 *   browseruse  GET https://api.browser-use.com/api/v2/browsers,
 *               `X-Browser-Use-API-Key` header.
 *   brightdata  GET https://api.brightdata.com/status (Bearer) → customer id,
 *               then GET /zone?zone=<zone> for the pinned-IP zone. The zone
 *               response carries the zone password list — it is used for
 *               its status code ONLY and never read into output.
 *
 * Any provider may be skipped: one connected provider is a working setup.
 */
import { spawn } from "node:child_process";
import { readFile } from "node:fs/promises";
import { homedir } from "node:os";
import { join } from "node:path";
import {
  emptyConfig, loadNephewConfig, nephewConfigPath, saveNephewConfig,
  type NephewConfig, type ProviderRef,
} from "./config.ts";
import { modalBridgePath, modalPythonPath } from "./run-modal.ts";

export type InitProvider = "modal" | "steel" | "browseruse" | "brightdata";
export type InitStatus = "connected" | "failed" | "skipped";

export interface ProviderInitResult {
  provider: InitProvider;
  status: InitStatus;
  /** One plain line: what was checked / why not. Never contains a secret. */
  detail: string;
}

export interface InitIo {
  out: (line: string) => void;
  err: (line: string) => void;
  ask: (question: string) => Promise<string>;
}

type FetchFn = (url: string, init?: { headers?: Record<string, string> }) => Promise<{ ok: boolean; status: number; json: () => Promise<any> }>;

export interface InitDeps {
  env?: NodeJS.ProcessEnv;
  configPath?: string;
  home?: string;
  fetchFn?: FetchFn;
  /** Modal bridge check; default spawns tools/modal_bridge.py {action:"check"}. */
  modalCheck?: (env: NodeJS.ProcessEnv) => Promise<{ ok: boolean; detail: string }>;
  now?: () => Date;
}

// ------------------------------------------------------------ live checks

export async function checkSteel(apiKey: string, fetchFn: FetchFn = fetch as FetchFn): Promise<{ ok: boolean; detail: string }> {
  try {
    const r = await fetchFn("https://api.steel.dev/v1/sessions", { headers: { "steel-api-key": apiKey } });
    return r.ok
      ? { ok: true, detail: "GET /v1/sessions answered 200" }
      : { ok: false, detail: `GET /v1/sessions answered HTTP ${r.status} — check the key in your Steel dashboard` };
  } catch {
    return { ok: false, detail: "api.steel.dev unreachable from this machine" };
  }
}

export async function checkBrowserUse(apiKey: string, fetchFn: FetchFn = fetch as FetchFn): Promise<{ ok: boolean; detail: string }> {
  try {
    const r = await fetchFn("https://api.browser-use.com/api/v2/browsers", { headers: { "X-Browser-Use-API-Key": apiKey } });
    return r.ok
      ? { ok: true, detail: "GET /api/v2/browsers answered 200" }
      : { ok: false, detail: `GET /api/v2/browsers answered HTTP ${r.status} — check the key at cloud.browser-use.com/settings` };
  } catch {
    return { ok: false, detail: "api.browser-use.com unreachable from this machine" };
  }
}

export async function checkBrightData(
  apiKey: string,
  zone: string,
  fetchFn: FetchFn = fetch as FetchFn,
): Promise<{ ok: boolean; detail: string; customerId?: string }> {
  const headers = { Authorization: `Bearer ${apiKey}` };
  try {
    const status = await fetchFn("https://api.brightdata.com/status", { headers });
    if (!status.ok) {
      return { ok: false, detail: `GET /status answered HTTP ${status.status} — check your Bright Data API token` };
    }
    const body: any = await status.json().catch(() => null);
    const customerId = typeof body?.customer === "string" ? body.customer : undefined;
    // Status only — the zone body lists zone passwords and is never read.
    const zoneRes = await fetchFn(`https://api.brightdata.com/zone?zone=${encodeURIComponent(zone)}`, { headers });
    if (!zoneRes.ok) {
      return { ok: false, detail: `zone "${zone}" read answered HTTP ${zoneRes.status} — check the zone name in your Bright Data dashboard`, customerId };
    }
    return { ok: true, detail: `zone "${zone}" found; egress username will be brd-customer-${customerId ?? "<customer>"}-zone-${zone}`, customerId };
  } catch {
    return { ok: false, detail: "api.brightdata.com unreachable from this machine" };
  }
}

/** Default Modal check: the bridge's read-only `check` action (see tools/modal_bridge.py). */
export function spawnModalCheck(env: NodeJS.ProcessEnv): Promise<{ ok: boolean; detail: string }> {
  return new Promise((resolve) => {
    const child = spawn(modalPythonPath(env), [modalBridgePath(env)], { stdio: ["pipe", "pipe", "pipe"], env });
    let stdout = "";
    child.stdout.on("data", (d) => { stdout += d; });
    child.on("error", () => resolve({ ok: false, detail: "modal bridge could not start (is the Modal SDK installed?)" }));
    child.on("close", () => {
      try {
        const res = JSON.parse(stdout.trim().split("\n").filter(Boolean).pop() ?? "");
        resolve(res.ok
          ? { ok: true, detail: String(res.detail ?? "token pair authenticated") }
          : { ok: false, detail: `token pair rejected (${String(res.error ?? "unknown error")})` });
      } catch {
        resolve({ ok: false, detail: "modal bridge produced no readable result" });
      }
    });
    child.stdin.end(JSON.stringify({ action: "check" }));
  });
}

/**
 * Does the customer's own Modal config hold a token pair? Presence only —
 * the values are never read out of the file by this code; the SDK reads
 * them itself when the bridge runs.
 */
export async function modalConfigHasPair(home: string): Promise<boolean> {
  try {
    const text = await readFile(join(home, ".modal.toml"), "utf8");
    return /token_id\s*=/.test(text) && /token_secret\s*=/.test(text);
  } catch {
    return false;
  }
}

// ---------------------------------------------------------------- the walk

async function wantsSetup(io: InitIo, label: string): Promise<boolean> {
  const answer = (await io.ask(`Connect ${label}? [Y/n] `)).trim().toLowerCase();
  return answer === "" || answer === "y" || answer === "yes";
}

export interface InitOutcome {
  code: number;
  results: ProviderInitResult[];
  config: NephewConfig;
  configPath: string;
}

export async function runInit(io: InitIo, deps: InitDeps = {}): Promise<InitOutcome> {
  const env = deps.env ?? process.env;
  const home = deps.home ?? homedir();
  const fetchFn = deps.fetchFn ?? (fetch as FetchFn);
  const modalCheck = deps.modalCheck ?? spawnModalCheck;
  const now = deps.now ?? (() => new Date());
  const configPath = deps.configPath ?? nephewConfigPath(env);
  const config = (await loadNephewConfig(configPath)) ?? emptyConfig(now());
  const results: ProviderInitResult[] = [];
  const stamp = () => now().toISOString();

  io.out("nephew init — connect your own provider accounts. Keys stay in your");
  io.out("environment / provider config; this writes references only, to");
  io.out(`${configPath} (mode 0600). Skip any provider you don't use.`);

  // ---- Modal (token pair: env, or Modal's own ~/.modal.toml) ----
  if (!(await wantsSetup(io, "Modal (your token pair runs the own-stack sandbox)"))) {
    results.push({ provider: "modal", status: "skipped", detail: "skipped — runs on steel/browseruse don't need it" });
  } else {
    const fromEnv = Boolean(env.MODAL_TOKEN_ID && env.MODAL_TOKEN_SECRET);
    const fromConfig = fromEnv ? false : await modalConfigHasPair(home);
    if (!fromEnv && !fromConfig) {
      config.providers.modal = { secretEnv: "MODAL_TOKEN_ID", secretEnv2: "MODAL_TOKEN_SECRET", source: "unset", verified: false };
      results.push({
        provider: "modal", status: "failed",
        detail: "no token pair found — run `modal token new`, or set MODAL_TOKEN_ID + MODAL_TOKEN_SECRET, then re-run nephew init",
      });
    } else {
      const check = await modalCheck(env);
      config.providers.modal = {
        secretEnv: "MODAL_TOKEN_ID", secretEnv2: "MODAL_TOKEN_SECRET",
        source: fromEnv ? "env" : "modal-config", verified: check.ok, checkedAt: stamp(),
      };
      results.push({ provider: "modal", status: check.ok ? "connected" : "failed", detail: check.detail });
    }
  }

  // ---- Steel (API key in env) ----
  if (!(await wantsSetup(io, "Steel (API key from your Steel dashboard)"))) {
    results.push({ provider: "steel", status: "skipped", detail: "skipped" });
  } else if (!env.STEEL_API_KEY) {
    config.providers.steel = { secretEnv: "STEEL_API_KEY", source: "unset", verified: false };
    results.push({ provider: "steel", status: "failed", detail: "STEEL_API_KEY is not set — export it (dashboard → Settings → API Keys) and re-run nephew init" });
  } else {
    const check = await checkSteel(env.STEEL_API_KEY, fetchFn);
    config.providers.steel = { secretEnv: "STEEL_API_KEY", source: "env", verified: check.ok, checkedAt: stamp() };
    results.push({ provider: "steel", status: check.ok ? "connected" : "failed", detail: check.detail });
  }

  // ---- Browser Use (API key in env) ----
  if (!(await wantsSetup(io, "Browser Use (API key from cloud.browser-use.com/settings)"))) {
    results.push({ provider: "browseruse", status: "skipped", detail: "skipped" });
  } else if (!env.BROWSER_USE_API_KEY) {
    config.providers.browseruse = { secretEnv: "BROWSER_USE_API_KEY", source: "unset", verified: false };
    results.push({ provider: "browseruse", status: "failed", detail: "BROWSER_USE_API_KEY is not set — export it and re-run nephew init" });
  } else {
    const check = await checkBrowserUse(env.BROWSER_USE_API_KEY, fetchFn);
    config.providers.browseruse = { secretEnv: "BROWSER_USE_API_KEY", source: "env", verified: check.ok, checkedAt: stamp() };
    results.push({ provider: "browseruse", status: check.ok ? "connected" : "failed", detail: check.detail });
  }

  // ---- Bright Data (API token in env; customer id + zone are not secrets) ----
  if (!(await wantsSetup(io, "Bright Data (the pinned egress IP — API token in env, zone name here)"))) {
    results.push({ provider: "brightdata", status: "skipped", detail: "skipped — profiles then run unpinned" });
  } else if (!env.BRIGHTDATA_API_KEY) {
    config.providers.brightdata = { secretEnv: "BRIGHTDATA_API_KEY", source: "unset", verified: false };
    results.push({ provider: "brightdata", status: "failed", detail: "BRIGHTDATA_API_KEY is not set — export it and re-run nephew init" });
  } else {
    const prior = config.providers.brightdata;
    const zoneAnswer = (await io.ask(`Bright Data zone for the pinned IP${prior?.zone ? ` [${prior.zone}]` : ""}: `)).trim();
    const zone = zoneAnswer || prior?.zone || "";
    if (!zone) {
      config.providers.brightdata = { secretEnv: "BRIGHTDATA_API_KEY", source: "env", verified: false };
      results.push({ provider: "brightdata", status: "failed", detail: "no zone named — create a dedicated ISP zone in Bright Data, then re-run nephew init" });
    } else {
      const check = await checkBrightData(env.BRIGHTDATA_API_KEY, zone, fetchFn);
      const ref: ProviderRef = {
        secretEnv: "BRIGHTDATA_API_KEY", source: "env", verified: check.ok, checkedAt: stamp(), zone,
        ...(check.customerId ? { customerId: check.customerId } : {}),
      };
      config.providers.brightdata = ref;
      results.push({ provider: "brightdata", status: check.ok ? "connected" : "failed", detail: check.detail });
    }
  }

  config.updatedAt = stamp();
  await saveNephewConfig(configPath, config);

  io.out("");
  io.out("providers:");
  for (const r of results) {
    const mark = r.status === "connected" ? "✓" : r.status === "failed" ? "✗" : "–";
    io.out(`  ${mark} ${r.provider.padEnd(10)} ${r.detail}`);
  }
  io.out(`config      ${configPath} (references only — no key values stored)`);
  const connected = results.filter((r) => r.status === "connected").length;
  const attempted = results.filter((r) => r.status !== "skipped").length;
  io.out(connected > 0
    ? `next        nephew capture — sign in once, in your own browser`
    : "next        connect at least one provider, then nephew capture");
  return { code: connected > 0 || attempted === 0 ? 0 : 1, results, config, configPath };
}

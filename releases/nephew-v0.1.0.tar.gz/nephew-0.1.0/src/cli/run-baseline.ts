/**
 * cli/run-baseline — the live steel / browseruse runs for `nephew run`.
 *
 * This is the proofs' session half, factored out of scripts/proof-steel.ts
 * and scripts/proof-browseruse.ts (same calls, same order, same cleanup):
 * create the provider session through the vault-backed CLI (the API key
 * never touches this process — the CLI holds it via surrogate), connect
 * over CDP, apply the bundle's Emulation overrides, GATE on the bundle
 * recipe's pinned fingerprint elements, then run the baseline workload:
 * restore the owner-held bundle state and verify it landed. One metrics
 * record per run (measure.ts, TEST_PLAN format) — AGENTS.md #5.
 *
 * Provider-native profiles are never used (AGENTS.md #2): sessions are
 * created with no profile id; the only state in them is our bundle's.
 */
import { execFile } from "node:child_process";
import { promisify } from "node:util";
import { homedir } from "node:os";
import { fileURLToPath } from "node:url";
import { join } from "node:path";
import { decryptState, encryptState, saveBundle, type ProfileBundle } from "../profile-store.ts";
import { CdpClient } from "../cdp.ts";
import { restoreState, captureState, readOriginStorage, type StoredState } from "../state.ts";
import { captureFingerprint, type FingerprintCapture } from "../fingerprint.ts";
import { recordRun } from "../measure.ts";
import { fingerprintGate, isBrightDataPin } from "./receipt.ts";

const execFileP = promisify(execFile);
const RUNS_DIR = fileURLToPath(new URL("../../runs/", import.meta.url));
const STEEL_CLI = join(homedir(), "workspace/custom-connectors/custom.steel/bin/steel_api.py");
const BU_CLI = join(homedir(), "workspace/custom-connectors/custom.browseruse/bin/browseruse_api.py");

type Log = (line: string) => void;

export interface BaselineOutcome {
  verified: boolean;
  gateOk: boolean;
  gateChanged: string[];
  latencyMs: number;
}

/** Call a vault-backed provider CLI; returns the parsed body. Never logs the body. */
async function vaultApi(cli: string, label: string, method: string, path: string, body?: string): Promise<any> {
  const args = [cli, method, path, ...(body ? [body] : [])];
  try {
    const { stdout } = await execFileP("python3", args, { timeout: 120_000 });
    return JSON.parse(stdout);
  } catch (e: any) {
    const stderr = String(e?.stderr ?? "");
    const status = (stderr.match(/HTTP \d+/) ?? ["no HTTP status"])[0];
    throw new Error(`${label} CLI ${method} ${path} failed (${status})`);
  }
}

/**
 * A session's cdpUrl may be a websocket URL (use as-is) or an HTTP(S) CDP
 * endpoint (resolve via /json/version). The URL is a capability — never logged.
 */
export async function resolveWsUrl(cdpUrl: string): Promise<string> {
  if (cdpUrl.startsWith("ws://") || cdpUrl.startsWith("wss://")) return cdpUrl;
  const base = cdpUrl.replace(/\/$/, "");
  const r = await fetch(`${base}/json/version`);
  if (!r.ok) throw new Error(`cdpUrl /json/version returned HTTP ${r.status}`);
  const j: any = await r.json();
  if (!j?.webSocketDebuggerUrl) throw new Error("cdpUrl /json/version had no webSocketDebuggerUrl");
  return j.webSocketDebuggerUrl as string;
}

export async function attachPage(cdp: CdpClient, providerLabel: string): Promise<string> {
  const { targetInfos } = await cdp.send("Target.getTargets");
  const page = (targetInfos ?? []).find((t: any) => t.type === "page") ?? (targetInfos ?? [])[0];
  if (!page) throw new Error(`${providerLabel} session exposed no page target`);
  const { sessionId } = await cdp.send("Target.attachToTarget", { targetId: page.targetId, flatten: true });
  await cdp.send("Page.enable", {}, sessionId);
  await cdp.send("Runtime.enable", {}, sessionId);
  return sessionId as string;
}

/** Bundle fingerprint recipe, CDP-Emulation half (all a managed cloud allows). */
async function applyOverrides(cdp: CdpClient, sessionId: string, bundle: ProfileBundle): Promise<void> {
  const fp = bundle.fingerprint;
  if (fp.userAgent) {
    await cdp.send("Emulation.setUserAgentOverride", { userAgent: fp.userAgent }, sessionId);
  }
  if (fp.timezone) {
    await cdp.send("Emulation.setTimezoneOverride", { timezoneId: fp.timezone }, sessionId);
  }
  if (fp.locale) {
    await cdp.send("Emulation.setLocaleOverride", { locale: fp.locale }, sessionId);
  }
  if (fp.viewport) {
    await cdp.send("Emulation.setDeviceMetricsOverride", {
      width: fp.viewport.width, height: fp.viewport.height,
      deviceScaleFactor: fp.viewport.deviceScaleFactor ?? 1, mobile: false,
      screenWidth: fp.viewport.width, screenHeight: fp.viewport.height,
    }, sessionId);
  }
}

export interface InSessionOptions {
  /**
   * After a verified restore, capture the session state back into this
   * bundle directory (re-encrypted; manifest.updatedAt bumped). Only the
   * modal runner passes this in cli v0: its sandbox is destroyed at the
   * end of the run, so state that is not captured back is lost with it.
   */
  captureBackToDir?: string;
  /** Metrics record directory override (tests); default the scaffold runs/. */
  runsDir?: string;
}

/**
 * The shared in-session flow: overrides -> fingerprint gate -> baseline
 * workload (restore + verify). The gate runs BEFORE any state is restored:
 * a mismatch means this session is not presenting as the owner's device,
 * and the run refuses rather than logging in as a stranger.
 */
export async function runInSession(
  cdp: CdpClient,
  sessionId: string,
  job: string,
  bundle: ProfileBundle,
  environment: string,
  log: Log,
  opts: InSessionOptions = {},
): Promise<BaselineOutcome> {
  const t0 = Date.now();
  await applyOverrides(cdp, sessionId, bundle);

  const state = JSON.parse(decryptState(bundle.encryptedState)) as StoredState;
  const probeUrl = (state.origins[0]?.origin ?? "https://example.com") + "/";
  const fpLive: FingerprintCapture = await captureFingerprint(cdp, sessionId, probeUrl);
  const gate = fingerprintGate(bundle, fpLive);
  if (!gate.ok) {
    return { verified: false, gateOk: false, gateChanged: gate.changed, latencyMs: Date.now() - t0 };
  }

  log(`running     ${job} …`);
  await restoreState(cdp, sessionId, state);
  let lsAllMatch = true;
  for (const o of state.origins) {
    const restored = await readOriginStorage(cdp, sessionId, o.origin);
    const sort = (xs: { name: string; value: string }[]) =>
      JSON.stringify([...xs].sort((x, y) => x.name.localeCompare(y.name)));
    if (sort(restored) !== sort(o.localStorage)) lsAllMatch = false;
  }
  const { cookies } = await cdp.send("Storage.getCookies", {});
  const cookieMatch = (cookies ?? []).length === state.cookies.length;
  const verified = lsAllMatch && cookieMatch;

  // Capture-back (modal runner only): re-read the live state and re-seal
  // it into the owner bundle before the sandbox is destroyed. Only on a
  // verified restore — capturing back after a failed restore would seal
  // a stranger's state over the owner's.
  if (verified && opts.captureBackToDir) {
    const captured = await captureState(cdp, sessionId, state.origins.map((o) => o.origin));
    await saveBundle({
      ...bundle,
      manifest: { ...bundle.manifest, updatedAt: new Date().toISOString() },
      encryptedState: encryptState(JSON.stringify(captured)),
    }, opts.captureBackToDir);
    log(`captured    state sealed back into the owner bundle`);
  }
  const latencyMs = Date.now() - t0;

  await recordRun({
    runId: job.replace(/[^a-zA-Z0-9_-]+/g, "-"),
    date: new Date().toISOString(),
    environment,
    workloadCompleted: verified,
    loggedInAtStart: verified, loggedInAtEnd: verified,
    loginPrompts: 0, mfaPrompts: 0, blocksOrChallenges: 0,
    latencyMs, humanAttentionMinutes: 0, costUsd: 0,
    egressIp: fpLive.egressIp, proxyPinned: isBrightDataPin(bundle),
    fingerprint: fpLive, fingerprintDeltaVsBundle: gate.diff,
    notes: `nephew run (cli v0) ${environment} baseline: bundle state restore ${verified ? "verified" : "FAILED"}; gate pinned elements held`,
  }, opts.runsDir ?? RUNS_DIR);
  log(`recorded    runs/ (${environment})`);
  return { verified, gateOk: true, gateChanged: [], latencyMs };
}

/**
 * A live provider session, opened and attached, with its teardown bundled —
 * the shape src/with-profile.ts holds while a job function drives the page.
 * close() is the same teardown the baseline runners always did (CDP close,
 * then provider release/stop), best-effort on the provider side.
 */
export interface OpenedProviderSession {
  cdp: CdpClient;
  pageSessionId: string;
  close(): Promise<void>;
}

export async function openSteelSession(log: Log): Promise<OpenedProviderSession> {
  // The vault key is org-scoped: Steel binds it to no project and rejects
  // session creation without an explicit projectId (HTTP 400). Use the
  // default project (measured in proof-steel, 2026-10-29).
  const projectList = await vaultApi(STEEL_CLI, "Steel", "GET", "/v1/projects");
  const project =
    (projectList?.projects ?? []).find((p: any) => p.isDefault) ?? (projectList?.projects ?? [])[0];
  if (!project?.id) throw new Error("Steel project list had no usable project");
  const created = await vaultApi(
    STEEL_CLI, "Steel", "POST", "/v1/sessions",
    JSON.stringify({ timeout: 600000, projectId: project.id }),
  );
  const sessionId: string | undefined = created?.id ?? created?.sessionId;
  const wsUrl: string | undefined =
    created?.websocketUrl ?? created?.webSocketUrl ?? created?.cdpUrl ?? created?.wsUrl;
  if (!sessionId || !wsUrl) {
    console.error("Steel session create response keys:", Object.keys(created ?? {}).join(", "));
    throw new Error("Steel session create response had no session id / CDP websocket URL");
  }
  const t0 = Date.now();
  const cdp = await CdpClient.connect(wsUrl);
  const page = await attachPage(cdp, "steel-cloud");
  log(`session     steel-cloud · live in ${((Date.now() - t0) / 1000).toFixed(1)}s`);
  return {
    cdp,
    pageSessionId: page,
    async close() {
      cdp.close();
      try { await vaultApi(STEEL_CLI, "Steel", "POST", `/v1/sessions/${sessionId}/release`); }
      catch { /* release best-effort; the session timeout reaps it */ }
    },
  };
}

export async function runSteelBaseline(job: string, bundle: ProfileBundle, log: Log): Promise<BaselineOutcome> {
  const session = await openSteelSession(log);
  try {
    return await runInSession(session.cdp, session.pageSessionId, job, bundle, "steel-cloud", log);
  } finally {
    await session.close();
  }
}

export async function openBrowserUseSession(log: Log): Promise<OpenedProviderSession> {
  const created = await vaultApi(BU_CLI, "Browser Use", "POST", "/api/v2/browsers", JSON.stringify({}));
  const buId: string | undefined = created?.id ?? created?.sessionId;
  const cdpUrl: string | undefined =
    created?.cdpUrl ?? created?.websocketUrl ?? created?.webSocketUrl ?? created?.wsUrl;
  if (!buId || !cdpUrl) {
    console.error("Browser Use session create response keys:", Object.keys(created ?? {}).join(", "));
    throw new Error("Browser Use session create response had no session id / CDP URL");
  }
  const t0 = Date.now();
  // A freshly created cloud browser may need a moment before its CDP
  // endpoint answers; retry resolve+connect briefly before failing.
  let cdp: CdpClient | undefined;
  let lastConnectErr: unknown;
  for (let attempt = 0; attempt < 10 && !cdp; attempt++) {
    try {
      cdp = await CdpClient.connect(await resolveWsUrl(cdpUrl));
    } catch (e) {
      lastConnectErr = e;
      await new Promise((r) => setTimeout(r, 1500));
    }
  }
  if (!cdp) throw lastConnectErr instanceof Error ? lastConnectErr : new Error("CDP connect failed");
  const connected = cdp;
  const page = await attachPage(connected, "browser-use-cloud");
  log(`session     browser-use-cloud · live in ${((Date.now() - t0) / 1000).toFixed(1)}s`);
  return {
    cdp: connected,
    pageSessionId: page,
    async close() {
      connected.close();
      // The v2 stop route is PATCH {"action":"stop"} — POST .../stop 404s and
      // DELETE is not accepted either (measured 2026-10-29, proof-browseruse).
      const stopAttempts: [string, string, string?][] = [
        ["PATCH", `/api/v2/browsers/${buId}`, JSON.stringify({ action: "stop" })],
        ["POST", `/api/v2/browsers/${buId}/stop`, undefined],
        ["DELETE", `/api/v2/browsers/${buId}`, undefined],
      ];
      for (const [method, path, body] of stopAttempts) {
        try {
          await vaultApi(BU_CLI, "Browser Use", method, path, body);
          break;
        } catch { /* try the next route; the session timeout reaps it regardless */ }
      }
    },
  };
}

export async function runBrowserUseBaseline(job: string, bundle: ProfileBundle, log: Log): Promise<BaselineOutcome> {
  const session = await openBrowserUseSession(log);
  try {
    return await runInSession(session.cdp, session.pageSessionId, job, bundle, "browser-use-cloud", log);
  } finally {
    await session.close();
  }
}

/**
 * cli/run-core — the one run path behind every surface: `nephew run`
 * (src/nephew.ts) and the MCP `profile_run` tool (src/mcp/server.ts) both
 * call runProfileJob, so the trust receipt, the fingerprint gate, and the
 * outcome semantics can never drift between surfaces.
 *
 * Outcome mapping (the delight brief's failure shape):
 *   gate mismatch        → "refused" — nothing ran, no state was released.
 *   restore did not verify → "login-required" — the carried login did not
 *     hold in the provider session. The CLI prints its failure line; the
 *     MCP surface returns this as the structured LOGIN_REQUIRED pause
 *     (a pause, not an exception), naming the bundle's designated human.
 *   verified             → "completed".
 */
import { homedir } from "node:os";
import { join } from "node:path";
import { loadBundle, type ProfileBundle } from "../profile-store.ts";
import { modalConnectionProblem, type ProviderName } from "./args.ts";
import { formatReceipt } from "./receipt.ts";
import { runSteelBaseline, runBrowserUseBaseline, type BaselineOutcome } from "./run-baseline.ts";
import { runModalBaseline } from "./run-modal.ts";

export type RunOutcome =
  | { kind: "completed"; receipt: string[]; bundle: ProfileBundle; latencyMs: number }
  | { kind: "refused"; receipt: string[]; bundle: ProfileBundle; changed: string[] }
  | { kind: "login-required"; receipt: string[]; bundle: ProfileBundle; provider: ProviderName }
  | { kind: "not-connected"; message: string }
  | { kind: "failed"; message: string };

export interface RunCoreDeps {
  runSteel?: typeof runSteelBaseline;
  runBrowserUse?: typeof runBrowserUseBaseline;
  runModal?: typeof runModalBaseline;
  loadBundleFn?: typeof loadBundle;
}

export function defaultBundleDir(env: NodeJS.ProcessEnv): string {
  return env.NEPHEW_BUNDLE_DIR ?? join(homedir(), "workspace/profile-proof-runs/default/bundle");
}

function firstLine(e: unknown): string {
  return (e instanceof Error ? e.message : String(e)).split("\n")[0];
}

export async function runProfileJob(
  input: { job: string; provider: ProviderName; bundleDir?: string; env: NodeJS.ProcessEnv; log: (line: string) => void },
  deps: RunCoreDeps = {},
): Promise<RunOutcome> {
  const { env, log } = input;

  // Modal gate first: one clear line, nothing else, when the pair is absent.
  if (input.provider === "modal") {
    const problem = modalConnectionProblem(env);
    if (problem) return { kind: "not-connected", message: problem };
  }

  const bundleDir = input.bundleDir ?? defaultBundleDir(env);
  let bundle: ProfileBundle;
  try {
    bundle = await (deps.loadBundleFn ?? loadBundle)(bundleDir);
  } catch (e) {
    return { kind: "failed", message: `nephew: could not load a bundle at ${bundleDir} — ${firstLine(e)}` };
  }

  // Trust receipt — before anything starts, on every path.
  const receipt = formatReceipt(bundle);
  for (const line of receipt) log(line);

  if (!env.PROFILE_ENCRYPTION_KEY) {
    return { kind: "failed", message: "nephew: PROFILE_ENCRYPTION_KEY is not set — the bundle state cannot be decrypted" };
  }

  let outcome: BaselineOutcome;
  try {
    outcome =
      input.provider === "steel"
        ? await (deps.runSteel ?? runSteelBaseline)(input.job, bundle, log)
        : input.provider === "browseruse"
          ? await (deps.runBrowserUse ?? runBrowserUseBaseline)(input.job, bundle, log)
          : await (deps.runModal ?? runModalBaseline)(input.job, bundle, bundleDir, log);
  } catch (e) {
    return { kind: "failed", message: `nephew: ${firstLine(e)}` };
  }

  if (!outcome.gateOk) return { kind: "refused", receipt, bundle, changed: outcome.gateChanged };
  if (!outcome.verified) return { kind: "login-required", receipt, bundle, provider: input.provider };
  return { kind: "completed", receipt, bundle, latencyMs: outcome.latencyMs };
}

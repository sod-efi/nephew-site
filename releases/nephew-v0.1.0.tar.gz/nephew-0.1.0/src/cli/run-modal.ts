/**
 * cli/run-modal — the live Modal run for `nephew run --provider modal`.
 *
 * Modal is the own-stack host (owner decision 2026-10-29): the sandbox
 * runs OUR patched Chromium (fingerprint-chromium, bundle seed — the
 * moat track in docs/ARCHITECTURE.md), not a provider browser.
 *
 * CO-LOCATED DRIVER (the 2026-10-30 rebuild). The first version of this
 * runner drove the sandbox browser from the host over the sandbox's
 * encrypted CDP tunnel. Its live smoke test failed for an architectural
 * reason: this host cannot reach *.modal.host tunnel hosts at all —
 * Node fetch, curl, and Python urllib all fail to connect, while
 * sandbox creation itself succeeds in ~2.5 s. The fix moves the
 * browser-driving step to where the browser is: the sandbox image
 * carries tools/modal_driver.py, which speaks CDP to Chromium over the
 * sandbox's own loopback and returns only the structured result. This
 * runner never opens a CDP connection; it asks the bridge to exec the
 * driver once per phase and keeps everything else host-side:
 *
 *   create sandbox -> driver probe -> GATE (host) -> driver restore
 *   -> capture-back seal (host) -> metrics record -> terminate
 *
 * The gate placement is a security property, not an optimization: the
 * probe payload carries NO state, so the bundle's plaintext state is
 * decrypted and sent into the sandbox only after the live fingerprint
 * matches the bundle recipe — the same order the steel / browseruse
 * baselines enforce in run-baseline.ts (gate before restore). The
 * driver captures state back only after a verified restore; the host
 * re-seals it into the owner bundle under the bundle key, because a
 * terminated sandbox takes its browser profile with it.
 *
 * PINNED EGRESS (2026-10-30): a bundle that pins a proxyUrl sends the
 * sandbox Chromium out through that proxy directly — the sandbox has
 * direct internet, so no host relay is involved. Chromium launches with
 * --proxy-server (in the create request, which never carries secrets);
 * the proxy's credentials arrive via the run's environment
 * (NEPHEW_PROXY_USERNAME / NEPHEW_PROXY_PASSWORD), ride only the two
 * driver payloads, and are spent inside the sandbox by the driver's CDP
 * Fetch auth handler. A pinned proxy with no credentials in the
 * environment refuses the run before any sandbox exists.
 *
 * Why a Python bridge (tools/modal_bridge.py) instead of a TS SDK: the
 * Modal TS SDK is not a dependency of this project and this build is
 * offline; the Python SDK (modal 1.6.3, ~/workspace/.venv-modal) is
 * installed and verified. The other providers already shell out to
 * Python CLIs the same way. The token pair reaches the bridge through
 * its environment only (the SDK reads MODAL_TOKEN_ID /
 * MODAL_TOKEN_SECRET natively) — never through argv, the request JSON,
 * or any log line (AGENTS.md #3).
 */
import { spawn } from "node:child_process";
import { homedir } from "node:os";
import { fileURLToPath } from "node:url";
import { join } from "node:path";
import { decryptState, encryptState, saveBundle, type ProfileBundle } from "../profile-store.ts";
import type { StoredState } from "../state.ts";
import {
  FINGERPRINT_PROBE_EXPRESSION, EGRESS_PROBE_EXPRESSION, type FingerprintCapture,
} from "../fingerprint.ts";
import { recordRun } from "../measure.ts";
import { fingerprintGate, isBrightDataPin } from "./receipt.ts";
import type { BaselineOutcome } from "./run-baseline.ts";

type Log = (line: string) => void;

const RUNS_DIR = fileURLToPath(new URL("../../runs/", import.meta.url));

export const MODAL_CDP_PORT = 9222;
/** In-sandbox profile dir. Ephemeral by design: state arrives and leaves via the driver. */
export const MODAL_USER_DATA_DIR = "/tmp/nephew-profile";
export const MODAL_DEFAULT_TIMEOUT_SEC = 600;
/** Per-phase ceiling for one in-sandbox driver exec. */
export const MODAL_DRIVER_TIMEOUT_SEC = 300;

// ---------------------------------------------------------- proxy secrets

/** Proxy credentials for a bundle-pinned proxy, carried by the run only. */
export interface ModalProxyAuth {
  username: string;
  password: string;
}

export const MODAL_PROXY_USERNAME_ENV = "NEPHEW_PROXY_USERNAME";
export const MODAL_PROXY_PASSWORD_ENV = "NEPHEW_PROXY_PASSWORD";

/**
 * Resolve proxy credentials for a bundle that pins a proxyUrl, from the
 * run's secret channel — the environment — and nowhere else. The bundle
 * holds only the proxy reference + URL (profile-store: network.json is
 * "reference, not credentials"), and the bridge request that CREATES the
 * sandbox never carries them: they cross only inside the two driver
 * payloads, to the in-sandbox driver's CDP Fetch auth handler.
 *
 * Fail closed: a pinned proxy without credentials in the environment is
 * a hard stop BEFORE any sandbox exists. Silently running unpinned
 * would break the identity's Layer-3 pin while the receipt claims it.
 */
export function modalProxyAuth(
  bundle: ProfileBundle,
  env: NodeJS.ProcessEnv = process.env,
): ModalProxyAuth | undefined {
  if (!bundle.network.proxyUrl) return undefined;
  const username = env[MODAL_PROXY_USERNAME_ENV];
  const password = env[MODAL_PROXY_PASSWORD_ENV];
  if (!username || !password) {
    throw new Error(
      `bundle pins a proxy (${bundle.network.proxyRef}) but ${MODAL_PROXY_USERNAME_ENV} / ${MODAL_PROXY_PASSWORD_ENV} are not set in the run environment — refusing to run unpinned`,
    );
  }
  return { username, password };
}

// ---------------------------------------------------------- driver payloads

/** The bundle's Emulation overrides, as the driver applies them in-sandbox. */
export interface ModalOverrides {
  userAgent?: string;
  timezone?: string;
  locale?: string;
  viewport?: { width: number; height: number; deviceScaleFactor?: number };
}

export type ModalDriverRequest =
  | {
      phase: "probe";
      overrides: ModalOverrides;
      probeUrl: string;
      probeExpression: string;
      egressExpression: string;
      /** Run-secret-channel proxy credentials (env -> driver Fetch auth). */
      proxyAuth?: ModalProxyAuth;
    }
  | { phase: "restore"; state: StoredState; captureBack: boolean; proxyAuth?: ModalProxyAuth };

export interface ModalDriverProbeResult {
  ok: true;
  phase: "probe";
  fpLive: FingerprintCapture;
}

export interface ModalDriverRestoreResult {
  ok: true;
  phase: "restore";
  verified: boolean;
  capturedState?: StoredState;
}

export type ModalDriverResult =
  | ModalDriverProbeResult
  | ModalDriverRestoreResult
  | { ok: false; error?: string };

// ------------------------------------------------------------ bridge types

export type ModalBridgeRequest =
  | { action: "create"; chromiumArgs: string[]; timeoutSec: number; appName?: string }
  | { action: "run"; sandboxId: string; driver: ModalDriverRequest; timeoutSec: number }
  | { action: "terminate"; sandboxId: string };

export interface ModalBridgeResponse {
  ok: boolean;
  error?: string;
  sandboxId?: string;
  cdpHttpUrl?: string;
  driver?: ModalDriverResult;
}

/**
 * Chromium flags for the sandbox. Mirrors the own-stack adapter's
 * launchArgsFor (same seed/persona/proxy construction), with the two
 * differences the sandbox forces: the debugging address is 0.0.0.0 (so
 * the port can be exposed as a tunnel for diagnostics) and the
 * user-data-dir is a sandbox path. Pure — unit-tested.
 */
export function modalChromiumArgs(bundle: ProfileBundle): string[] {
  const fp = bundle.fingerprint;
  const args = [
    "--headless=new",
    "--no-sandbox",
    "--disable-dev-shm-usage",
    "--disable-gpu-sandbox",
    "--use-angle=swiftshader",
    `--fingerprint=${fp.seed}`,
    `--user-data-dir=${MODAL_USER_DATA_DIR}`,
    `--remote-debugging-port=${MODAL_CDP_PORT}`,
    "--remote-debugging-address=0.0.0.0",
    "--no-first-run",
    "--no-default-browser-check",
  ];
  if (fp.platform) args.push(`--fingerprint-platform=${fp.platform}`);
  if (fp.brand) args.push(`--fingerprint-brand=${fp.brand}`);
  if (fp.timezone) args.push(`--timezone=${fp.timezone}`);
  if (fp.locale) args.push(`--lang=${fp.locale}`, `--accept-lang=${fp.locale},en`);
  if (bundle.network.proxyUrl) args.push(`--proxy-server=${bundle.network.proxyUrl}`);
  args.push("about:blank");
  return args;
}

/** The create request for a run. Carries no credential material, ever. */
export function buildModalCreateRequest(
  bundle: ProfileBundle,
  opts: { timeoutSec?: number; appName?: string } = {},
): ModalBridgeRequest {
  return {
    action: "create",
    chromiumArgs: modalChromiumArgs(bundle),
    timeoutSec: opts.timeoutSec ?? MODAL_DEFAULT_TIMEOUT_SEC,
    ...(opts.appName ? { appName: opts.appName } : {}),
  };
}

/** The bundle fingerprint recipe's Emulation half, for the driver. Pure. */
export function modalOverrides(bundle: ProfileBundle): ModalOverrides {
  const fp = bundle.fingerprint;
  return {
    ...(fp.userAgent ? { userAgent: fp.userAgent } : {}),
    ...(fp.timezone ? { timezone: fp.timezone } : {}),
    ...(fp.locale ? { locale: fp.locale } : {}),
    ...(fp.viewport ? { viewport: fp.viewport } : {}),
  };
}

/**
 * The probe-phase payload. Deliberately carries NO bundle state: state
 * crosses into the sandbox only in the restore phase, after the gate.
 * The probe expressions are fingerprint.ts's own — one probe everywhere.
 */
export function buildModalProbeRequest(
  bundle: ProfileBundle,
  state: StoredState,
  proxyAuth?: ModalProxyAuth,
): ModalDriverRequest {
  return {
    phase: "probe",
    overrides: modalOverrides(bundle),
    probeUrl: (state.origins[0]?.origin ?? "https://example.com") + "/",
    probeExpression: FINGERPRINT_PROBE_EXPRESSION,
    egressExpression: EGRESS_PROBE_EXPRESSION,
    ...(proxyAuth ? { proxyAuth } : {}),
  };
}

/** The restore-phase payload — the first moment state leaves the host. */
export function buildModalRestoreRequest(
  state: StoredState,
  captureBack = true,
  proxyAuth?: ModalProxyAuth,
): ModalDriverRequest {
  return { phase: "restore", state, captureBack, ...(proxyAuth ? { proxyAuth } : {}) };
}

/** Wrap a driver payload as a bridge `run` request. */
export function buildModalRunRequest(
  sandboxId: string,
  driver: ModalDriverRequest,
  opts: { timeoutSec?: number } = {},
): ModalBridgeRequest {
  return {
    action: "run",
    sandboxId,
    driver,
    timeoutSec: opts.timeoutSec ?? MODAL_DRIVER_TIMEOUT_SEC,
  };
}

/** Validate + narrow a bridge response's driver result for one phase. */
export function parseDriverResult(
  res: ModalBridgeResponse,
  phase: "probe",
): ModalDriverProbeResult;
export function parseDriverResult(
  res: ModalBridgeResponse,
  phase: "restore",
): ModalDriverRestoreResult;
export function parseDriverResult(
  res: ModalBridgeResponse,
  phase: "probe" | "restore",
): ModalDriverProbeResult | ModalDriverRestoreResult {
  const label = `modal in-sandbox driver (${phase})`;
  const d = res.driver;
  if (!d) throw new Error(`${label} returned no result`);
  if (!d.ok) throw new Error(`${label} failed: ${d.error ?? "unknown driver error"}`);
  if (d.phase !== phase) throw new Error(`${label} answered for phase "${d.phase}"`);
  if (phase === "probe" && !(d as ModalDriverProbeResult).fpLive) {
    throw new Error(`${label} result had no fingerprint capture`);
  }
  if (phase === "restore" && typeof (d as ModalDriverRestoreResult).verified !== "boolean") {
    throw new Error(`${label} result had no verified flag`);
  }
  return d as ModalDriverProbeResult | ModalDriverRestoreResult;
}

/** Parse the bridge's single JSON response line out of its stdout. */
export function parseBridgeResponse(stdout: string): ModalBridgeResponse {
  const line = stdout.trim().split("\n").filter(Boolean).pop();
  if (!line) throw new Error("modal bridge produced no output");
  let parsed: any;
  try {
    parsed = JSON.parse(line);
  } catch {
    throw new Error("modal bridge produced unparseable output");
  }
  if (typeof parsed?.ok !== "boolean") throw new Error("modal bridge response had no ok flag");
  return parsed as ModalBridgeResponse;
}

export function modalPythonPath(env: NodeJS.ProcessEnv = process.env): string {
  return env.NEPHEW_MODAL_PYTHON ?? join(homedir(), "workspace/.venv-modal/bin/python");
}

export function modalBridgePath(env: NodeJS.ProcessEnv = process.env): string {
  return env.NEPHEW_MODAL_BRIDGE ?? fileURLToPath(new URL("../../tools/modal_bridge.py", import.meta.url));
}

/** Default bridge transport: spawn the Python bridge, request JSON on stdin. */
export function spawnBridge(
  req: ModalBridgeRequest,
  opts: { timeoutMs?: number; env?: NodeJS.ProcessEnv } = {},
): Promise<ModalBridgeResponse> {
  const env = opts.env ?? process.env;
  const timeoutMs = opts.timeoutMs ?? (req.action === "create" ? 600_000 : 360_000);
  return new Promise((resolve, reject) => {
    const child = spawn(modalPythonPath(env), [modalBridgePath(env)], {
      stdio: ["pipe", "pipe", "pipe"],
      env,
    });
    let stdout = "";
    let stderr = "";
    const timer = setTimeout(() => {
      child.kill("SIGKILL");
      reject(new Error(`modal bridge ${req.action} timed out after ${timeoutMs} ms`));
    }, timeoutMs);
    child.stdout.on("data", (d) => { stdout += d; });
    child.stderr.on("data", (d) => { stderr += d; });
    child.on("error", (e) => {
      clearTimeout(timer);
      reject(new Error(`modal bridge could not start: ${e.message.split("\n")[0]}`));
    });
    child.on("close", () => {
      clearTimeout(timer);
      try {
        resolve(parseBridgeResponse(stdout));
      } catch (e) {
        const firstStderr = stderr.trim().split("\n")[0];
        reject(new Error(
          `modal bridge ${req.action} failed (${(e as Error).message})${firstStderr ? `: ${firstStderr.slice(0, 200)}` : ""}`,
        ));
      }
    });
    child.stdin.end(JSON.stringify(req));
  });
}

async function bridgeOrThrow(
  bridge: (req: ModalBridgeRequest) => Promise<ModalBridgeResponse>,
  req: ModalBridgeRequest,
  label: string,
): Promise<ModalBridgeResponse> {
  const res = await bridge(req);
  if (!res.ok) throw new Error(`modal ${label} failed: ${res.error ?? "unknown bridge error"}`);
  return res;
}

/** Injectable seams so the whole runner is unit-testable offline. */
export interface ModalDeps {
  bridge?: (req: ModalBridgeRequest) => Promise<ModalBridgeResponse>;
  runsDir?: string;
  timeoutSec?: number;
  /** Per-phase in-sandbox driver exec ceiling. */
  driverTimeoutSec?: number;
  appName?: string;
  /** Run environment (secret channel + app name). Defaults to process.env. */
  env?: NodeJS.ProcessEnv;
}

export async function runModalBaseline(
  job: string,
  bundle: ProfileBundle,
  bundleDir: string,
  log: Log,
  deps: ModalDeps = {},
): Promise<BaselineOutcome> {
  const bridge = deps.bridge ?? ((req) => spawnBridge(req));
  const env = deps.env ?? process.env;

  // A loopback proxyUrl is the host-local Bright Data relay (bd_relay):
  // it exists on THIS host and a sandbox cannot route through it. Say so
  // plainly instead of silently running unpinned.
  const proxyUrl = bundle.network.proxyUrl;
  const loopbackProxy = !!proxyUrl && /^(https?|socks5?):\/\/(127\.0\.0\.1|localhost|\[::1\])/i.test(proxyUrl);
  if (loopbackProxy) {
    log("network     bundle proxy is host-loopback (local relay) — not reachable from a modal sandbox; this run's egress is unpinned");
  }
  // A real (non-loopback) pinned proxy: credentials must be in the run
  // environment, resolved BEFORE any sandbox exists (fail closed).
  // Chromium launches with --proxy-server (create request, no secrets);
  // the credentials ride only the two driver payloads, where the
  // in-sandbox driver answers the proxy's 407 via CDP Fetch auth.
  const proxyAuth = proxyUrl && !loopbackProxy ? modalProxyAuth(bundle, env) : undefined;
  if (proxyAuth) {
    log(`network     egress pin ${bundle.network.proxyRef} — sandbox Chromium routes via the pinned proxy directly; credentials from the run environment only`);
  }

  const t0 = Date.now();
  const created = await bridgeOrThrow(
    bridge,
    buildModalCreateRequest(bundle, {
      timeoutSec: deps.timeoutSec,
      appName: deps.appName ?? env.NEPHEW_MODAL_APP,
    }),
    "sandbox create",
  );
  const sandboxId = created.sandboxId;
  if (!sandboxId) {
    throw new Error("modal sandbox create response had no sandbox id");
  }
  log(`session     modal-sandbox · live in ${((Date.now() - t0) / 1000).toFixed(1)}s`);
  try {
    // Decrypted host-side for the probe URL; the plaintext itself stays
    // on the host until the gate below has accepted the live fingerprint.
    const state = JSON.parse(decryptState(bundle.encryptedState)) as StoredState;

    // Phase 1 — probe. No state in this payload, by construction.
    const probeRes = await bridgeOrThrow(
      bridge,
      buildModalRunRequest(sandboxId, buildModalProbeRequest(bundle, state, proxyAuth), {
        timeoutSec: deps.driverTimeoutSec,
      }),
      "driver probe",
    );
    const { fpLive } = parseDriverResult(probeRes, "probe");

    // The trust gate — identical semantics to the baselines: pinned
    // elements only, refusal before any state is restored.
    const gate = fingerprintGate(bundle, fpLive);
    if (!gate.ok) {
      return { verified: false, gateOk: false, gateChanged: gate.changed, latencyMs: Date.now() - t0 };
    }

    // Phase 2 — restore + verify inside the sandbox.
    log(`running     ${job} …`);
    const restoreRes = await bridgeOrThrow(
      bridge,
      buildModalRunRequest(sandboxId, buildModalRestoreRequest(state, true, proxyAuth), {
        timeoutSec: deps.driverTimeoutSec,
      }),
      "driver restore",
    );
    const restore = parseDriverResult(restoreRes, "restore");
    const verified = restore.verified;

    // Capture-back: the driver returns the live state only after a
    // verified restore; re-seal it into the owner bundle before the
    // sandbox is destroyed, or the state dies with the sandbox.
    if (verified && restore.capturedState) {
      await saveBundle({
        ...bundle,
        manifest: { ...bundle.manifest, updatedAt: new Date().toISOString() },
        encryptedState: encryptState(JSON.stringify(restore.capturedState)),
      }, bundleDir);
      log(`captured    state sealed back into the owner bundle`);
    }
    const latencyMs = Date.now() - t0;

    await recordRun({
      runId: job.replace(/[^a-zA-Z0-9_-]+/g, "-"),
      date: new Date().toISOString(),
      environment: "modal-sandbox",
      workloadCompleted: verified,
      loggedInAtStart: verified, loggedInAtEnd: verified,
      loginPrompts: 0, mfaPrompts: 0, blocksOrChallenges: 0,
      latencyMs, humanAttentionMinutes: 0, costUsd: 0,
      egressIp: fpLive.egressIp, proxyPinned: isBrightDataPin(bundle),
      fingerprint: fpLive, fingerprintDeltaVsBundle: gate.diff,
      notes: `nephew run (cli v0) modal-sandbox baseline: bundle state restore ${verified ? "verified" : "FAILED"}; gate pinned elements held; driver co-located in sandbox`,
    }, deps.runsDir ?? RUNS_DIR);
    log(`recorded    runs/ (modal-sandbox)`);
    return { verified, gateOk: true, gateChanged: [], latencyMs };
  } finally {
    try {
      await bridgeOrThrow(bridge, { action: "terminate", sandboxId }, "sandbox terminate");
    } catch { /* terminate best-effort; the sandbox timeout reaps it */ }
  }
}

/**
 * fingerprint — capture the measure set over CDP and diff two captures.
 * Hashes are identifiers, safe to log (SECURITY_REVIEW rule 4). Raw values like
 * the WebGL renderer string are fine; cookie/token values never appear here.
 *
 * The probe runs in the page: canvas/WebGL/audio hashes are computed the same
 * way the spike's probe.html computed them, so spike and product numbers are
 * comparable.
 */
import type { CdpClient } from "./cdp.ts";
import { setTimeout as sleep } from "node:timers/promises";

export interface FingerprintCapture {
  userAgent: string;
  timezone: string;
  canvasHash: string;
  webglVendor: string;
  webglRenderer: string;
  audioHash: string;
  fontsHash: string;
  screen: string;
  hardwareConcurrency: number;
  egressIp: string;
}

export function diffFingerprints(a: FingerprintCapture, b: FingerprintCapture) {
  const changed: string[] = [];
  const unchanged: string[] = [];
  (Object.keys(a) as (keyof FingerprintCapture)[]).forEach((k) =>
    (String(a[k]) === String(b[k]) ? unchanged : changed).push(k),
  );
  return { changed, unchanged };
}

const PROBE = `(async () => {
  const hash = (s) => { let h = 0; for (let i = 0; i < s.length; i++) { h = (h * 31 + s.charCodeAt(i)) >>> 0; } return h.toString(16); };
  const out = {};
  out.userAgent = navigator.userAgent;
  out.timezone = Intl.DateTimeFormat().resolvedOptions().timeZone;
  out.hardwareConcurrency = navigator.hardwareConcurrency;
  const cv = document.createElement('canvas'); cv.width = 280; cv.height = 60;
  const ctx = cv.getContext('2d');
  ctx.textBaseline = 'top'; ctx.font = '14px Arial'; ctx.fillStyle = '#f60';
  ctx.fillRect(2, 2, 120, 20); ctx.fillStyle = '#069';
  ctx.fillText('portable-profile-probe', 4, 24); ctx.fillStyle = 'rgba(102,204,0,0.7)';
  ctx.fillText('portable-profile-probe', 6, 26);
  out.canvasHash = hash(cv.toDataURL());
  const gl = document.createElement('canvas').getContext('webgl');
  if (gl) {
    const ext = gl.getExtension('WEBGL_debug_renderer_info');
    out.webglVendor = ext ? gl.getParameter(ext.UNMASKED_VENDOR_WEBGL) : gl.getParameter(gl.VENDOR);
    out.webglRenderer = ext ? gl.getParameter(ext.UNMASKED_RENDERER_WEBGL) : gl.getParameter(gl.RENDERER);
  } else { out.webglVendor = ''; out.webglRenderer = ''; }
  try {
    const ac = new OfflineAudioContext(1, 44100, 44100);
    const osc = ac.createOscillator(); osc.type = 'triangle'; osc.frequency.value = 10000;
    const comp = ac.createDynamicsCompressor();
    osc.connect(comp); comp.connect(ac.destination); osc.start(0);
    const buf = await ac.startRendering();
    const data = buf.getChannelData(0);
    let sum = 0; for (let i = 4500; i < 5500; i++) sum += Math.abs(data[i]);
    out.audioHash = hash(String(sum));
  } catch { out.audioHash = ''; }
  const fonts = ['Arial','Verdana','Times New Roman','Courier New','Georgia','Trebuchet MS','Comic Sans MS','Impact','Tahoma','Calibri','Segoe UI','Helvetica Neue','Menlo','Consolas'];
  const base = { 'monospace': 0, 'sans-serif': 0, 'serif': 0 };
  const test = document.createElement('canvas').getContext('2d');
  const widthFor = (f) => { test.font = '72px ' + f; return test.measureText('mmmmmmmmmmlli').width; };
  const baseW = {}; for (const b of Object.keys(base)) baseW[b] = widthFor(b);
  const detected = fonts.filter((f) => Object.keys(baseW).some((b) => widthFor(f + ',' + b) !== baseW[b]));
  out.fontsHash = hash(detected.join(','));
  out.screen = screen.width + 'x' + screen.height;
  return out;
})()`;

/**
 * The probe expressions, exported so an out-of-process driver (the Modal
 * in-sandbox driver, tools/modal_driver.py) runs the EXACT same measurement
 * this module runs over CDP — spike, baseline, and sandbox numbers stay
 * comparable because there is one probe, not two copies that can drift.
 */
export const FINGERPRINT_PROBE_EXPRESSION = PROBE;
export const EGRESS_PROBE_EXPRESSION =
  `fetch('https://api.ipify.org?format=json').then(r => r.json()).then(j => j.ip).catch(() => '')`;

export async function captureFingerprint(
  cdp: CdpClient,
  sessionId: string,
  pageUrl: string,
): Promise<FingerprintCapture> {
  await cdp.send("Page.navigate", { url: pageUrl }, sessionId);
  await sleep(1500);
  const probe = await cdp.evaluate<Record<string, unknown>>(sessionId, PROBE);
  let egressIp = "";
  try {
    egressIp = await cdp.evaluate<string>(sessionId, EGRESS_PROBE_EXPRESSION);
  } catch { egressIp = ""; }
  return {
    userAgent: String(probe.userAgent ?? ""),
    timezone: String(probe.timezone ?? ""),
    canvasHash: String(probe.canvasHash ?? ""),
    webglVendor: String(probe.webglVendor ?? ""),
    webglRenderer: String(probe.webglRenderer ?? ""),
    audioHash: String(probe.audioHash ?? ""),
    fontsHash: String(probe.fontsHash ?? ""),
    screen: String(probe.screen ?? ""),
    hardwareConcurrency: Number(probe.hardwareConcurrency ?? 0),
    egressIp: egressIp ?? "",
  };
}

/**
 * human-input — ALL automated mouse input in workload runs goes through here.
 *
 * Owner requirement (2026-10-29): automated input must be human-paced,
 * slower than machine speed, so bot detectors are not tripped. Concretely:
 *   - no instant jumps and no straight constant-velocity lines — the pointer
 *     travels an eased cubic-Bezier curve with a random perpendicular bow;
 *   - variable speed with natural acceleration and deceleration (smootherstep
 *     easing over the path, per-step timing jittered);
 *   - a small overshoot past the target on longer moves, then a settle back
 *     onto the exact point;
 *   - a randomized dwell before every click, and a human-length button hold.
 *
 * The planner (`planMousePath`) is pure and unit-tested; `HumanInput` is the
 * thin CDP dispatcher over it (Input.dispatchMouseEvent). Parameters live in
 * HUMAN_INPUT_DEFAULTS and are recorded in memory.md (2026-10-29). Workload
 * code must not dispatch raw Input events itself.
 */
import { setTimeout as sleep } from "node:timers/promises";
import type { CdpClient } from "./cdp.ts";

export interface Point { x: number; y: number }
export interface PathStep extends Point { waitMs: number }
export type Rng = () => number;

export interface HumanInputParams {
  /** Pointer speed range; a value is drawn per move. */
  speedPxPerMs: [number, number];
  /** Total move duration clamps, ms. */
  minMoveMs: number;
  maxMoveMs: number;
  /** Nominal time between path samples, ms (jittered per step). */
  stepIntervalMs: [number, number];
  /** Max perpendicular bow of the curve, as a fraction of move distance. */
  curveFraction: number;
  /** Overshoot applies only to moves longer than this, px. */
  overshootMinDistancePx: number;
  /** Overshoot distance range, px. */
  overshootPx: [number, number];
  /** Randomized pause between arriving and pressing, ms. */
  preClickDwellMs: [number, number];
  /** How long the button stays down, ms. */
  clickHoldMs: [number, number];
}

export const HUMAN_INPUT_DEFAULTS: HumanInputParams = {
  speedPxPerMs: [1.1, 2.2],       // deliberate, below flick speed
  minMoveMs: 300,
  maxMoveMs: 1700,
  stepIntervalMs: [8, 16],
  curveFraction: 0.14,
  overshootMinDistancePx: 60,
  overshootPx: [1.5, 4],
  preClickDwellMs: [90, 380],
  clickHoldMs: [45, 130],
};

const rand = (rng: Rng, [lo, hi]: [number, number]) => lo + rng() * (hi - lo);
const clamp = (v: number, lo: number, hi: number) => Math.min(hi, Math.max(lo, v));
/** smootherstep: zero velocity at both ends, peak mid-path. */
const ease = (t: number) => t * t * t * (t * (t * 6 - 15) + 10);

/**
 * Plan one human-paced move from `from` to `to`. Pure: same rng sequence in,
 * same path out. The final step always lands exactly on `to`.
 */
export function planMousePath(
  from: Point,
  to: Point,
  params: HumanInputParams = HUMAN_INPUT_DEFAULTS,
  rng: Rng = Math.random,
): PathStep[] {
  const dx = to.x - from.x;
  const dy = to.y - from.y;
  const dist = Math.hypot(dx, dy);
  if (dist < 1) return [{ ...to, waitMs: rand(rng, params.preClickDwellMs) / 2 }];

  const speed = rand(rng, params.speedPxPerMs);
  const duration = clamp(dist / speed, params.minMoveMs, params.maxMoveMs);
  const stepMs = rand(rng, params.stepIntervalMs);
  const n = Math.max(6, Math.round(duration / stepMs));

  // Cubic Bezier control points with a random perpendicular bow.
  const ux = dx / dist, uy = dy / dist;
  const px = -uy, py = ux; // unit perpendicular
  const bow = (rng() * 2 - 1) * params.curveFraction * dist;
  const c1 = { x: from.x + dx / 3 + px * bow * rand(rng, [0.4, 1]), y: from.y + dy / 3 + py * bow * rand(rng, [0.4, 1]) };
  const c2 = { x: from.x + (2 * dx) / 3 + px * bow * rand(rng, [0.4, 1]), y: from.y + (2 * dy) / 3 + py * bow * rand(rng, [0.4, 1]) };
  const bez = (t: number): Point => {
    const m = 1 - t;
    return {
      x: m * m * m * from.x + 3 * m * m * t * c1.x + 3 * m * t * t * c2.x + t * t * t * to.x,
      y: m * m * m * from.y + 3 * m * m * t * c1.y + 3 * m * t * t * c2.y + t * t * t * to.y,
    };
  };

  const steps: PathStep[] = [];
  let prevEased = 0;
  for (let i = 1; i <= n; i++) {
    const eased = ease(i / n);
    const waitMs = Math.max(2, (eased - prevEased) * duration * rand(rng, [0.7, 1.3]));
    prevEased = eased;
    steps.push({ ...bez(i / n), waitMs });
  }

  // Overshoot + settle on longer moves: pass the target slightly along the
  // direction of travel, then converge onto the exact point.
  if (dist > params.overshootMinDistancePx) {
    const over = rand(rng, params.overshootPx);
    const overPoint = { x: to.x + ux * over, y: to.y + uy * over };
    const insertAt = Math.max(1, steps.length - 2);
    steps.splice(insertAt, 0, { ...overPoint, waitMs: rand(rng, [25, 60]) });
    steps.push({ x: to.x + ux * over * 0.4, y: to.y + uy * over * 0.4, waitMs: rand(rng, [30, 70]) });
  }
  steps.push({ ...to, waitMs: rand(rng, [20, 50]) });
  return steps;
}

/** Stateful dispatcher: remembers the pointer position between moves. */
export class HumanInput {
  private pos: Point;
  private readonly params: HumanInputParams;
  private readonly rng: Rng;
  private readonly cdp: CdpClient;
  private readonly sessionId: string;

  constructor(
    cdp: CdpClient,
    sessionId: string,
    opts: { params?: Partial<HumanInputParams>; rng?: Rng; startAt?: Point } = {},
  ) {
    this.cdp = cdp;
    this.sessionId = sessionId;
    this.params = { ...HUMAN_INPUT_DEFAULTS, ...opts.params };
    this.rng = opts.rng ?? Math.random;
    this.pos = opts.startAt ?? { x: 0, y: 0 };
  }

  get position(): Point { return { ...this.pos }; }

  async moveTo(x: number, y: number): Promise<void> {
    const steps = planMousePath(this.pos, { x, y }, this.params, this.rng);
    for (const s of steps) {
      await sleep(s.waitMs);
      await this.cdp.send("Input.dispatchMouseEvent",
        { type: "mouseMoved", x: Math.round(s.x), y: Math.round(s.y), button: "none" },
        this.sessionId);
    }
    this.pos = { x, y };
  }

  /** Randomized pause — before clicks, after navigations, between actions. */
  async dwell(range: [number, number] = this.params.preClickDwellMs): Promise<void> {
    await sleep(rand(this.rng, range));
  }

  async click(x: number, y: number, button: "left" | "right" | "middle" = "left"): Promise<void> {
    await this.moveTo(x, y);
    await this.dwell();
    await this.cdp.send("Input.dispatchMouseEvent",
      { type: "mousePressed", x, y, button, clickCount: 1 }, this.sessionId);
    await sleep(rand(this.rng, this.params.clickHoldMs));
    await this.cdp.send("Input.dispatchMouseEvent",
      { type: "mouseReleased", x, y, button, clickCount: 1 }, this.sessionId);
  }
}

/**
 * profile-store — the owner-held bundle. The only component allowed to touch
 * plaintext profile data. See docs/SECURITY_REVIEW.md before changing anything.
 *
 * Bundle layout (ARCHITECTURE.md):
 *   profile/          Layer 1 stored state (cookies, localStorage, IndexedDB subset)
 *   fingerprint.json  Layer 2 recipe: seed + explicit config
 *   network.json      Layer 3 pinned proxy assignment (reference, not credentials)
 *   manifest.json     versions, checksums, revoke state
 */
import { createCipheriv, createDecipheriv, randomBytes } from "node:crypto";
import { mkdir, readFile, writeFile, rm, stat } from "node:fs/promises";
import { join } from "node:path";

export interface FingerprintConfig {
  /** Seed for patched-Chromium builds (--fingerprint=<seed>). Stable per profile. */
  seed: number;
  userAgent?: string;
  /** --fingerprint-platform value: windows | linux | macos. */
  platform?: string;
  /** --fingerprint-brand value: Chrome | Edge | Opera | Vivaldi. */
  brand?: string;
  timezone?: string;
  locale?: string;
  viewport?: { width: number; height: number; deviceScaleFactor?: number };
  webglVendor?: string;
  webglRenderer?: string;
}

export interface ProfileBundle {
  manifest: {
    id: string;
    createdAt: string;
    updatedAt: string;
    revoked: boolean;
    /**
     * The designated human for this profile (product design, delight brief
     * §3): the one person a paused run routes its LOGIN_REQUIRED handoff to —
     * whoever receives this account's codes today. A name or handle the owner
     * chose at capture time; never a credential. Optional only so bundles
     * captured before the field existed still load.
     */
    designatedHuman?: string;
  };
  fingerprint: FingerprintConfig;
  network: { proxyRef: string; proxyUrl?: string; country?: string };
  /** Encrypted Layer-1 state payload (storageState JSON), never plaintext on disk. */
  encryptedState: string;
}

const ALGO = "aes-256-gcm";

function keyFromEnv(): Buffer {
  const raw = process.env.PROFILE_ENCRYPTION_KEY;
  if (!raw) throw new Error("PROFILE_ENCRYPTION_KEY is not set (see .env.example)");
  return Buffer.from(raw, "base64"); // must decode to 32 bytes
}

export function encryptState(plaintext: string): string {
  const iv = randomBytes(12);
  const cipher = createCipheriv(ALGO, keyFromEnv(), iv);
  const body = Buffer.concat([cipher.update(plaintext, "utf8"), cipher.final()]);
  return [iv.toString("base64"), cipher.getAuthTag().toString("base64"), body.toString("base64")].join(".");
}

export function decryptState(payload: string): string {
  const [iv, tag, body] = payload.split(".").map((s) => Buffer.from(s, "base64"));
  const decipher = createDecipheriv(ALGO, keyFromEnv(), iv);
  decipher.setAuthTag(tag);
  return Buffer.concat([decipher.update(body), decipher.final()]).toString("utf8");
}

async function exists(p: string): Promise<boolean> {
  try { await stat(p); return true; } catch { return false; }
}

export async function saveBundle(bundle: ProfileBundle, dir: string): Promise<void> {
  if (bundle.manifest.revoked) throw new Error("refusing to save a revoked bundle");
  await mkdir(dir, { recursive: true });
  await writeFile(join(dir, "manifest.json"), JSON.stringify(bundle.manifest, null, 2));
  await writeFile(join(dir, "fingerprint.json"), JSON.stringify(bundle.fingerprint, null, 2));
  await writeFile(join(dir, "network.json"), JSON.stringify(bundle.network, null, 2));
  await writeFile(join(dir, "state.enc"), bundle.encryptedState);
}

export async function loadBundle(dir: string): Promise<ProfileBundle> {
  if (await exists(dir + ".revoked.json")) {
    throw new Error(`bundle at ${dir} was revoked and destroyed`);
  }
  const manifest = JSON.parse(await readFile(join(dir, "manifest.json"), "utf8"));
  if (manifest.revoked) throw new Error(`bundle ${manifest.id} is marked revoked`);
  const fingerprint = JSON.parse(await readFile(join(dir, "fingerprint.json"), "utf8"));
  const network = JSON.parse(await readFile(join(dir, "network.json"), "utf8"));
  const encryptedState = await readFile(join(dir, "state.enc"), "utf8");
  return { manifest, fingerprint, network, encryptedState };
}

export async function revokeBundle(dir: string): Promise<void> {
  // Destroy, don't flag: overwrite the encrypted state, remove the bundle
  // directory, and leave only a tombstone so a later load fails loudly.
  const statePath = join(dir, "state.enc");
  if (await exists(statePath)) {
    await writeFile(statePath, randomBytes(256));
  }
  await rm(dir, { recursive: true, force: true });
  await writeFile(
    dir + ".revoked.json",
    JSON.stringify({ revokedAt: new Date().toISOString(), note: "bundle destroyed by owner revoke" }, null, 2),
  );
}

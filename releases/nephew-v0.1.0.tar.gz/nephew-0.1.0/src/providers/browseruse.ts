/**
 * Browser Use Cloud adapter — BASELINE environment.
 *
 * What it can hold constant (per FINGERPRINT_RESEARCH_FINDINGS.md §3):
 * Layer 1 state (their profile sync exists, but we apply OUR bundle state —
 * never their native profile persistence), plus CDP Emulation overrides
 * (UA/UA-CH, timezone, screen, locale) once connected.
 * What it cannot: canvas/WebGL/audio/font values — not exposed. Expect drift;
 * the drift numbers are the baseline evidence, not a surprise.
 */
import type { ProviderAdapter, Session } from "./index.ts";
import type { ProfileBundle } from "../profile-store.ts";

export const browserUseAdapter: ProviderAdapter = {
  name: "browseruse",
  async start(_bundle: ProfileBundle): Promise<Session> {
    const apiKey = process.env.BROWSER_USE_API_KEY;
    if (!apiKey) throw new Error("BROWSER_USE_API_KEY is not set (see .env.example)");
    // TODO(fable): create browser via the Browser Use API (X-Browser-Use-API-Key
    // header), WITHOUT a native profileId; connect over the returned CDP ws URL;
    // apply bundle state (storageState) + Emulation overrides from bundle.fingerprint.
    throw new Error("not implemented");
  },
};

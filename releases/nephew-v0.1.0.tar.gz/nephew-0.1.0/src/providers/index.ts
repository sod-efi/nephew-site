/**
 * providers — one adapter per execution environment, one interface.
 *
 * Hard rule (AGENTS.md #2): an adapter must NEVER fall back to a provider's
 * native persistent profile. That would fake the portability proof.
 * Adapters receive the bundle per run and hold nothing between runs.
 */
import type { ProfileBundle } from "../profile-store.ts";

export interface Session {
  /** CDP websocket endpoint for Playwright connectOverCDP. */
  cdpUrl: string;
  provider: string;
  close(): Promise<void>;
}

export interface ProviderAdapter {
  name: "browseruse" | "steel-cloud" | "own-stack";
  start(bundle: ProfileBundle): Promise<Session>;
}

export async function getAdapter(name: ProviderAdapter["name"]): Promise<ProviderAdapter> {
  switch (name) {
    case "browseruse":
      return (await import("./browseruse.ts")).browserUseAdapter;
    case "steel-cloud":
      return (await import("./steel.ts")).steelCloudAdapter;
    case "own-stack":
      return (await import("./own-stack.ts")).ownStackAdapter;
  }
}

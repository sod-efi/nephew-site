/**
 * Steel Cloud adapter — BASELINE environment (same control class as Browser Use:
 * session options + CDP; no custom binary, seed, or canvas/WebGL/font controls
 * documented). Self-hosted Steel is NOT this adapter — see own-stack.ts, where
 * CHROME_EXECUTABLE_PATH pointing at a patched Chromium is the hinge.
 */
import type { ProviderAdapter, Session } from "./index.ts";
import type { ProfileBundle } from "../profile-store.ts";

export const steelCloudAdapter: ProviderAdapter = {
  name: "steel-cloud",
  async start(_bundle: ProfileBundle): Promise<Session> {
    const apiKey = process.env.STEEL_API_KEY;
    if (!apiKey) throw new Error("STEEL_API_KEY is not set (see .env.example)");
    // TODO(fable): create Steel session (userAgent/proxyUrl from the bundle's
    // network assignment), connectOverCDP, apply bundle state + Emulation overrides.
    throw new Error("not implemented");
  },
};

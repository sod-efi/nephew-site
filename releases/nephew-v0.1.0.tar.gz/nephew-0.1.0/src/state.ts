/**
 * state — Layer 1 capture/restore: cookies + per-origin localStorage.
 *
 * Capture reads cookies at browser level (Storage.getCookies) and walks the
 * origins the workload touched, reading localStorage in each origin's own
 * context (the only place it can be read). Restore reverses both. The result
 * is the plaintext state JSON that profile-store encrypts into the bundle —
 * this module never writes it to disk.
 */
import type { CdpClient } from "./cdp.ts";
import { setTimeout as sleep } from "node:timers/promises";

export interface StoredOrigin {
  origin: string;
  localStorage: { name: string; value: string }[];
}

export interface StoredState {
  cookies: Record<string, unknown>[];
  origins: StoredOrigin[];
}

async function navigate(cdp: CdpClient, sessionId: string, url: string): Promise<void> {
  await cdp.send("Page.navigate", { url }, sessionId);
  await sleep(1200);
}

export async function captureState(
  cdp: CdpClient,
  sessionId: string,
  origins: string[],
): Promise<StoredState> {
  const { cookies } = await cdp.send("Storage.getCookies", {});
  const stored: StoredOrigin[] = [];
  for (const origin of origins) {
    await navigate(cdp, sessionId, origin + "/");
    const entries = await cdp.evaluate<{ name: string; value: string }[]>(
      sessionId,
      `Object.entries(localStorage).map(([name, value]) => ({ name, value }))`,
    );
    stored.push({ origin, localStorage: entries ?? [] });
  }
  return { cookies: cookies ?? [], origins: stored };
}

export async function restoreState(
  cdp: CdpClient,
  sessionId: string,
  state: StoredState,
): Promise<void> {
  if (state.cookies.length) {
    await cdp.send("Storage.setCookies", { cookies: state.cookies });
  }
  for (const o of state.origins) {
    await navigate(cdp, sessionId, o.origin + "/");
    for (const { name, value } of o.localStorage) {
      await cdp.evaluate(
        sessionId,
        `localStorage.setItem(${JSON.stringify(name)}, ${JSON.stringify(value)})`,
      );
    }
  }
}

/** Read back one origin's localStorage for verification. */
export async function readOriginStorage(
  cdp: CdpClient,
  sessionId: string,
  origin: string,
): Promise<{ name: string; value: string }[]> {
  await navigate(cdp, sessionId, origin + "/");
  return (
    (await cdp.evaluate<{ name: string; value: string }[]>(
      sessionId,
      `Object.entries(localStorage).map(([name, value]) => ({ name, value }))`,
    )) ?? []
  );
}

/**
 * with-profile — the TypeScript decorator/helper surface (delight brief §3,
 * Shape B): run a job function inside a carried, verified profile session.
 *
 *   import { withProfile } from "./src/with-profile.ts";
 *   await withProfile(bundleDir, "steel", async ({ cdp, sessionId }) => {
 *     // already logged in as the owner — no login code in this file
 *   });
 *
 * What it does, in order: load the owner-held bundle → open a provider
 * session (the same openers `nephew run` uses) → apply the bundle's
 * emulation overrides → FINGERPRINT GATE → restore the bundle state and
 * verify it (all of that is run-baseline's runInSession, reused, not
 * reimplemented) → hand the live page session to fn → capture the session
 * state back into the same bundle (cookies + per-origin localStorage, via
 * state.ts) → close the session.
 *
 * HONEST LIMITS of this subset (marked, not faked):
 *  1. Providers: steel + browseruse only. Modal is NOT supported here —
 *     its runner drives the browser from INSIDE the sandbox and exposes
 *     no host-side CDP session to hand to a job function. Use
 *     `nephew run --provider modal` for Modal. Calling withProfile with
 *     "modal" throws immediately and says exactly this.
 *  2. The handle is the baseline page session after restore+verify, left
 *     on the bundle's first origin. Multi-tab work, extra targets, and
 *     job navigation are the job function's own business (raw CDP).
 *  3. Capture-back covers the bundle's OWN origins (the Layer-1 subset
 *     every surface here carries: cookies are browser-wide; localStorage
 *     is per bundled origin). A login created mid-job on a NEW origin is
 *     not folded into the bundle by this helper — re-capture it with
 *     `nephew capture`.
 *  4. If fn throws, the session is closed WITHOUT capture-back: a failed
 *     job's half-mutated state never seals over the owner's bundle.
 */
import { decryptState, encryptState, loadBundle, saveBundle, type ProfileBundle } from "./profile-store.ts";
import type { CdpClient } from "./cdp.ts";
import { captureState, type StoredState } from "./state.ts";
import type { ProviderName } from "./cli/args.ts";
import {
  openBrowserUseSession, openSteelSession, runInSession,
  type BaselineOutcome, type OpenedProviderSession,
} from "./cli/run-baseline.ts";

/** The live, verified session handed to the job function. */
export interface ProfileSessionHandle {
  /** Raw CDP client for the provider session (the job drives from here). */
  cdp: CdpClient;
  /** The attached page session, with the profile restored + verified. */
  sessionId: string;
  bundle: ProfileBundle;
  provider: "steel" | "browseruse";
}

/** Thrown when the live fingerprint fails the bundle recipe's gate. */
export class ProfileGateError extends Error {
  readonly changed: string[];
  constructor(changed: string[]) {
    super(`fingerprint mismatch on: ${changed.join(", ")} — run refused before any state was released`);
    this.name = "ProfileGateError";
    this.changed = changed;
  }
}

/**
 * Thrown when the carried login does not hold — the structured pause from
 * the delight brief, as an error class with a machine-readable `status`
 * (the MCP surface returns the same shape as a result, not an error).
 */
export class LoginRequiredError extends Error {
  readonly status = "LOGIN_REQUIRED" as const;
  readonly designatedHuman?: string;
  constructor(bundle: ProfileBundle) {
    super(
      `LOGIN_REQUIRED — profile "${bundle.manifest.id}" did not verify as logged in; ` +
      `the designated human (${bundle.manifest.designatedHuman ?? "not recorded"}) re-captures with \`nephew capture\` and the job can be retried`,
    );
    this.name = "LoginRequiredError";
    this.designatedHuman = bundle.manifest.designatedHuman;
  }
}

export interface WithProfileOptions {
  /** Metrics-record job label (default "withProfile"). */
  job?: string;
  log?: (line: string) => void;
  /** Metrics directory override (tests); default the scaffold runs/. */
  runsDir?: string;
  /** Session-opener seam (tests). */
  openSession?: (provider: "steel" | "browseruse", log: (line: string) => void) => Promise<OpenedProviderSession>;
  /** In-session flow seam (tests). */
  runInSessionFn?: typeof runInSession;
}

export async function withProfile<T>(
  bundleDir: string,
  provider: ProviderName,
  fn: (session: ProfileSessionHandle) => Promise<T>,
  opts: WithProfileOptions = {},
): Promise<T> {
  if (provider === "modal") {
    throw new Error(
      "withProfile does not support provider \"modal\" yet: the modal runner drives its browser from inside the sandbox and exposes no host-side CDP session to hand a job function — use `nephew run --provider modal` (documented limit, src/with-profile.ts)",
    );
  }
  const log = opts.log ?? (() => {});
  const bundle = await loadBundle(bundleDir);
  const open = opts.openSession ?? ((p, l) => (p === "steel" ? openSteelSession(l) : openBrowserUseSession(l)));
  const session = await open(provider, log);
  try {
    const outcome: BaselineOutcome = await (opts.runInSessionFn ?? runInSession)(
      session.cdp, session.pageSessionId, opts.job ?? "withProfile", bundle,
      provider === "steel" ? "steel-cloud" : "browser-use-cloud", log,
      { runsDir: opts.runsDir },
    );
    if (!outcome.gateOk) throw new ProfileGateError(outcome.gateChanged);
    if (!outcome.verified) throw new LoginRequiredError(bundle);

    const result = await fn({ cdp: session.cdp, sessionId: session.pageSessionId, bundle, provider });

    // Capture-back: seal the job's session state into the same bundle,
    // so the next run — on either provider — continues from here.
    const state = JSON.parse(decryptState(bundle.encryptedState)) as StoredState;
    const captured = await captureState(session.cdp, session.pageSessionId, state.origins.map((o) => o.origin));
    await saveBundle({
      ...bundle,
      manifest: { ...bundle.manifest, updatedAt: new Date().toISOString() },
      encryptedState: encryptState(JSON.stringify(captured)),
    }, bundleDir);
    log(`captured    state sealed back into the owner bundle`);
    return result;
  } finally {
    await session.close();
  }
}

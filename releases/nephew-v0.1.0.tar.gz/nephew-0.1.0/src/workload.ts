/**
 * workload — the recurring logged-in job used for the proof.
 * Provider-blind: it receives a connected page and knows nothing about
 * adapters. The owner designates the real target + test account; until then
 * this stub defines the shape and the login checks every run must perform.
 */
export interface WorkloadResult {
  completed: boolean;
  loggedInAtStart: boolean;
  loggedInAtEnd: boolean;
  loginPrompts: number;
  mfaPrompts: number;
  blocksOrChallenges: number;
}

export async function runWorkload(_page: unknown): Promise<WorkloadResult> {
  // TODO(fable): navigate to the target, assert logged-in state WITHOUT
  // submitting credentials (a credential prompt = a counted failure signal,
  // not something to type into — test account handling per SECURITY_REVIEW),
  // perform the recurring job, re-check login state at the end.
  throw new Error("not implemented");
}

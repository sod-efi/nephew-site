#!/usr/bin/env python3
"""Bright Data zone isp_proxy2 CONNECT relay (daemon mode).

Fetches the zone password in-process via the custom.brightdata connector
surrogate (memory only — never printed, logged, or written), then serves a
local CONNECT relay on 127.0.0.1:<port argv[1]> that chains:
  client -> this VM's egress proxy -> brd.superproxy.io:33335 -> target
adding the zone's Proxy-Authorization on the second hop.

Usage: bd_relay.py <port>
Prints only "READY" (stderr) once listening.
"""
import base64
import os
import select
import socket
import sys
import threading
import urllib.request
from urllib.parse import urlparse

sys.path.insert(0, "/opt/muse/skills/custom-connector-setup/bin")
from dynamic_credentials import add_surrogate_to_request, read_json_response  # noqa: E402

import os
ZONE = os.environ.get("BD_ZONE", "isp_proxy2")
BD_HOST, BD_PORT = "brd.superproxy.io", 33335


def api_get(path: str):
    req = urllib.request.Request("https://api.brightdata.com" + path, method="GET")
    req.add_header("Accept", "application/json")
    add_surrogate_to_request(req, "custom.brightdata", entry_name="access_token",
                             allowed_hosts=["api.brightdata.com"])
    resp = urllib.request.urlopen(req, timeout=60)
    return read_json_response(resp)


def read_headers(sock: socket.socket) -> bytes:
    buf = b""
    while b"\r\n\r\n" not in buf:
        chunk = sock.recv(4096)
        if not chunk:
            raise ConnectionError("connection closed while reading headers")
        buf += chunk
        if len(buf) > 65536:
            raise ConnectionError("headers too large")
    return buf


def status_of(headers: bytes) -> int:
    try:
        return int(headers.split(b" ", 2)[1])
    except Exception:
        return -1


class Relay:
    def __init__(self, bd_auth: str):
        self.bd_auth = bd_auth
        env = os.environ.get("https_proxy") or os.environ.get("HTTPS_PROXY") or ""
        u = urlparse(env)
        self.egress_host = u.hostname
        self.egress_port = u.port or 3128
        self.egress_auth = None
        if u.username:
            raw = f"{u.username}:{u.password or ''}"
            self.egress_auth = "Basic " + base64.b64encode(raw.encode()).decode()

    def open_bd_tunnel(self) -> socket.socket:
        s = socket.create_connection((self.egress_host, self.egress_port), timeout=30)
        lines = [f"CONNECT {BD_HOST}:{BD_PORT} HTTP/1.1", f"Host: {BD_HOST}:{BD_PORT}"]
        if self.egress_auth:
            lines.append(f"Proxy-Authorization: {self.egress_auth}")
        s.sendall(("\r\n".join(lines) + "\r\n\r\n").encode())
        h = read_headers(s)
        if status_of(h) != 200:
            raise ConnectionError(f"egress CONNECT to BD proxy failed: {status_of(h)}")
        return s

    def handle(self, client: socket.socket):
        try:
            first = read_headers(client)
            head, _, rest = first.partition(b"\r\n\r\n")
            request_line = head.split(b"\r\n")[0].decode("latin1")
            parts = request_line.split(" ")
            if parts[0] != "CONNECT":
                client.sendall(b"HTTP/1.1 405 Method Not Allowed\r\n\r\n")
                return
            target = parts[1]
            upstream = self.open_bd_tunnel()
            lines = [f"CONNECT {target} HTTP/1.1", f"Host: {target}",
                     f"Proxy-Authorization: {self.bd_auth}"]
            upstream.sendall(("\r\n".join(lines) + "\r\n\r\n").encode())
            h = read_headers(upstream)
            code = status_of(h)
            if code != 200:
                client.sendall(b"HTTP/1.1 502 Bad Gateway\r\n\r\n".encode())
                print(f"BD CONNECT {target} -> {code}", file=sys.stderr)
                return
            client.sendall(b"HTTP/1.1 200 Connection Established\r\n\r\n")
            if rest:
                upstream.sendall(rest)
            self.splice(client, upstream)
        except Exception as e:  # noqa: BLE001
            print(f"relay error: {e}", file=sys.stderr)
            try:
                client.close()
            except Exception:
                pass

    @staticmethod
    def splice(a: socket.socket, b: socket.socket):
        # Proper half-close splicing: EOF from one side shuts down the
        # peer's write side and stops reads on the closed side, but the
        # peer may still be sending — keep pumping until it EOFs too or
        # the idle timeout hits. (The previous version returned on the
        # first EOF, closing both sockets and truncating in-flight data.)
        sockets = [a, b]
        try:
            while sockets:
                r, _, _ = select.select(sockets, [], [], 120)
                if not r:
                    break
                for s in r:
                    peer = b if s is a else a
                    try:
                        data = s.recv(65536)
                    except OSError:
                        data = b""
                    if not data:
                        try:
                            peer.shutdown(socket.SHUT_WR)
                        except OSError:
                            pass
                        if s in sockets:
                            sockets.remove(s)
                        continue
                    try:
                        peer.sendall(data)
                    except OSError:
                        if peer in sockets:
                            sockets.remove(peer)
                        if s in sockets:
                            sockets.remove(s)
        finally:
            for s in (a, b):
                try:
                    s.close()
                except Exception:
                    pass

    def serve(self, port: int):
        srv = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        srv.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
        srv.bind(("127.0.0.1", port))
        srv.listen(50)
        print("READY", file=sys.stderr, flush=True)
        while True:
            client, _ = srv.accept()
            threading.Thread(target=self.handle, args=(client,), daemon=True).start()


def main() -> int:
    port = int(sys.argv[1])
    status = api_get("/status")
    customer = status["customer"]
    zone = api_get(f"/zone?zone={ZONE}")
    password = zone["password"][0]
    username = f"brd-customer-{customer}-zone-{ZONE}"
    bd_auth = "Basic " + base64.b64encode(f"{username}:{password}".encode()).decode()
    Relay(bd_auth).serve(port)
    return 0


if __name__ == "__main__":
    sys.exit(main())

#!/usr/bin/env python3
"""
modal_bridge — the Modal half of `nephew run --provider modal`.

Why a Python bridge (design choice, recorded in memory.md 2026-10-30):
the TypeScript Modal SDK is not among this project's dependencies and
this build is offline, while the Modal Python SDK (modal 1.6.3) is
installed and verified on the host at ~/workspace/.venv-modal. The
scaffold already shells out to Python for the other two providers
(the vault-backed steel / browseruse CLIs in src/cli/run-baseline.ts),
so a small, dumb bridge keeps one pattern: TS owns the run logic,
Python owns the provider API call.

CO-LOCATION (the 2026-10-30 rebuild): the browser-driving step runs
INSIDE the sandbox, not from this host. The first Modal runner drove
the sandbox browser over its encrypted tunnel — and this host cannot
reach *.modal.host tunnel hosts at all (Node fetch, curl, and Python
all fail to connect, while sandbox creation succeeds in ~2.5 s). The
accepted fix: the sandbox image carries tools/modal_driver.py, which
drives Chromium over the sandbox's own loopback CDP and returns only
the structured result. The bridge's `run` action is the transport:
Sandbox.exec of the driver, request JSON on its stdin, one JSON line
back on its stdout.

Protocol: one JSON request object on stdin, exactly one JSON response
line on stdout, exit code 0 whenever a response was produced (failures
are {"ok": false, "error": ...} in the response, never a traceback on
stdout). Logs go to stderr only.

Credentials: the Modal SDK reads MODAL_TOKEN_ID / MODAL_TOKEN_SECRET
from this process's environment natively. They are never accepted as
request fields, never printed, and never written anywhere.

Actions:
  create    {action, chromiumArgs: [..], timeoutSec, appName?}
            -> {ok, sandboxId, cdpHttpUrl}
            Creates a Sandbox whose main process IS our patched
            Chromium (own-stack image plan below), with the CDP port
            exposed as an encrypted tunnel. The URL is returned for
            diagnostics only — nothing drives the browser through it;
            the driver works on loopback inside the sandbox.
  run       {action, sandboxId, driver: {...}, timeoutSec?}
            -> {ok, driver: {...}, driverStderr} | {ok: false, error, driverStderr}
            Executes the in-sandbox driver once (one probe OR restore
            phase per call — the host gates between them) and returns
            its parsed result line. The result also carries the tail
            of the driver's stderr: the driver's protocol is stdout
            only, so when it dies before printing (an import error in
            the sandbox, a missing file) stderr is the only evidence —
            discarding it made that failure invisible from the host.
  terminate {action, sandboxId} -> {ok}
  check     {action}
            -> {ok: true} | {ok: false, error: <exception class name only>}
            The `nephew init` connection check: one authenticated,
            read-only App.lookup. A missing app still proves the token
            pair authenticates (the run path creates the app on demand);
            an auth failure does not. Only the exception CLASS is ever
            returned — an error message could quote request material,
            and this bridge never carries secrets into its output.
"""
import json
import os
import sys
from pathlib import Path

CDP_PORT = 9222
DRIVER_REMOTE_PATH = "/opt/nephew/modal_driver.py"
DRIVER_LOCAL_PATH = Path(__file__).with_name("modal_driver.py")
DRIVER_DEFAULT_TIMEOUT_SEC = 300
# How much of the driver's stderr tail a `run` result carries back.
# Diagnostics only — bounded so a noisy driver cannot flood the host.
DRIVER_STDERR_TAIL_CHARS = 4000

# Own-stack image plan (docs/ARCHITECTURE.md): fingerprint-chromium in a
# fixed OS image with a pinned font pack. Release provenance: the spike
# (docs/SPIKE_RESULTS.md) — official Linux x86_64 release tarball of
# 150.0.7871.186, no compilation.
CHROMIUM_VERSION = "150.0.7871.186"
CHROMIUM_URL = (
    "https://github.com/adryfish/fingerprint-chromium/releases/download/"
    f"{CHROMIUM_VERSION}/ungoogled-chromium-{CHROMIUM_VERSION}-1-x86_64_linux.tar.xz"
)
CHROMIUM_DIR = "/opt/fingerprint-chromium"
CHROME_BIN = CHROMIUM_DIR + "/chrome"

# Chromium runtime libraries on Debian slim. The apt font families
# (fonts-liberation, fonts-dejavu-core) stay installed but are NOT the
# presented font set: the pinned pack below governs visibility through
# the baked fontconfig, exactly as FONTCONFIG_FILE does on the host.
# debian_slim carries Python 3 (Modal images do), which is all the
# in-sandbox driver needs — it is stdlib-only by design.
APT_PACKAGES = [
    "ca-certificates", "curl", "xz-utils", "fontconfig",
    "libnss3", "libnspr4", "libatk1.0-0", "libatk-bridge2.0-0",
    "libcups2", "libdrm2", "libxkbcommon0", "libxcomposite1",
    "libxdamage1", "libxfixes3", "libxrandr2", "libgbm1",
    "libasound2", "libpango-1.0-0", "libcairo2", "libatspi2.0-0",
    "fonts-liberation", "fonts-dejavu-core",
]

# The pinned font pack (windows-persona-pinned-v1, 18 fonts) is baked
# into the image: the font FILES at FONT_PACK_REMOTE_DIR, and the pack's
# fontconfig (tools/modal_fonts.conf — pack2.conf with sandbox paths)
# installed AS /etc/fonts/fonts.conf, so the sandbox browser resolves
# fonts through the pack only — the arrangement the host font-pack proof
# (runs/VERDICT-fontpack.md) validated under FONTCONFIG_FILE. The font
# files live outside git (binaries; the manifest — names, versions,
# sha256 — is recorded in the font-pack verdict), so the pack directory
# is a host path: NEPHEW_FONT_PACK_DIR overrides it, defaulting to the
# owner's ~/workspace/font-pack/fonts.
FONT_PACK_LOCAL_DIR = Path(
    os.environ.get(
        "NEPHEW_FONT_PACK_DIR",
        str(Path.home() / "workspace" / "font-pack" / "fonts"),
    )
)
FONT_PACK_REMOTE_DIR = "/opt/nephew/font-pack/fonts"
FONT_CONF_LOCAL_PATH = Path(__file__).with_name("modal_fonts.conf")
FONT_CONF_REMOTE_PATH = "/etc/fonts/fonts.conf"


def build_image(modal):
    return (
        modal.Image.debian_slim()
        .apt_install(*APT_PACKAGES)
        .run_commands(
            f"mkdir -p {CHROMIUM_DIR}",
            f"curl -fsSL {CHROMIUM_URL} | tar -xJ -C {CHROMIUM_DIR} --strip-components=1",
            f"{CHROME_BIN} --version",
        )
        # The in-sandbox driver ships with the image: any sandbox built
        # from it can be driven locally, with no host->tunnel CDP path.
        .add_local_file(str(DRIVER_LOCAL_PATH), DRIVER_REMOTE_PATH, copy=True)
        # The pinned font pack + its fontconfig (see the FONT_PACK_*
        # constants): fonts at /opt/nephew/font-pack/fonts, and the
        # pack conf AS /etc/fonts/fonts.conf so no system font leaks
        # into the browser's font set. fc-cache warms the cache under
        # the new conf; failure to warm is not fatal (fontconfig
        # rebuilds on first use), so it is guarded.
        .add_local_dir(str(FONT_PACK_LOCAL_DIR), FONT_PACK_REMOTE_DIR, copy=True)
        .add_local_file(str(FONT_CONF_LOCAL_PATH), FONT_CONF_REMOTE_PATH, copy=True)
        .run_commands("fc-cache -f >/dev/null 2>&1 || true")
    )


def create(modal, req):
    app = modal.App.lookup(req.get("appName") or "nephew-browser", create_if_missing=True)
    cmd = [CHROME_BIN, *req["chromiumArgs"]]
    sb = modal.Sandbox.create(
        *cmd,
        app=app,
        image=build_image(modal),
        encrypted_ports=[CDP_PORT],
        timeout=int(req.get("timeoutSec") or 600),
    )
    tunnel = sb.tunnels(timeout=60)[CDP_PORT]
    return {"ok": True, "sandboxId": sb.object_id, "cdpHttpUrl": tunnel.url}


def run(modal, req):
    sb = modal.Sandbox.from_id(req["sandboxId"])
    proc = sb.exec(
        "python3", DRIVER_REMOTE_PATH,
        timeout=int(req.get("timeoutSec") or DRIVER_DEFAULT_TIMEOUT_SEC),
    )
    proc.stdin.write(json.dumps(req["driver"]).encode())
    proc.stdin.write_eof()
    # Modal SDK StreamWriter buffers: write()/write_eof() only queue.
    # Without drain() nothing is ever sent — the driver blocks on its
    # stdin read until the exec timeout kills it, producing no output
    # on either stream (the silent 300 s probe failures of 2026-10-30).
    proc.stdin.drain()
    lines = []
    for line in proc.stdout:
        lines.append(line.decode() if isinstance(line, bytes) else line)
    err_lines = []
    for line in proc.stderr:
        err_lines.append(line.decode() if isinstance(line, bytes) else line)
    proc.wait()
    driver_stderr = "".join(err_lines)[-DRIVER_STDERR_TAIL_CHARS:]

    def failed(error):
        # Failure results fold a single-line copy of the stderr tail
        # into the error itself: that is the string the host CLI prints,
        # and on these paths it is the only place the evidence shows.
        tail = " ⏎ ".join(driver_stderr.strip().splitlines())
        return {
            "ok": False,
            "error": f"{error} — driver stderr: {tail}" if tail else error,
            "driverStderr": driver_stderr,
        }

    if not lines:
        return failed("in-sandbox driver produced no output")
    try:
        result = json.loads(lines[-1])
    except Exception:
        return failed("in-sandbox driver produced unparseable output")
    if not isinstance(result, dict) or not isinstance(result.get("ok"), bool):
        return failed("in-sandbox driver result had no ok flag")
    return {"ok": True, "driver": result, "driverStderr": driver_stderr}


def terminate(modal, req):
    modal.Sandbox.from_id(req["sandboxId"]).terminate()
    return {"ok": True}


def check(modal):
    # Read-only auth probe for `nephew init`. App.lookup with
    # create_if_missing=False changes nothing. NotFound means the pair
    # authenticated and the app simply does not exist yet — the run
    # path creates it on demand, so that is a pass. Anything else is
    # reported by exception class only (see the module docstring).
    try:
        modal.App.lookup("nephew-browser", create_if_missing=False)
        return {"ok": True, "detail": "app 'nephew-browser' found"}
    except Exception as e:  # noqa: BLE001 — class name is the whole report
        if type(e).__name__ == "NotFoundError":
            return {"ok": True, "detail": "authenticated (app is created on first run)"}
        return {"ok": False, "error": type(e).__name__}


def main():
    try:
        req = json.loads(sys.stdin.read())
        import modal  # deferred: a broken SDK install should still yield a JSON error

        if req.get("action") == "create":
            out = create(modal, req)
        elif req.get("action") == "check":
            out = check(modal)
        elif req.get("action") == "run":
            out = run(modal, req)
        elif req.get("action") == "terminate":
            out = terminate(modal, req)
        else:
            out = {"ok": False, "error": f"unknown bridge action: {req.get('action')!r}"}
    except Exception as e:  # one JSON line, first line of the message only
        out = {"ok": False, "error": str(e).split("\n")[0][:300]}
    print(json.dumps(out))
    return 0


if __name__ == "__main__":
    sys.exit(main())

/**
 * handoff/record — the plain JSON handoff event record.
 *
 * One file per handoff, at a documented path the receipts work can
 * consume without importing this module:
 *
 *   runs/handoffs/<YYYY-MM-DD>-<profile>-<handoffId>.json
 *
 * (relative to the scaffold root; overridable per session). The record
 * is written when the handoff starts (outcome "active") and rewritten
 * finalized at teardown. Identifiers, timestamps, and counts only —
 * never page content, frames, keystrokes, or profile state (AGENTS.md #3).
 */
import { mkdir, writeFile } from "node:fs/promises";
import { fileURLToPath } from "node:url";
import { join } from "node:path";
import type { HandoffEventRecord } from "./types.ts";

/** Default event-record directory: <scaffold>/runs/handoffs/. */
export function defaultHandoffEventDir(): string {
  return fileURLToPath(new URL("../../runs/handoffs/", import.meta.url));
}

export function handoffEventFileName(rec: Pick<HandoffEventRecord, "startedAt" | "profile" | "handoffId">): string {
  const day = rec.startedAt.slice(0, 10);
  const profile = rec.profile.replace(/[^a-zA-Z0-9_-]+/g, "-");
  return `${day}-${profile}-${rec.handoffId}.json`;
}

export async function writeHandoffRecord(
  rec: HandoffEventRecord,
  file: string,
): Promise<void> {
  await mkdir(join(file, ".."), { recursive: true });
  await writeFile(file, JSON.stringify(rec, null, 2) + "\n");
}

/**
 * receipts/run-receipt — signed proof/compliance receipts for runs
 * (productization item 6: the revoke receipt's Ed25519 construction,
 * extended from deletion to completed runs).
 *
 * At run end, finalizeRun() builds a RunReceipt from the run's identity +
 * metrics, digests every field individually, signs the canonical record
 * with the profile owner's receipt-signing key — the SAME key, file, and
 * construction as the deletion receipt (cli/revoke.ts): env
 * NEPHEW_RECEIPT_SIGNING_KEY_FILE, else ~/.nephew/receipt-signing-key.json
 * (mode 0600, created on first use, can decrypt nothing) — and stores it
 * under ~/.nephew/receipts/ (files mode 0600).
 *
 * Identifiers, hashes, and outcome counts only — never state, cookie
 * values, page content, or key material (AGENTS.md #3). A receipt proves
 * WHO ran WHAT, WHERE (provider, egress, fingerprint identity), and HOW
 * it ended. It does not carry the job's payload.
 *
 * verify() is the compliance check: structure, per-field digests, then
 * the Ed25519 signature. A tampered field is NAMED in the verdict — the
 * per-field digest map inside the signed record is what makes that
 * possible; a signature failure with all digests intact means the signer
 * envelope itself was forged and is reported as such.
 *
 * handoffUsed records whether the run paused for the profile's designated
 * human (LOGIN_REQUIRED handoff). The handoff module is landing
 * separately (src/handoff/); until its event record is wired into run
 * outcomes, finalizeRun takes the flag from its caller and defaults it to
 * false. See INTEGRATION.md.
 */
import { createHash, createPrivateKey, createPublicKey, sign, verify } from "node:crypto";
import { mkdir, readFile, writeFile } from "node:fs/promises";
import { homedir } from "node:os";
import { join } from "node:path";
import {
  loadOrCreateReceiptSigningKey,
  type ReceiptSigningKey,
} from "../cli/revoke.ts";

/** Fingerprint identity of the environment the run actually executed in. */
export interface RunEnvironment {
  canvasHash: string | null;
  audioHash: string | null;
  fontsHash: string | null;
}

export interface RunReceipt {
  type: "nephew.run-receipt";
  version: 1;
  /** Bundle / profile id (manifest id) the run carried. */
  profileId: string;
  /** The run's metrics-record id (measure.ts RunRecord.runId). */
  runId: string;
  /** Provider the run executed on: steel | browseruse | modal. */
  provider: string;
  /** Live fingerprint hashes from the run metrics, or null when the run produced none. */
  environment: RunEnvironment | null;
  /** Observed egress IP (the Layer-3 pin's public face), or null when unrecorded. */
  egressIp: string | null;
  startedAt: string; // ISO 8601
  endedAt: string; // ISO 8601
  /** Run outcome: the run-core outcome kind ("completed", "refused", …) or a job-level label. */
  outcome: string;
  humanAttentionMinutes: number;
  /** True when the run paused for the designated human (LOGIN_REQUIRED handoff). */
  handoffUsed: boolean;
  /**
   * sha256 of each content field's canonical JSON, keyed by field name.
   * Inside the signed record: lets verify() NAME a tampered field instead
   * of reporting a bare signature failure.
   */
  fieldDigests: Record<string, string>;
}

export interface SignedRunReceipt {
  receipt: RunReceipt;
  /** Ed25519 public key (SPKI, base64) the signature verifies against. */
  signingPublicKey: string;
  /** Ed25519 signature over the canonical receipt JSON (base64). */
  signature: string;
}

/** Content fields, in canonical construction order (fieldDigests excluded — it is derived). */
export const RUN_RECEIPT_FIELDS = [
  "type",
  "version",
  "profileId",
  "runId",
  "provider",
  "environment",
  "egressIp",
  "startedAt",
  "endedAt",
  "outcome",
  "humanAttentionMinutes",
  "handoffUsed",
] as const;

export type RunReceiptField = (typeof RUN_RECEIPT_FIELDS)[number];

type RunReceiptContent = Omit<RunReceipt, "fieldDigests">;

function fieldDigest(value: unknown): string {
  return createHash("sha256").update(JSON.stringify(value) ?? "undefined", "utf8").digest("hex");
}

/** Compute the digest map for a receipt's content fields, in canonical order. */
export function computeFieldDigests(content: RunReceiptContent): Record<string, string> {
  const digests: Record<string, string> = {};
  for (const field of RUN_RECEIPT_FIELDS) {
    digests[field] = fieldDigest(content[field]);
  }
  return digests;
}

/** Canonical form: the receipt's fields in a fixed construction order (same discipline as the deletion receipt). */
export function canonicalRunReceiptJson(receipt: RunReceipt): string {
  const digests: Record<string, string> = {};
  for (const field of RUN_RECEIPT_FIELDS) digests[field] = receipt.fieldDigests[field];
  return JSON.stringify({
    type: receipt.type,
    version: receipt.version,
    profileId: receipt.profileId,
    runId: receipt.runId,
    provider: receipt.provider,
    environment: receipt.environment,
    egressIp: receipt.egressIp,
    startedAt: receipt.startedAt,
    endedAt: receipt.endedAt,
    outcome: receipt.outcome,
    humanAttentionMinutes: receipt.humanAttentionMinutes,
    handoffUsed: receipt.handoffUsed,
    fieldDigests: digests,
  });
}

export function signRunReceipt(receipt: RunReceipt, key: ReceiptSigningKey): SignedRunReceipt {
  const priv = createPrivateKey({ key: Buffer.from(key.privateKeyPkcs8, "base64"), format: "der", type: "pkcs8" });
  const signature = sign(null, Buffer.from(canonicalRunReceiptJson(receipt), "utf8"), priv);
  return { receipt, signingPublicKey: key.publicKeySpki, signature: signature.toString("base64") };
}

// ---------------------------------------------------------------------------
// verify
// ---------------------------------------------------------------------------

export interface RunReceiptVerdict {
  ok: boolean;
  status: "PASS" | "FAIL";
  /** Fields whose value, presence, or type does not match the signed record. */
  tamperedFields: string[];
  /** Human-readable reason (empty on PASS). */
  reason: string;
}

const pass = (): RunReceiptVerdict => ({ ok: true, status: "PASS", tamperedFields: [], reason: "" });
const fail = (reason: string, tamperedFields: string[] = []): RunReceiptVerdict => ({
  ok: false, status: "FAIL", tamperedFields, reason,
});

function isPlainObject(v: unknown): v is Record<string, unknown> {
  return typeof v === "object" && v !== null && !Array.isArray(v);
}

const ENVIRONMENT_KEYS = ["canvasHash", "audioHash", "fontsHash"] as const;

/** Per-field type/shape check; returns a problem description or null. */
function fieldProblem(field: RunReceiptField, value: unknown): string | null {
  switch (field) {
    case "type":
      return value === "nephew.run-receipt" ? null : `field "type" must be "nephew.run-receipt"`;
    case "version":
      return value === 1 ? null : `field "version" must be 1`;
    case "profileId":
    case "runId":
    case "provider":
    case "startedAt":
    case "endedAt":
    case "outcome":
      return typeof value === "string" && value.length > 0
        ? null
        : `field "${field}" must be a non-empty string`;
    case "egressIp":
      return value === null || (typeof value === "string" && value.length > 0)
        ? null
        : `field "egressIp" must be a non-empty string or null`;
    case "humanAttentionMinutes":
      return typeof value === "number" && Number.isFinite(value) && value >= 0
        ? null
        : `field "humanAttentionMinutes" must be a finite number >= 0`;
    case "handoffUsed":
      return typeof value === "boolean" ? null : `field "handoffUsed" must be a boolean`;
    case "environment": {
      if (value === null) return null;
      if (!isPlainObject(value)) return `field "environment" must be an object or null`;
      for (const k of Object.keys(value)) {
        if (!(ENVIRONMENT_KEYS as readonly string[]).includes(k)) {
          return `field "environment" carries unexpected key "${k}"`;
        }
      }
      for (const k of ENVIRONMENT_KEYS) {
        if (!(k in value)) return `field "environment" is missing "${k}"`;
        const v = value[k];
        if (v !== null && typeof v !== "string") {
          return `field "environment.${k}" must be a string or null`;
        }
      }
      return null;
    }
  }
}

/**
 * Verify a signed run receipt: envelope → field presence/shape → per-field
 * digests (names any tampered field) → Ed25519 signature. Pure — no I/O.
 */
export function verifyRunReceipt(signed: unknown): RunReceiptVerdict {
  if (!isPlainObject(signed)) return fail("receipt envelope is not an object");
  for (const k of ["receipt", "signingPublicKey", "signature"] as const) {
    if (!(k in signed)) return fail(`receipt envelope is missing "${k}"`, [k]);
  }
  for (const k of Object.keys(signed)) {
    if (!["receipt", "signingPublicKey", "signature"].includes(k)) {
      return fail(`receipt envelope carries unexpected key "${k}"`, [k]);
    }
  }
  if (typeof signed.signingPublicKey !== "string" || signed.signingPublicKey.length === 0) {
    return fail(`envelope field "signingPublicKey" must be a non-empty string`, ["signingPublicKey"]);
  }
  if (typeof signed.signature !== "string" || signed.signature.length === 0) {
    return fail(`envelope field "signature" must be a non-empty string`, ["signature"]);
  }

  const receipt = signed.receipt;
  if (!isPlainObject(receipt)) return fail(`envelope field "receipt" is not an object`, ["receipt"]);

  // Presence (missing fields are named, never silently defaulted) and shape.
  const problems: string[] = [];
  const badFields: string[] = [];
  for (const field of RUN_RECEIPT_FIELDS) {
    if (!(field in receipt)) {
      problems.push(`field "${field}" is missing`);
      badFields.push(field);
      continue;
    }
    const problem = fieldProblem(field, receipt[field]);
    if (problem) {
      problems.push(problem);
      badFields.push(field);
    }
  }
  for (const k of Object.keys(receipt)) {
    if (!(RUN_RECEIPT_FIELDS as readonly string[]).includes(k) && k !== "fieldDigests") {
      problems.push(`receipt carries unexpected field "${k}"`);
      badFields.push(k);
    }
  }
  if (!("fieldDigests" in receipt)) {
    problems.push(`field "fieldDigests" is missing`);
    badFields.push("fieldDigests");
  } else if (!isPlainObject(receipt.fieldDigests)) {
    problems.push(`field "fieldDigests" must be an object`);
    badFields.push("fieldDigests");
  }
  if (problems.length) return fail(problems.join("; "), badFields);

  const r = receipt as unknown as RunReceipt;

  // Per-field digests: name exactly the fields that changed since signing.
  const tampered: string[] = [];
  for (const field of RUN_RECEIPT_FIELDS) {
    if (r.fieldDigests[field] !== fieldDigest(r[field])) tampered.push(field);
  }
  for (const k of Object.keys(r.fieldDigests)) {
    if (!(RUN_RECEIPT_FIELDS as readonly string[]).includes(k)) tampered.push(`fieldDigests.${k}`);
  }
  if (tampered.length) {
    return fail(`field(s) altered since signing: ${tampered.join(", ")}`, tampered);
  }

  // Signature over the canonical record.
  try {
    const pub = createPublicKey({
      key: Buffer.from(signed.signingPublicKey as string, "base64"), format: "der", type: "spki",
    });
    const okSig = verify(
      null,
      Buffer.from(canonicalRunReceiptJson(r), "utf8"),
      pub,
      Buffer.from(signed.signature as string, "base64"),
    );
    if (!okSig) {
      return fail("signature does not verify against signingPublicKey (fields match their digests — the signer envelope was forged or re-signed with another key)");
    }
  } catch {
    return fail("signature does not verify against signingPublicKey (malformed key or signature)");
  }
  return pass();
}

/** Read a receipt file and verify it. Never throws on bad content — the verdict carries the failure. */
export async function verifyRunReceiptFile(path: string): Promise<RunReceiptVerdict> {
  let raw: string;
  try {
    raw = await readFile(path, "utf8");
  } catch (e) {
    return fail(`cannot read receipt file: ${e instanceof Error ? e.message : String(e)}`);
  }
  let parsed: unknown;
  try {
    parsed = JSON.parse(raw);
  } catch {
    return fail("receipt file is not valid JSON");
  }
  return verifyRunReceipt(parsed);
}

// ---------------------------------------------------------------------------
// finalize
// ---------------------------------------------------------------------------

/** The slice of a run metrics record (measure.ts RunRecord) a receipt consumes. */
export interface RunMetricsSlice {
  fingerprint?: Partial<Record<(typeof ENVIRONMENT_KEYS)[number], string>> | null;
  egressIp?: string | null;
  humanAttentionMinutes?: number;
}

export interface FinalizeRunInput {
  profileId: string;
  runId: string;
  provider: string;
  outcome: string;
  startedAt: string | Date;
  endedAt: string | Date;
  /** Explicit fingerprint identity; wins over metrics.fingerprint. Null records "no environment captured". */
  environment?: RunEnvironment | null;
  /** Explicit egress; wins over metrics.egressIp. */
  egressIp?: string | null;
  /** Explicit attention; wins over metrics.humanAttentionMinutes. Default 0. */
  humanAttentionMinutes?: number;
  /** True when the run paused for the designated human. Default false (see header note). */
  handoffUsed?: boolean;
  /** Run metrics record (or slice) to draw environment/egress/attention from. */
  metrics?: RunMetricsSlice | null;
  /** Owner receipt-signing key file. Default: env NEPHEW_RECEIPT_SIGNING_KEY_FILE, else ~/.nephew/receipt-signing-key.json (the revoke receipt's key). */
  signingKeyFile?: string;
  /** Storage directory. Default: env NEPHEW_RECEIPTS_DIR, else ~/.nephew/receipts. */
  receiptsDir?: string;
  env?: NodeJS.ProcessEnv;
}

export interface FinalizeRunResult {
  signed: SignedRunReceipt;
  /** Where the signed receipt was written (mode 0600). */
  receiptPath: string;
}

function toIso(t: string | Date): string {
  const d = t instanceof Date ? t : new Date(t);
  if (Number.isNaN(d.getTime())) throw new Error(`invalid timestamp: ${String(t)}`);
  return d.toISOString();
}

function environmentFromMetrics(metrics: RunMetricsSlice | null | undefined): RunEnvironment | null {
  const fp = metrics?.fingerprint;
  if (!fp) return null;
  const env: RunEnvironment = {
    canvasHash: fp.canvasHash ?? null,
    audioHash: fp.audioHash ?? null,
    fontsHash: fp.fontsHash ?? null,
  };
  return env.canvasHash === null && env.audioHash === null && env.fontsHash === null ? null : env;
}

function safeName(s: string): string {
  return s.replace(/[^A-Za-z0-9._-]+/g, "-");
}

/**
 * Finalize a run: build its receipt, sign it with the owner's
 * receipt-signing key, store it under the receipts dir (mode 0600), and
 * return the signed receipt + path. Throws on missing/invalid required
 * input — a run that cannot be receipted should fail loudly at the call
 * site, not silently skip its compliance record.
 */
export async function finalizeRun(input: FinalizeRunInput): Promise<FinalizeRunResult> {
  for (const field of ["profileId", "runId", "provider", "outcome"] as const) {
    const v = input[field];
    if (typeof v !== "string" || v.length === 0) {
      throw new Error(`finalizeRun: "${field}" is required (non-empty string)`);
    }
  }
  const env = input.env ?? process.env;
  const content: RunReceiptContent = {
    type: "nephew.run-receipt",
    version: 1,
    profileId: input.profileId,
    runId: input.runId,
    provider: input.provider,
    environment:
      input.environment !== undefined ? input.environment : environmentFromMetrics(input.metrics),
    egressIp: input.egressIp !== undefined ? input.egressIp : (input.metrics?.egressIp ?? null),
    startedAt: toIso(input.startedAt),
    endedAt: toIso(input.endedAt),
    outcome: input.outcome,
    humanAttentionMinutes:
      input.humanAttentionMinutes ?? input.metrics?.humanAttentionMinutes ?? 0,
    handoffUsed: input.handoffUsed ?? false,
  };
  if (
    typeof content.humanAttentionMinutes !== "number" ||
    !Number.isFinite(content.humanAttentionMinutes) ||
    content.humanAttentionMinutes < 0
  ) {
    throw new Error(`finalizeRun: "humanAttentionMinutes" must be a finite number >= 0`);
  }
  const receipt: RunReceipt = { ...content, fieldDigests: computeFieldDigests(content) };

  const signingKeyFile =
    input.signingKeyFile ??
    env.NEPHEW_RECEIPT_SIGNING_KEY_FILE ??
    join(homedir(), ".nephew", "receipt-signing-key.json");
  const key = await loadOrCreateReceiptSigningKey(signingKeyFile);
  const signed = signRunReceipt(receipt, key);

  const receiptsDir = input.receiptsDir ?? env.NEPHEW_RECEIPTS_DIR ?? join(homedir(), ".nephew", "receipts");
  await mkdir(receiptsDir, { recursive: true, mode: 0o700 });
  const fileName = `${safeName(content.startedAt.slice(0, 10))}-${safeName(content.profileId)}-${safeName(content.runId)}.run-receipt.json`;
  const receiptPath = join(receiptsDir, fileName);
  await writeFile(receiptPath, JSON.stringify(signed, null, 2), { mode: 0o600 });
  return { signed, receiptPath };
}

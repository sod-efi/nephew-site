# nephew — the Python package

Run Python jobs inside your own portable browser profile: the same
carried identity the TypeScript helper offers, with the same
fingerprint gate and the same signed run receipts.

This package is a thin driver over the Nephew CLI's `nephew bridge`
stdio command. The session itself — bundle, gate, state restore,
capture-back, signed receipts — lives in the CLI, so the Python side
holds no keys, stores nothing, and never sees the bundle. Install
Nephew first (the CLI provides the bridge); this package finds it via
`NEPHEW_CLI` or `nephew` on your PATH.

## Install

From a Nephew release tree (the `python/` directory of the tarball):

```sh
pip install ./python
```

Requires Python 3.10+. No dependencies of its own — Playwright is
**not** required (see the pattern below).

## Use

Context manager:

```python
from nephew import with_profile

with with_profile(bundle="/path/to/bundle", provider="steel") as session:
    # session.cdp_url is the live session's CDP endpoint, already
    # logged in as the profile owner. Drive it with anything that
    # speaks CDP. With Playwright (not a dependency — your choice):
    from playwright.sync_api import sync_playwright

    with sync_playwright() as pw:
        browser = pw.chromium.connect_over_cdp(session.cdp_url)
        page = browser.contexts[0].pages[0]
        ...

# On exit: the live state is captured back into the bundle, the
# session closes, and a signed run receipt is issued —
# session.receipt_path names it (verify with `nephew receipt verify`).
```

Decorator — the wrapped function receives the session first:

```python
from nephew import with_profile

@with_profile(bundle="/path/to/bundle", provider="browseruse")
def nightly_recon(session):
    ...  # session.cdp_url, session.session_id — no login code here

nightly_recon()
```

## The pause and the gate

- The carried login does not hold → entering raises
  `LoginRequiredError`, the structured LOGIN_REQUIRED pause: it
  carries the full payload (`status`, `profile`, `designated_human`,
  `receipt_path`) so your agent can route the re-capture to the
  profile's designated human and retry.
- The live fingerprint fails the bundle's gate → `GateRefusedError`
  with the `changed` elements. Nothing ran; no state was released.
- Your job raises → the session still closes (without capture-back —
  a failed job's half-mutated state never seals over the bundle) and
  the original exception propagates.

## Environment

Inherited as-is by the bridge — the same rules as the CLI:
`PROFILE_ENCRYPTION_KEY` and your provider keys are read from the
environment only and are never stored by this package. `NEPHEW_CLI`
overrides how the CLI is located.

## Limits, stated plainly

- Providers: Steel + Browser Use, exactly like the TS helper. Modal
  exposes no host-side CDP session and stays CLI-only:
  `nephew run --provider modal`.
- Capture-back covers the bundle's own origins (cookies are
  browser-wide; localStorage is per bundled origin) — the same
  Layer-1 subset every Nephew surface carries.

Tests: `python3 -m unittest discover -s tests` from this directory
(the bridge is stubbed; no provider account needed).

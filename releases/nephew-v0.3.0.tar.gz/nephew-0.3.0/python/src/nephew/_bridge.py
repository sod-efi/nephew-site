"""Bridge subprocess client — speaks the `nephew bridge` JSON-lines
protocol (see src/cli/python-bridge.ts in the Nephew source tree).

One JSON object per line over the child's stdin/stdout. The child's
stderr is inherited on purpose: the bridge's human-facing output (the
trust receipt, run logs) belongs on the user's terminal, exactly like
the CLI — only the protocol travels these pipes.
"""
from __future__ import annotations

import json
import subprocess
from typing import Optional


class BridgeProcess:
    def __init__(self, cli: str):
        self._proc = subprocess.Popen(
            [cli, "bridge"],
            stdin=subprocess.PIPE,
            stdout=subprocess.PIPE,
            text=True,
            bufsize=1,
        )

    def send(self, obj: dict) -> None:
        assert self._proc.stdin is not None
        self._proc.stdin.write(json.dumps(obj) + "\n")
        self._proc.stdin.flush()

    def read_event(self) -> Optional[dict]:
        """The next protocol event, or None when the bridge has exited."""
        assert self._proc.stdout is not None
        line = self._proc.stdout.readline()
        if not line:
            return None
        return json.loads(line)

    def reap(self, timeout: float = 30) -> Optional[int]:
        """Wait for the bridge to exit; terminate, then kill, if it won't."""
        try:
            rc: Optional[int] = self._proc.wait(timeout=timeout)
        except subprocess.TimeoutExpired:
            self._proc.terminate()
            try:
                rc = self._proc.wait(timeout=5)
            except subprocess.TimeoutExpired:
                self._proc.kill()
                rc = self._proc.wait()
        for stream in (self._proc.stdin, self._proc.stdout):
            try:
                if stream is not None:
                    stream.close()
            except OSError:
                pass
        return rc

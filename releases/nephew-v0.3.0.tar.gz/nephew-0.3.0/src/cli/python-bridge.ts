/**
 * cli/python-bridge — `nephew bridge`: the Python bridge (stdio,
 * JSON lines). This is NOT a user surface: it exists so the `nephew`
 * Python package (python/) can offer Python jobs the exact surface
 * withProfile offers TypeScript jobs — same carried identity, same
 * fingerprint gate, same signed run receipts — without a second
 * implementation of any of it. The bridge is a thin protocol shell
 * over src/with-profile.ts's openProfileSession / LiveProfileSession;
 * the Python side holds no keys, stores nothing, and never sees the
 * bundle.
 *
 * Protocol (one JSON object per line; stdout is the protocol, so ALL
 * human-facing output — the trust receipt, run logs — goes to stderr):
 *
 *   → {"type":"start","bundle":"<dir>","provider":"steel","job":"<label>"?}
 *   ← {"type":"ready","cdpUrl":"…","sessionId":"…","profile":"<id>",
 *      "provider":"steel","job":"<label>"}
 *        The session is live and verified. cdpUrl is the provider-issued
 *        CDP endpoint (ws or http) — a session capability: it crosses
 *        ONLY this channel to the owner's own driver process, and is
 *        never logged, recorded, or receipted (SECURITY_REVIEW rule 4).
 *   ← {"type":"refused","status":"REFUSED","reason":"fingerprint-mismatch",
 *      "job","provider","profile","changed":[…],"receiptPath":"…"|null}
 *        Terminal: the gate refused before any state was released.
 *   ← {"type":"login_required","status":"LOGIN_REQUIRED","job","provider",
 *      "profile","designatedHuman":…,"handoff":null,"action":"…",
 *      "receiptPath":"…"|null}
 *        Terminal: the structured pause, mirroring the MCP profile_run
 *        result shape. This surface holds no live handoff (the session
 *        is closed, exactly as the TS helper's LoginRequiredError path
 *        closes it), so handoff is null and the action is re-capture.
 *   → {"type":"close","ok":true}          the job finished cleanly
 *   → {"type":"close","ok":false,"error":"…"}   the job raised
 *   ← {"type":"finalized","outcome":"completed"|"job-failed",
 *      "capturedBack":true|false,"receiptPath":"…"|null}
 *        Terminal. ok:true captured the live state back into the
 *        bundle before closing; ok:false captured nothing.
 *   ← {"type":"error","message":"…"}     Terminal failure (no session,
 *        or the session could not be finalized). No receipt is issued
 *        for a start that never carried a profile — the same rule
 *        run-core keeps for its failed / not-connected outcomes.
 *
 * A driver that vanishes (stdin EOF) aborts the session: closed
 * WITHOUT capture-back and receipted "job-failed" — a dead driver
 * never seals its half-mutated state over the owner's bundle.
 *
 * Providers: steel + browseruse, like the TS helper. Modal stays
 * CLI-only (its runner exposes no host-side CDP session) — a modal
 * start returns the helper's documented-limit error verbatim.
 *
 * Exit codes: 0 a terminal outcome was emitted (ready→finalized,
 * refused, login_required) · 1 an error event · 2 protocol violation.
 */
import { createInterface } from "node:readline";
import {
  openProfileSession, LoginRequiredError, ProfileGateError,
  type LiveProfileSession, type WithProfileOptions,
} from "../with-profile.ts";
import { PROVIDERS, type ProviderName } from "./args.ts";

export interface PythonBridgeDeps {
  env?: NodeJS.ProcessEnv;
  /**
   * Session-lifecycle seams (tests) — forwarded to openProfileSession,
   * which is also where the fake provider sessions in the withProfile
   * tests plug in.
   */
  sessionOpts?: Pick<WithProfileOptions, "openSession" | "runInSessionFn" | "runsDir" | "finalizeRunFn">;
}

export interface BridgeIo {
  /** One protocol event per call (a single JSON line, no newline). */
  write: (line: string) => void;
  /** Human-facing lines — trust receipt + run logs. Never the protocol. */
  err: (line: string) => void;
}

function firstLine(e: unknown): string {
  return (e instanceof Error ? e.message : String(e)).split("\n")[0];
}

export async function runPythonBridge(
  lines: AsyncIterable<string>,
  io: BridgeIo,
  deps: PythonBridgeDeps = {},
): Promise<number> {
  const env = deps.env ?? process.env;
  const log = (line: string) => io.err(line);
  const emit = (event: Record<string, unknown>) => io.write(JSON.stringify(event));
  let live: LiveProfileSession | null = null;

  for await (const raw of lines) {
    const line = raw.trim();
    if (!line) continue;
    let msg: any;
    try {
      msg = JSON.parse(line);
    } catch {
      emit({ type: "error", message: "malformed JSON line — the bridge speaks one JSON object per line" });
      if (live) await live.abort().catch(() => { /* the protocol error is the outcome */ });
      return 2;
    }

    if (!live) {
      if (msg?.type !== "start") {
        emit({ type: "error", message: `unexpected message "${String(msg?.type)}" — the bridge waits for a start` });
        return 2;
      }
      const provider = (PROVIDERS as readonly string[]).includes(msg.provider)
        ? (msg.provider as ProviderName)
        : null;
      if (!provider || typeof msg.bundle !== "string" || !msg.bundle) {
        emit({ type: "error", message: "start needs { bundle: <dir>, provider: steel|browseruse|modal }" });
        return 2;
      }
      const job = typeof msg.job === "string" && msg.job ? msg.job : "python";
      try {
        live = await openProfileSession(msg.bundle, provider, {
          job, log, env, ...(deps.sessionOpts ?? {}),
        });
      } catch (e) {
        if (e instanceof ProfileGateError) {
          emit({
            type: "refused", status: "REFUSED", reason: "fingerprint-mismatch",
            job, provider, profile: e.profileId, changed: e.changed, receiptPath: e.receiptPath,
          });
          return 0;
        }
        if (e instanceof LoginRequiredError) {
          emit({
            type: "login_required", status: "LOGIN_REQUIRED",
            job, provider, profile: e.profileId,
            designatedHuman: e.designatedHuman ?? null,
            handoff: null,
            action: "the designated human re-captures the login (`nephew capture`) — the job can then be retried unchanged",
            receiptPath: e.receiptPath,
          });
          return 0;
        }
        emit({ type: "error", message: firstLine(e) });
        return 1;
      }
      if (!live.handle.cdpUrl) {
        await live.abort().catch(() => { /* an endpoint-less session is unusable either way */ });
        emit({ type: "error", message: "the provider session exposed no CDP endpoint for the bridge" });
        return 1;
      }
      emit({
        type: "ready",
        cdpUrl: live.handle.cdpUrl,
        sessionId: live.handle.sessionId,
        profile: live.bundle.manifest.id,
        provider,
        job,
      });
      continue;
    }

    // A session is live: the only legal next message is its close.
    if (msg?.type === "close") {
      const ok = msg.ok !== false;
      try {
        const { receiptPath } = ok ? await live.complete() : await live.abort();
        emit({ type: "finalized", outcome: ok ? "completed" : "job-failed", capturedBack: ok, receiptPath });
      } catch (e) {
        emit({ type: "error", message: firstLine(e) });
        return 1;
      }
      return 0;
    }
    emit({ type: "error", message: `unexpected message "${String(msg?.type)}" — the bridge waits for close` });
    await live.abort().catch(() => { /* the protocol error is the outcome */ });
    return 2;
  }

  // stdin EOF with a live session: the driver vanished mid-job.
  if (live) {
    const { receiptPath } = await live.abort().catch(() => ({ receiptPath: null }));
    emit({ type: "finalized", outcome: "job-failed", capturedBack: false, receiptPath });
  }
  return 0;
}

/** Serve the bridge on stdio until the session ends. Logs go to stderr — stdout is the protocol. */
export async function servePythonBridgeStdio(deps: PythonBridgeDeps = {}): Promise<number> {
  const rl = createInterface({ input: process.stdin });
  return runPythonBridge(rl, {
    write: (line) => { process.stdout.write(line + "\n"); },
    err: (line) => { console.error(line); },
  }, deps);
}

/**
 * cli/capture — `nephew capture`: the local capture from the delight brief.
 *
 * The owner lends their own browser: a seeded fingerprint-chromium window
 * opens on THIS machine, the owner logs in to their sites exactly as they
 * normally would (password manager, MFA, passkeys — untouched by us), and
 * on their confirmation the CLI captures the resulting session — cookies +
 * per-origin localStorage, via src/state.ts, the same capture the runs use —
 * into a NEW encrypted owner-held bundle (src/profile-store.ts). Nothing is
 * recorded except the resulting session state; plaintext state exists only
 * in this process's memory and is sealed under the owner's key before the
 * browser closes.
 *
 * Three one-idea steps in the terminal, per the brief:
 *   1 — Your logins (name the profile + its designated human, then log in)
 *   2 — Review (the inventory: origins + counts; remove a site by hostname)
 *   3 — Where it lives (the sealed bundle, its location, how to run it)
 *
 * The recipe is measured, not invented: after capture, the live browser's
 * fingerprint is probed (src/fingerprint.ts) and pinned into the bundle —
 * user agent, timezone, screen, WebGL strings — alongside the launch seed.
 * The designated human (who a paused run calls on) is recorded in the
 * bundle manifest at capture time.
 */
import { randomInt } from "node:crypto";
import { rm, stat } from "node:fs/promises";
import { homedir } from "node:os";
import { join } from "node:path";
import { launchChromium, type LaunchedBrowser } from "../cdp.ts";
import { captureFingerprint } from "../fingerprint.ts";
import { encryptState, saveBundle, type FingerprintConfig, type ProfileBundle } from "../profile-store.ts";
import { captureState, type StoredState } from "../state.ts";
import { launchArgsFor } from "../providers/own-stack.ts";
import { loadNephewConfig, nephewConfigPath } from "./config.ts";
import type { CaptureCommand } from "./args.ts";

export interface CaptureIo {
  out: (line: string) => void;
  err: (line: string) => void;
  ask: (question: string) => Promise<string>;
}

export interface CaptureDeps {
  env?: NodeJS.ProcessEnv;
  /** Browser launcher seam (tests); default cdp.launchChromium. */
  launch?: typeof launchChromium;
  /** Where named profiles live; default ~/.nephew/profiles. */
  profilesRoot?: string;
  /** How capture waits for the owner to finish logging in (tests). */
  waitForDone?: (browser: LaunchedBrowser, ask: CaptureIo["ask"]) => Promise<void>;
  now?: () => Date;
}

export interface CaptureResult {
  bundleDir: string;
  bundleId: string;
  designatedHuman: string;
  origins: string[];
  cookieCount: number;
  storageEntries: number;
  seed: number;
}

async function exists(p: string): Promise<boolean> {
  try { await stat(p); return true; } catch { return false; }
}

/** Port base, pid-derived like the own-stack adapter's (orphan safety). */
function capturePort(): number {
  return 9700 + (process.pid % 200);
}

function platformFromUserAgent(ua: string): string | undefined {
  if (/windows/i.test(ua)) return "windows";
  if (/macintosh|mac os/i.test(ua)) return "macos";
  if (/linux/i.test(ua)) return "linux";
  return undefined;
}

/** Default wait: the owner presses Enter here, or simply closes the window. */
async function defaultWaitForDone(browser: LaunchedBrowser, ask: CaptureIo["ask"]): Promise<void> {
  const closed = new Promise<void>((resolve) => {
    browser.process.once("exit", () => resolve());
  });
  await Promise.race([ask(""), closed]);
}

export async function runCapture(cmd: CaptureCommand, io: CaptureIo, deps: CaptureDeps = {}): Promise<CaptureResult> {
  const env = deps.env ?? process.env;
  const now = deps.now ?? (() => new Date());
  const profilesRoot = deps.profilesRoot ?? join(homedir(), ".nephew", "profiles");

  if (!env.PROFILE_ENCRYPTION_KEY) {
    throw new Error(
      "PROFILE_ENCRYPTION_KEY is not set — capture seals the bundle under your key; generate one locally (e.g. `openssl rand -base64 32`), keep it in your password manager / OS keychain, and export it before running capture",
    );
  }
  const chromePath = env.OWN_STACK_CHROME_PATH ?? env.NEPHEW_CHROME_PATH;
  if (!chromePath) {
    throw new Error("no capture browser configured — set OWN_STACK_CHROME_PATH to the fingerprint-chromium binary (the same binary the runs use)");
  }

  // ------------------------------------------------ Step 1 — your logins
  io.out("Step 1 of 3 — Your logins");
  const name = cmd.name ?? (await io.ask("Profile name (e.g. ben-main): ")).trim();
  if (!name) throw new Error("capture needs a profile name");
  const human = cmd.human ?? (await io.ask("Designated human — who should a paused run call on for this profile? ")).trim();
  if (!human) throw new Error("capture needs a designated human — the person a LOGIN_REQUIRED pause routes to");
  const bundleDir = cmd.bundleDir ?? join(profilesRoot, name);
  if (await exists(bundleDir) || await exists(bundleDir + ".revoked.json")) {
    throw new Error(`a bundle already exists at ${bundleDir} — pick a new --name, or revoke the old one first (nephew revoke)`);
  }
  const seed = cmd.seed ?? randomInt(1, 2_147_483_647);

  // The recipe being born: seed first; the rest is measured after login.
  const draft: ProfileBundle = {
    manifest: { id: name, createdAt: now().toISOString(), updatedAt: now().toISOString(), revoked: false, designatedHuman: human },
    fingerprint: { seed },
    network: { proxyRef: "none-capture" },
    encryptedState: "",
  };
  const userDataDir = join(profilesRoot, ".staging", `${name}-${process.pid}`);
  const args = launchArgsFor(draft, userDataDir).filter((a) => a !== "--headless=new");
  io.out("A browser window is opening. Log in to the sites your agents should");
  io.out("act on — the way you normally would. We never see your passwords;");
  io.out("only the logged-in state is captured, on the next step.");
  io.out("Press Enter here when you're done (or just close the window).");
  const browser = await (deps.launch ?? launchChromium)(chromePath, args, capturePort());
  try {
    await (deps.waitForDone ?? defaultWaitForDone)(browser, io.ask);

    // --------------------------------------------- Step 2 — review the take
    io.out("");
    io.out("Step 2 of 3 — Review");
    const { targetInfos } = await browser.cdp.send("Target.getTargets");
    const origins = new Set<string>();
    for (const t of targetInfos ?? []) {
      if (t.type !== "page" || !t.url) continue;
      try {
        const u = new URL(t.url as string);
        if (u.protocol === "http:" || u.protocol === "https:") origins.add(u.origin);
      } catch { /* non-URL target */ }
    }
    for (const site of cmd.sites) {
      try { origins.add(new URL(site).origin); } catch { throw new Error(`--sites entry "${site}" is not a URL`); }
    }
    if (origins.size === 0) {
      throw new Error("no sites were visited in the capture window — nothing to capture");
    }
    let state: StoredState = await captureState(browser.cdp, browser.sessionId, [...origins]);
    for (;;) {
      const storageEntries = state.origins.reduce((n, o) => n + o.localStorage.length, 0);
      io.out(`Captured ${state.cookies.length} cookies · ${storageEntries} stored entries across:`);
      for (const o of state.origins) io.out(`  ${new URL(o.origin).hostname} — ${o.localStorage.length} stored entries`);
      const drop = (await io.ask("Remove a site? Type its hostname, or press Enter to keep all: ")).trim();
      if (!drop) break;
      const before = state.origins.length;
      state = {
        origins: state.origins.filter((o) => new URL(o.origin).hostname !== drop),
        cookies: state.cookies.filter((c) => !String((c as { domain?: string }).domain ?? "").replace(/^\./, "").endsWith(drop)),
      };
      io.out(state.origins.length < before ? `Removed ${drop} — it never enters the bundle.` : `No captured site matches "${drop}".`);
      if (state.origins.length === 0) throw new Error("all sites removed — nothing left to capture");
    }

    // Measure the device this profile now is, and pin it as the recipe.
    const fpLive = await captureFingerprint(browser.cdp, browser.sessionId, state.origins[0].origin + "/");
    const [w, h] = (fpLive.screen || "").split("x").map(Number);
    const fingerprint: FingerprintConfig = {
      seed,
      ...(fpLive.userAgent ? { userAgent: fpLive.userAgent } : {}),
      ...(platformFromUserAgent(fpLive.userAgent) ? { platform: platformFromUserAgent(fpLive.userAgent) } : {}),
      brand: "Chrome",
      ...(fpLive.timezone ? { timezone: fpLive.timezone } : {}),
      ...(w > 0 && h > 0 ? { viewport: { width: w, height: h, deviceScaleFactor: 1 } } : {}),
      ...(fpLive.webglVendor ? { webglVendor: fpLive.webglVendor } : {}),
      ...(fpLive.webglRenderer ? { webglRenderer: fpLive.webglRenderer } : {}),
    };

    // ------------------------------------------ Step 3 — where it lives
    io.out("");
    io.out("Step 3 of 3 — Where it lives");
    // Pin the egress from the customer's init config when Bright Data is set up.
    let network = draft.network;
    const config = await loadNephewConfig(nephewConfigPath(env));
    const bd = config?.providers.brightdata;
    if (bd?.zone) {
      network = { proxyRef: `brightdata-zone-${bd.zone}`, proxyUrl: "http://brd.superproxy.io:33335" };
    }
    const bundle: ProfileBundle = {
      manifest: draft.manifest,
      fingerprint,
      network,
      encryptedState: encryptState(JSON.stringify(state)),
    };
    await saveBundle(bundle, bundleDir);
    const storageEntries = state.origins.reduce((n, o) => n + o.localStorage.length, 0);
    io.out(`Profile "${name}" is encrypted and stored in your vault: ${bundleDir}`);
    io.out(`Designated human: ${human} — a paused run routes its handoff to them.`);
    io.out(`Egress: ${network.proxyRef}${bd?.zone ? " (pinned via your Bright Data zone)" : " (unpinned — run nephew init to pin a dedicated IP)"}.`);
    io.out(`Run it anywhere: nephew run <job> --provider steel|browseruse|modal|browserbase --bundle ${bundleDir}`);
    return {
      bundleDir, bundleId: name, designatedHuman: human,
      origins: state.origins.map((o) => o.origin),
      cookieCount: state.cookies.length, storageEntries, seed,
    };
  } finally {
    await browser.close();
    // The staging profile dir holds the session in plaintext Chromium
    // storage — the sealed bundle is the only copy that may survive.
    await rm(userDataDir, { recursive: true, force: true });
  }
}

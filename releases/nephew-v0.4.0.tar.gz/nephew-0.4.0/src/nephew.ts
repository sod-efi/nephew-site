/**
 * nephew — the one-command CLI for the portable browser profile
 * (decision: ../2026-10-29-nephew-cli-decision.md).
 *
 *   nephew init                                                        connect your own provider accounts
 *   nephew capture [--name <id>] [--human <who>] [--bundle <dir>]      capture a profile in your local browser
 *   nephew run <job> --provider steel|browseruse|modal|browserbase [--dry-run] [--bundle <dir>] [--handoff]
 *   nephew revoke [--bundle <dir>] [--key-file <file>] [--receipt <file>]
 *   nephew receipt verify <file>                                       verify a signed run receipt
 *   nephew mcp                                                         MCP server (stdio): profile_run
 *   nephew bridge                                                      Python bridge (stdio): with_profile sessions for the Python package
 *
 * Happy path asks ZERO questions: bundle defaults resolve from env /
 * the standard location, the trust receipt prints before anything starts,
 * and a fingerprint mismatch refuses the run before the job. Exit codes:
 * 0 ok · 1 run failed / refused · 2 usage error · 3 modal not connected.
 */
import { createInterface } from "node:readline/promises";
import { homedir } from "node:os";
import { join } from "node:path";
import { pathToFileURL } from "node:url";
import { loadBundle } from "./profile-store.ts";
import {
  parseCliArgs, modalConnectionProblem, USAGE, RUN_USAGE, REVOKE_USAGE, INIT_USAGE, CAPTURE_USAGE, MCP_USAGE, RECEIPT_USAGE, BRIDGE_USAGE,
  type RunCommand, type RevokeCommand, type InitCommand, type CaptureCommand, type ReceiptVerifyCommand,
} from "./cli/args.ts";
import { verifyRunReceiptFile } from "./receipts/run-receipt.ts";
import { revokeWithReceipt } from "./cli/revoke.ts";
import { formatReceipt, buildRunPlan, planHeader } from "./cli/receipt.ts";
import { runProfileJob, defaultBundleDir } from "./cli/run-core.ts";
import { runInit, type InitDeps } from "./cli/init.ts";
import { runCapture, type CaptureDeps } from "./cli/capture.ts";
import { serveMcpStdio, type McpDeps } from "./mcp/server.ts";
import { servePythonBridgeStdio, type PythonBridgeDeps } from "./cli/python-bridge.ts";

export interface CliIo {
  out: (line: string) => void;
  err: (line: string) => void;
  env: NodeJS.ProcessEnv;
  /** Interactive prompt seam (init/capture). Default: readline on stdio. */
  ask?: (question: string) => Promise<string>;
}

/** Test seams for the interactive / server commands. */
export interface MainDeps {
  init?: InitDeps;
  capture?: CaptureDeps;
  mcp?: McpDeps;
  bridge?: PythonBridgeDeps;
  /** Run-core seam (tests) — `nephew run` without a live provider. */
  run?: typeof runProfileJob;
}

let sharedRl: ReturnType<typeof createInterface> | undefined;
function defaultAsk(question: string): Promise<string> {
  sharedRl ??= createInterface({ input: process.stdin, output: process.stdout });
  return sharedRl.question(question);
}

const defaultIo: CliIo = {
  out: (line) => console.log(line),
  err: (line) => console.error(line),
  env: process.env,
  ask: defaultAsk,
};

function firstLine(e: unknown): string {
  return (e instanceof Error ? e.message : String(e)).split("\n")[0];
}

async function runCommand(cmd: RunCommand, io: CliIo, deps: MainDeps = {}): Promise<number> {
  // Modal gate first: one clear line, nothing else, when the pair is absent.
  if (cmd.provider === "modal") {
    const problem = modalConnectionProblem(io.env);
    if (problem) {
      io.err(problem);
      return 3;
    }
  }

  const bundleDir = cmd.bundleDir ?? defaultBundleDir(io.env);

  if (cmd.dryRun) {
    let bundle;
    try {
      bundle = await loadBundle(bundleDir);
    } catch (e) {
      io.err(`nephew: could not load a bundle at ${bundleDir} — ${firstLine(e)}`);
      return 1;
    }
    // Trust receipt — before anything starts, on every path.
    for (const line of formatReceipt(bundle)) io.out(line);
    const planInput = { job: cmd.job, provider: cmd.provider, bundle, bundleDir, dryRun: cmd.dryRun };
    io.out(planHeader(planInput));
    buildRunPlan(planInput).forEach((step, i) => io.out(`  ${i + 1}. ${step}`));
    return 0;
  }

  const outcome = await (deps.run ?? runProfileJob)(
    {
      job: cmd.job, provider: cmd.provider, bundleDir, env: io.env, log: io.out,
      ...(cmd.handoff ? { handoff: { enabled: true, ttlMs: cmd.handoff.ttlMs, port: cmd.handoff.port } } : {}),
    },
  );
  switch (outcome.kind) {
    case "not-connected":
      io.err(outcome.message);
      return 3;
    case "failed":
      io.err(outcome.message);
      return 1;
    case "refused":
      io.out(`stopped     fingerprint mismatch on: ${outcome.changed.join(", ")} — run refused before the job started`);
      return 1;
    case "login-required": {
      io.out(`✗ failed    state restore did not verify in the ${cmd.provider} session`);
      if (outcome.handoffUnavailable && cmd.handoff) {
        io.out(`handoff     unavailable — ${outcome.handoffUnavailable}; re-capture with \`nephew capture\` instead`);
      }
      if (outcome.handoff && outcome.handoffSession) {
        // The handoff lines (URL, token, deadline) were already printed
        // by run-core as it started; the CLI stays with the pause until
        // the human hands back, ends it, or the deadline expires it.
        io.out(`handoff     waiting — this run is paused until ${outcome.handoff.designatedHuman} hands control back or the deadline passes`);
        const rec = await outcome.handoffSession.waitForOutcome();
        if (rec.outcome === "resumed") {
          io.out(`handoff     resumed by ${rec.designatedHuman} — the fixed login is sealed in the bundle; re-run the job to continue`);
        } else if (rec.outcome === "ended") {
          io.out(`handoff     ended by ${rec.designatedHuman} — nothing was captured back`);
        } else if (rec.outcome === "expired") {
          io.out(`handoff     expired at ${rec.expiresAt} — nothing was captured back; re-capture with \`nephew capture\``);
        } else {
          io.out(`handoff     aborted — nothing was captured back`);
        }
      }
      return 1;
    }
    case "completed":
      io.out(`✓ done      ${cmd.job} · logged in the whole run · 0 prompts · ${(outcome.latencyMs / 1000).toFixed(1)}s in-session`);
      return 0;
  }
}

async function revokeCommand(cmd: RevokeCommand, io: CliIo): Promise<number> {
  const bundleDir = cmd.bundleDir ?? defaultBundleDir(io.env);
  const signingKeyFile =
    io.env.NEPHEW_RECEIPT_SIGNING_KEY_FILE ?? join(homedir(), ".nephew", "receipt-signing-key.json");
  try {
    const { signed, receiptPath } = await revokeWithReceipt({
      bundleDir,
      signingKeyFile,
      keyFile: cmd.keyFile,
      receiptCopyPath: cmd.receiptFile,
    });
    io.out(`revoked     ${signed.receipt.bundleId} · bundle destroyed at ${bundleDir}`);
    for (const copy of signed.receipt.copies) {
      io.out(`destroyed   ${copy.kind} · ${copy.location}`);
    }
    io.out(`receipt     signed deletion receipt: ${cmd.receiptFile ?? receiptPath}`);
    return 0;
  } catch (e) {
    io.err(`nephew: revoke failed — ${firstLine(e)}`);
    return 1;
  }
}

async function initCommand(_cmd: InitCommand, io: CliIo, deps: MainDeps): Promise<number> {
  try {
    const outcome = await runInit(
      { out: io.out, err: io.err, ask: io.ask ?? defaultAsk },
      { env: io.env, ...(deps.init ?? {}) },
    );
    return outcome.code;
  } catch (e) {
    io.err(`nephew: init failed — ${firstLine(e)}`);
    return 1;
  }
}

async function captureCommand(cmd: CaptureCommand, io: CliIo, deps: MainDeps): Promise<number> {
  try {
    await runCapture(cmd, { out: io.out, err: io.err, ask: io.ask ?? defaultAsk }, { env: io.env, ...(deps.capture ?? {}) });
    return 0;
  } catch (e) {
    io.err(`nephew: capture failed — ${firstLine(e)}`);
    return 1;
  }
}

async function receiptVerifyCommand(cmd: ReceiptVerifyCommand, io: CliIo): Promise<number> {
  const verdict = await verifyRunReceiptFile(cmd.file);
  if (verdict.ok) {
    io.out(`PASS        ${cmd.file} — signature valid, all fields intact`);
    return 0;
  }
  io.out(`FAIL        ${cmd.file} — ${verdict.reason}`);
  return 1;
}

const HELP_TEXT: Record<string, string> = {
  run: RUN_USAGE, revoke: REVOKE_USAGE, init: INIT_USAGE, capture: CAPTURE_USAGE, mcp: MCP_USAGE, receipt: RECEIPT_USAGE, bridge: BRIDGE_USAGE,
};

export async function main(
  argv: string[] = process.argv.slice(2),
  io: CliIo = defaultIo,
  deps: MainDeps = {},
): Promise<number> {
  const parsed = parseCliArgs(argv);
  if (!parsed.ok) {
    io.err(`nephew: ${parsed.error}`);
    io.err(parsed.error.startsWith("unknown command") ? USAGE : HELP_TEXT[argv[0]] ?? RUN_USAGE);
    return 2;
  }
  if (parsed.value.command === "help") {
    io.out(parsed.value.topic ? HELP_TEXT[parsed.value.topic] : USAGE);
    return 0;
  }
  if (parsed.value.command === "revoke") return revokeCommand(parsed.value, io);
  if (parsed.value.command === "receipt") return receiptVerifyCommand(parsed.value, io);
  if (parsed.value.command === "init") return initCommand(parsed.value, io, deps);
  if (parsed.value.command === "capture") return captureCommand(parsed.value, io, deps);
  if (parsed.value.command === "mcp") {
    await serveMcpStdio({ env: io.env, ...(deps.mcp ?? {}) });
    return 0;
  }
  if (parsed.value.command === "bridge") {
    return servePythonBridgeStdio({ env: io.env, ...(deps.bridge ?? {}) });
  }
  return runCommand(parsed.value, io, deps);
}

const isMain = process.argv[1] !== undefined && import.meta.url === pathToFileURL(process.argv[1]).href;
if (isMain) {
  main().then(
    (code) => { process.exitCode = code; },
    (e) => { console.error(`nephew: ${firstLine(e)}`); process.exitCode = 1; },
  );
}

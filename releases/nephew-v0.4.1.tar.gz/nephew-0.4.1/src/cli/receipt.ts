/**
 * cli/receipt — the trust receipt, the fingerprint gate, and the run plan.
 *
 * The receipt is the 3 lines from the delight brief printed BEFORE a run
 * starts: whose profile (bundle id), which fingerprint (short hash of the
 * bundle's fingerprint recipe), and the pinned egress (Layer-3 network pin).
 * Identifiers and hashes only — never state, cookies, or proxy credentials
 * (AGENTS.md #3, SECURITY_REVIEW rule 4).
 *
 * The gate reuses fingerprint.ts: a live capture in the provider session is
 * diffed (diffFingerprints) against the capture the bundle's recipe SHOULD
 * produce. Only recipe-pinned elements gate — userAgent / timezone / screen,
 * the ones CDP Emulation actually controls in a managed cloud. Computed
 * elements (canvas/WebGL/audio/fonts) drift in managed clouds by design
 * (the baselines measured exactly that); they are recorded, not gated.
 */
import { createHash } from "node:crypto";
import type { ProfileBundle } from "../profile-store.ts";
import { diffFingerprints, type FingerprintCapture } from "../fingerprint.ts";
import type { ProviderName } from "./args.ts";

/** Short stable identifier for the bundle's fingerprint recipe. */
export function fingerprintHash(bundle: ProfileBundle): string {
  const fp = bundle.fingerprint;
  const canonical = JSON.stringify({
    seed: fp.seed,
    userAgent: fp.userAgent ?? null,
    platform: fp.platform ?? null,
    brand: fp.brand ?? null,
    timezone: fp.timezone ?? null,
    locale: fp.locale ?? null,
    viewport: fp.viewport ?? null,
    webglVendor: fp.webglVendor ?? null,
    webglRenderer: fp.webglRenderer ?? null,
  });
  return createHash("sha256").update(canonical).digest("hex").slice(0, 10);
}

/** True when the bundle's Layer-3 pin names a Bright Data zone. */
export function isBrightDataPin(bundle: ProfileBundle): boolean {
  return /bright\s*-?\s*data/i.test(bundle.network.proxyRef) || /brightdata/i.test(bundle.network.proxyUrl ?? "");
}

/** Display form of the egress pin — host only if a URL is present, never userinfo. */
export function egressDisplay(bundle: ProfileBundle): string {
  const ref = bundle.network.proxyRef;
  if (/^none/i.test(ref)) return `${ref} · unpinned`;
  if (isBrightDataPin(bundle)) return `${ref} · pinned · local relay`;
  if (bundle.network.proxyUrl) {
    try {
      const u = new URL(bundle.network.proxyUrl);
      return `${ref} · pinned · ${u.protocol}//${u.host}`;
    } catch {
      return `${ref} · pinned`;
    }
  }
  return `${ref} · pinned`;
}

/** The 3-line trust receipt. Exactly three lines, in brief order. */
export function formatReceipt(bundle: ProfileBundle): string[] {
  const fp = bundle.fingerprint;
  const persona = [fp.platform, fp.brand].filter(Boolean).join("/");
  return [
    `profile     ${bundle.manifest.id} · owner-held bundle · loaded from your vault`,
    `fingerprint ${fingerprintHash(bundle)} · seed ${fp.seed}${persona ? ` · ${persona}` : ""}`,
    `egress      ${egressDisplay(bundle)}`,
  ];
}

/**
 * The capture the bundle's recipe should produce, for the elements the
 * recipe pins. Unpinned elements are copied from the live capture so they
 * can never appear as "changed" — the diff then names exactly the pinned
 * elements that failed to hold.
 */
export function expectedCapture(bundle: ProfileBundle, live: FingerprintCapture): FingerprintCapture {
  const fp = bundle.fingerprint;
  return {
    ...live,
    userAgent: fp.userAgent ?? live.userAgent,
    timezone: fp.timezone ?? live.timezone,
    screen: fp.viewport ? `${fp.viewport.width}x${fp.viewport.height}` : live.screen,
  };
}

export interface FingerprintGate {
  ok: boolean;
  /** Pinned elements that failed to hold (empty when ok). */
  changed: string[];
  /** Full diff vs the recipe-expected capture (drift record). */
  diff: { changed: string[]; unchanged: string[] };
}

/** Gate a live session capture against the bundle recipe. Reuses diffFingerprints. */
export function fingerprintGate(bundle: ProfileBundle, live: FingerprintCapture): FingerprintGate {
  const diff = diffFingerprints(expectedCapture(bundle, live), live);
  return { ok: diff.changed.length === 0, changed: diff.changed, diff };
}

export interface RunPlanInput {
  job: string;
  provider: ProviderName;
  bundle: ProfileBundle;
  bundleDir: string;
  dryRun: boolean;
}

/** The ordered steps a run will take — printed by --dry-run, followed live. */
export function buildRunPlan(input: RunPlanInput): string[] {
  const { job, provider, bundle, bundleDir } = input;
  const fp = bundle.fingerprint;
  const overrides: string[] = [];
  if (fp.userAgent) overrides.push("user agent");
  if (fp.timezone) overrides.push(`timezone ${fp.timezone}`);
  if (fp.locale) overrides.push(`locale ${fp.locale}`);
  if (fp.viewport) overrides.push(`screen ${fp.viewport.width}x${fp.viewport.height}`);

  const isModal = provider === "modal";
  const providerStep =
    provider === "steel"
      ? "create steel session (vault CLI, default project, 10 min timeout)"
      : provider === "browseruse"
        ? "create browseruse session (vault CLI)"
        : provider === "browserbase"
          ? "create browserbase session (vault CLI, key-only, 1 h session window requested)"
          : "create modal sandbox (own-stack patched Chromium, bundle seed; the driver runs inside the sandbox)";

  const steps: string[] = [
    isModal
      ? `load bundle ${bundle.manifest.id} from ${bundleDir} (profile-store; state is decrypted on this host only and crosses into the sandbox only after the fingerprint gate holds)`
      : `load bundle ${bundle.manifest.id} from ${bundleDir} (profile-store; state stays sealed until the session is live)`,
    providerStep,
    isModal
      ? "the in-sandbox driver attaches to the sandbox's local browser (loopback CDP — nothing drives it from this host)"
      : "connect over CDP and attach to the page target",
  ];
  if (overrides.length) steps.push(`apply bundle emulation overrides (${overrides.join(", ")})`);
  steps.push("capture fingerprint and gate on the recipe-pinned elements (userAgent, timezone, screen) — mismatch stops the run before the job");
  if (isBrightDataPin(bundle)) {
    steps.push(`network: pin ${bundle.network.proxyRef} — route the session through the local Bright Data relay (bd_relay pattern)`);
  } else if (!/^none/i.test(bundle.network.proxyRef)) {
    steps.push(`network: egress pin ${bundle.network.proxyRef}`);
  }
  steps.push(
    isModal
      ? "only after the gate holds: hand the decrypted bundle state to the in-sandbox driver, which restores cookies + per-origin localStorage locally"
      : "decrypt the bundle state (PROFILE_ENCRYPTION_KEY) and restore cookies + per-origin localStorage",
    isModal
      ? "the driver verifies the restore on every bundled origin (localStorage + cookie counts) and returns the result — that verification is the job"
      : "verify the restore on every bundled origin (localStorage + cookie counts) — that verification is the job",
    ...(isModal
      ? ["capture the verified state back from the driver and re-seal it into the owner bundle (the sandbox is destroyed next)"]
      : []),
    `record the run in runs/ (TEST_PLAN format) as job "${job}"`,
    provider === "steel"
      ? "release the steel session"
      : provider === "browseruse"
        ? "stop the browseruse session"
        : provider === "browserbase"
          ? "release the browserbase session"
          : "terminate the modal sandbox",
  );
  return steps;
}

/** Header line for plan output (dry-run and live pre-flight share it). */
export function planHeader(input: RunPlanInput): string {
  return input.dryRun
    ? `plan        nephew run ${input.job} --provider ${input.provider} (dry run — no session created)`
    : `plan        nephew run ${input.job} --provider ${input.provider}`;
}

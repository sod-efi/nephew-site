/**
 * cli/run-core — the one run path behind every surface: `nephew run`
 * (src/nephew.ts) and the MCP `profile_run` tool (src/mcp/server.ts) both
 * call runProfileJob, so the trust receipt, the fingerprint gate, and the
 * outcome semantics can never drift between surfaces.
 *
 * Outcome mapping (the delight brief's failure shape):
 *   gate mismatch        → "refused" — nothing ran, no state was released.
 *   restore did not verify → "login-required" — the carried login did not
 *     hold in the provider session. The CLI prints its failure line; the
 *     MCP surface returns this as the structured LOGIN_REQUIRED pause
 *     (a pause, not an exception), naming the bundle's designated human.
 *   verified             → "completed".
 *
 * Handoff (src/handoff/): when the caller enables it, a login-required
 * run on steel/browseruse/browserbase keeps its live provider session and starts a
 * streamed human handoff over it — run-core emits a `handoff_required`
 * signal with the control handle (input.onHandoffRequired + the
 * outcome's handoff / handoffSession fields). A resumed handoff captures
 * the live state back into the owner bundle before the session closes;
 * an ended/expired one captures nothing. Modal exposes no host-side CDP
 * session, so a Modal pause carries `handoffUnavailable` instead of a
 * handle (documented limit, src/handoff/README.md). With handoff not
 * requested, every path behaves exactly as before.
 *
 * Run receipts (src/receipts/): every terminal outcome that carried a
 * profile (completed / refused / login-required) is receipted exactly
 * once — a signed proof record via receipts.finalizeRun, issued through
 * the shared issueRunReceipt() helper below, which can never change the
 * outcome: on failure
 * it logs one line and the run returns exactly what it would have
 * returned without receipting. A login-required run with a LIVE handoff
 * is the one deferred case: the run truly ends at handoff teardown, so
 * its receipt is issued then (the outcome carries `receiptPromise`),
 * with humanAttentionMinutes taken from the finalized handoff event
 * record. not-connected / failed outcomes have no run to receipt.
 */
import { readFile } from "node:fs/promises";
import { homedir } from "node:os";
import { join } from "node:path";
import { encryptState, loadBundle, saveBundle, type ProfileBundle } from "../profile-store.ts";
import {
  openHandoff, formatHandoffLines,
  type HandoffEventRecord, type HandoffHandle, type HandoffRequiredSignal,
  type HandoffSession, type OpenHandoff,
} from "../handoff/index.ts";
import { receipts } from "../receipts/index.ts";
import { modalConnectionProblem, type ProviderName } from "./args.ts";
import { formatReceipt } from "./receipt.ts";
import {
  runSteelBaseline, runBrowserUseBaseline, runBrowserbaseBaseline,
  type BaselineMetrics, type BaselineOutcome,
} from "./run-baseline.ts";
import { runModalBaseline } from "./run-modal.ts";

export type RunOutcome =
  | { kind: "completed"; receipt: string[]; bundle: ProfileBundle; latencyMs: number; receiptPath?: string }
  | { kind: "refused"; receipt: string[]; bundle: ProfileBundle; changed: string[]; receiptPath?: string }
  | {
      kind: "login-required"; receipt: string[]; bundle: ProfileBundle; provider: ProviderName;
      /** Live handoff handle when one was started (see src/handoff/). */
      handoff?: HandoffHandle;
      /** The live handoff session — surfaces that stay resident (CLI) may await its outcome. */
      handoffSession?: HandoffSession;
      /** Why no handoff was started, when one was requested but impossible. */
      handoffUnavailable?: string;
      /** Signed run receipt path, when it was issued before this outcome returned. */
      receiptPath?: string;
      /**
       * Live-handoff runs only: the receipt is issued at handoff
       * teardown (when the run truly ends); this resolves to its path,
       * or null when issuance failed (the failure is logged either way).
       * Never rejects.
       */
      receiptPromise?: Promise<string | null>;
    }
  | { kind: "not-connected"; message: string }
  | { kind: "failed"; message: string };

export interface RunCoreDeps {
  runSteel?: typeof runSteelBaseline;
  runBrowserUse?: typeof runBrowserUseBaseline;
  runBrowserbase?: typeof runBrowserbaseBaseline;
  runModal?: typeof runModalBaseline;
  loadBundleFn?: typeof loadBundle;
  openHandoffFn?: typeof openHandoff;
  finalizeRunFn?: typeof receipts.finalizeRun;
}

/** Caller-side handoff request for a run (off unless enabled). */
export interface RunHandoffOptions {
  enabled?: boolean;
  /** Hard expiry budget, ms (default 360_000 — src/handoff). */
  ttlMs?: number;
  host?: string;
  port?: number;
  eventDir?: string;
}

export function defaultBundleDir(env: NodeJS.ProcessEnv): string {
  // Aligned with capture: named profiles live in ~/.nephew/profiles/<id>,
  // so the no-name default is that root's "default" profile — never a
  // path inside anyone's workspace (v0.4.0 pointed at a maintainer-only
  // workspace path).
  return env.NEPHEW_BUNDLE_DIR ?? join(homedir(), ".nephew", "profiles", "default");
}

function firstLine(e: unknown): string {
  return (e instanceof Error ? e.message : String(e)).split("\n")[0];
}

export interface IssueRunReceiptArgs {
  bundle: ProfileBundle;
  job: string;
  provider: ProviderName;
  outcome: string;
  metrics?: BaselineMetrics;
  handoffUsed: boolean;
  startedAt: Date;
  endedAt?: Date;
  humanAttentionMinutes?: number;
  env: NodeJS.ProcessEnv;
  log: (line: string) => void;
  /** Test seam — the same override RunCoreDeps exposes. */
  finalizeRunFn?: typeof receipts.finalizeRun;
}

/**
 * Issue the ONE signed run receipt for a terminal outcome
 * (src/receipts/INTEGRATION.md). This is the only receipt-issuance
 * construction in the codebase: runProfileJob calls it for every run,
 * and the session surfaces (src/with-profile.ts, which the Python
 * bridge drives) call it with the same field sourcing — receipts are
 * never re-implemented per surface.
 *
 * The helper never throws: a finalize failure logs one line and yields
 * no path, so receipting cannot change a run's outcome — only leave it
 * unreceipted.
 */
export async function issueRunReceipt(args: IssueRunReceiptArgs): Promise<string | null> {
  try {
    const m = args.metrics;
    const fp = m?.fingerprint;
    const { receiptPath } = await (args.finalizeRunFn ?? receipts.finalizeRun)({
      profileId: args.bundle.manifest.id,
      runId: m?.runId ?? args.job,
      provider: args.provider,
      outcome: args.outcome,
      startedAt: args.startedAt,
      endedAt: args.endedAt ?? new Date(),
      metrics: m
        ? {
            // Only the identity hashes cross into the receipt, and an
            // empty hash is "not captured", never a value.
            fingerprint: {
              ...(fp?.canvasHash ? { canvasHash: fp.canvasHash } : {}),
              ...(fp?.audioHash ? { audioHash: fp.audioHash } : {}),
              ...(fp?.fontsHash ? { fontsHash: fp.fontsHash } : {}),
            },
            egressIp: m.egressIp || null,
            humanAttentionMinutes: m.humanAttentionMinutes,
          }
        : null,
      ...(args.humanAttentionMinutes !== undefined
        ? { humanAttentionMinutes: args.humanAttentionMinutes } : {}),
      handoffUsed: args.handoffUsed,
      env: args.env,
    });
    args.log(`receipt     signed run receipt: ${receiptPath}`);
    return receiptPath;
  } catch (e) {
    args.log(`receipt     FAILED to issue: ${firstLine(e)}`);
    return null;
  }
}

export async function runProfileJob(
  input: {
    job: string; provider: ProviderName; bundleDir?: string; env: NodeJS.ProcessEnv;
    log: (line: string) => void;
    handoff?: RunHandoffOptions;
    /** Emitted once, the moment a live handoff is ready to be routed. */
    onHandoffRequired?: (signal: HandoffRequiredSignal) => void;
  },
  deps: RunCoreDeps = {},
): Promise<RunOutcome> {
  const { env, log } = input;

  // Modal gate first: one clear line, nothing else, when the pair is absent.
  if (input.provider === "modal") {
    const problem = modalConnectionProblem(env);
    if (problem) return { kind: "not-connected", message: problem };
  }

  const bundleDir = input.bundleDir ?? defaultBundleDir(env);
  let bundle: ProfileBundle;
  try {
    bundle = await (deps.loadBundleFn ?? loadBundle)(bundleDir);
  } catch (e) {
    return { kind: "failed", message: `nephew: could not load a bundle at ${bundleDir} — ${firstLine(e)}` };
  }

  // Trust receipt — before anything starts, on every path.
  const receipt = formatReceipt(bundle);
  for (const line of receipt) log(line);

  if (!env.PROFILE_ENCRYPTION_KEY) {
    return { kind: "failed", message: "nephew: PROFILE_ENCRYPTION_KEY is not set — the bundle state cannot be decrypted" };
  }

  // Run receipt (src/receipts/INTEGRATION.md): startedAt is captured
  // before the provider call, and every terminal outcome below issues
  // exactly one signed receipt through issueRunReceipt (the shared
  // helper above — it never throws, so receipting cannot change a
  // run's outcome, only leave it unreceipted).
  const startedAt = new Date();
  const issueReceipt = (args: {
    outcome: string;
    metrics?: BaselineMetrics;
    handoffUsed: boolean;
    endedAt?: Date;
    humanAttentionMinutes?: number;
  }): Promise<string | null> =>
    issueRunReceipt({
      bundle, job: input.job, provider: input.provider, startedAt, env, log,
      finalizeRunFn: deps.finalizeRunFn,
      outcome: args.outcome, metrics: args.metrics, handoffUsed: args.handoffUsed,
      endedAt: args.endedAt, humanAttentionMinutes: args.humanAttentionMinutes,
    });

  const holdForHandoff = input.handoff?.enabled === true && input.provider !== "modal";
  let outcome: BaselineOutcome;
  try {
    outcome =
      input.provider === "steel"
        ? await (deps.runSteel ?? runSteelBaseline)(input.job, bundle, log, { holdForHandoff })
        : input.provider === "browseruse"
          ? await (deps.runBrowserUse ?? runBrowserUseBaseline)(input.job, bundle, log, { holdForHandoff })
          : input.provider === "browserbase"
            ? await (deps.runBrowserbase ?? runBrowserbaseBaseline)(input.job, bundle, log, { holdForHandoff })
            : await (deps.runModal ?? runModalBaseline)(input.job, bundle, bundleDir, log);
  } catch (e) {
    return { kind: "failed", message: `nephew: ${firstLine(e)}` };
  }

  if (!outcome.gateOk) {
    const receiptPath = await issueReceipt({ outcome: "refused", metrics: outcome.metrics, handoffUsed: false });
    return {
      kind: "refused", receipt, bundle, changed: outcome.gateChanged,
      ...(receiptPath ? { receiptPath } : {}),
    };
  }
  if (outcome.verified) {
    const receiptPath = await issueReceipt({ outcome: "completed", metrics: outcome.metrics, handoffUsed: false });
    return {
      kind: "completed", receipt, bundle, latencyMs: outcome.latencyMs,
      ...(receiptPath ? { receiptPath } : {}),
    };
  }

  // login-required from here. Every path that does not start a live
  // handoff is receipted before it returns (handoffUsed: false — no
  // handoff session was opened for the run).
  const loginRequiredNoHandoff = async (handoffUnavailable?: string): Promise<RunOutcome> => {
    const receiptPath = await issueReceipt({
      outcome: "login-required", metrics: outcome.metrics, handoffUsed: false,
    });
    return {
      kind: "login-required", receipt, bundle, provider: input.provider,
      ...(handoffUnavailable ? { handoffUnavailable } : {}),
      ...(receiptPath ? { receiptPath } : {}),
    };
  };

  // A held live session we cannot use must still be closed here —
  // ownership transferred to run-core with it.
  const control = outcome.handoffControl;
  if (!input.handoff?.enabled) {
    if (control) await control.close().catch(() => { /* defensive: runners only hold when asked */ });
    return loginRequiredNoHandoff();
  }
  if (!control) {
    return loginRequiredNoHandoff(
      input.provider === "modal"
        ? "modal runs its browser inside the sandbox and exposes no host-side CDP session for a live handoff"
        : "the provider session could not be held open for a handoff",
    );
  }
  const designatedHuman = bundle.manifest.designatedHuman;
  if (!designatedHuman) {
    await control.close().catch(() => { /* the session must not leak */ });
    return loginRequiredNoHandoff("the bundle records no designated human to bind a handoff to");
  }

  let opened: OpenHandoff;
  try {
    opened = await (deps.openHandoffFn ?? openHandoff)({
      cdp: control.cdp,
      sessionId: control.sessionId,
      designatedHuman,
      profile: bundle.manifest.id,
      provider: input.provider,
      job: input.job,
      ttlMs: input.handoff.ttlMs,
      eventDir: input.handoff.eventDir,
      serverHost: input.handoff.host,
      serverPort: input.handoff.port,
      onBeforeTeardown: async (outcomeKind, sessionLike) => {
        // Resume = the human fixed the login in the live session:
        // capture that state and seal it into the owner bundle, so the
        // next run starts from the fixed login. End/expire capture
        // nothing — a half-finished login never seals over the bundle.
        if (outcomeKind !== "resumed" || !control.captureBack) return;
        sessionLike.captureBackAttempted = true;
        const captured = await control.captureBack();
        if (!captured) return;
        await saveBundle({
          ...bundle,
          manifest: { ...bundle.manifest, updatedAt: new Date().toISOString() },
          encryptedState: encryptState(JSON.stringify(captured)),
        }, bundleDir);
        log(`captured    handoff login sealed back into the owner bundle`);
      },
      onTeardown: async () => {
        await control.close().catch(() => { /* the runner's teardown is best-effort at this point */ });
      },
    });
  } catch (e) {
    await control.close().catch(() => { /* the session must not leak */ });
    return loginRequiredNoHandoff(`handoff could not start: ${firstLine(e)}`);
  }

  for (const line of formatHandoffLines(opened.handle)) log(line);
  input.onHandoffRequired?.({ type: "handoff_required", handle: opened.handle });
  // This run ends at handoff teardown, not here, so its receipt is
  // issued then. waitForOutcome() resolves only after the session has
  // finalized its event record — and written it to handle.eventFile —
  // so the pause's human-attention minutes and end time are read from
  // that finalized record (the resolved record is the fallback when the
  // file cannot be read). issueReceipt never throws, so this promise
  // never rejects.
  const receiptPromise: Promise<string | null> = (async () => {
    let record: HandoffEventRecord | null = null;
    try { record = await opened.session.waitForOutcome(); } catch { record = null; }
    let startedIso = record?.startedAt;
    let endedIso = record?.endedAt;
    try {
      const raw = JSON.parse(await readFile(opened.handle.eventFile, "utf8")) as
        Partial<HandoffEventRecord> | null;
      if (typeof raw?.startedAt === "string" && typeof raw?.endedAt === "string") {
        startedIso = raw.startedAt;
        endedIso = raw.endedAt;
      }
    } catch { /* the resolved record stands when the file cannot be read */ }
    const pauseMs = startedIso && endedIso ? Date.parse(endedIso) - Date.parse(startedIso) : NaN;
    const endedAt = endedIso ? new Date(endedIso) : undefined;
    return issueReceipt({
      outcome: "login-required",
      metrics: outcome.metrics,
      handoffUsed: true,
      humanAttentionMinutes: Number.isFinite(pauseMs) && pauseMs > 0 ? pauseMs / 60_000 : 0,
      ...(endedAt && Number.isFinite(endedAt.getTime()) ? { endedAt } : {}),
    });
  })();
  return {
    kind: "login-required", receipt, bundle, provider: input.provider,
    handoff: opened.handle, handoffSession: opened.session, receiptPromise,
  };
}

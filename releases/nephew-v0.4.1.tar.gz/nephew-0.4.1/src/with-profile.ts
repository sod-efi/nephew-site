/**
 * with-profile — the TypeScript decorator/helper surface (delight brief §3,
 * Shape B): run a job function inside a carried, verified profile session.
 *
 *   import { withProfile } from "./src/with-profile.ts";
 *   await withProfile(bundleDir, "steel", async ({ cdp, sessionId }) => {
 *     // already logged in as the owner — no login code in this file
 *   });
 *
 * What it does, in order: load the owner-held bundle → print the trust
 * receipt through the log seam → open a provider session (the same
 * openers `nephew run` uses) → apply the bundle's emulation overrides →
 * FINGERPRINT GATE → restore the bundle state and verify it (all of that
 * is run-baseline's runInSession, reused, not reimplemented) → hand the
 * live session to fn → capture the session state back into the same
 * bundle (cookies + per-origin localStorage, via state.ts) → close the
 * session.
 *
 * The lifecycle is split in two so another driver can hold the session
 * between start and finish: openProfileSession() performs everything up
 * to the verified live session and returns it with complete() (capture
 * back, close, receipt) and abort() (close without capture-back,
 * receipt). withProfile() is the composition open → fn → complete/abort,
 * and the Python bridge (src/cli/python-bridge.ts) drives the same pair
 * over stdio for the `nephew` Python package — one lifecycle, never a
 * second implementation.
 *
 * Every terminal outcome that carried a profile is receipted exactly
 * once — refused / login-required at the pause, completed at
 * complete(), job-failed at abort() — through run-core's
 * issueRunReceipt → receipts.finalizeRun, the same construction
 * `nephew run` and the MCP surface use. Receipting never changes an
 * outcome: issuance failure logs one line and yields no path.
 *
 * HONEST LIMITS of this subset (marked, not faked):
 *  1. Providers: steel + browseruse + browserbase. Modal is NOT supported here —
 *     its runner drives the browser from INSIDE the sandbox and exposes
 *     no host-side CDP session to hand to a job function. Use
 *     `nephew run --provider modal` for Modal. Calling withProfile with
 *     "modal" throws immediately and says exactly this.
 *  2. The handle is the baseline page session after restore+verify, left
 *     on the bundle's first origin. Multi-tab work, extra targets, and
 *     job navigation are the job function's own business (raw CDP).
 *  3. Capture-back covers the bundle's OWN origins (the Layer-1 subset
 *     every surface here carries: cookies are browser-wide; localStorage
 *     is per bundled origin). A login created mid-job on a NEW origin is
 *     not folded into the bundle by this helper — re-capture it with
 *     `nephew capture`.
 *  4. If fn throws, the session is closed WITHOUT capture-back: a failed
 *     job's half-mutated state never seals over the owner's bundle.
 */
import { decryptState, encryptState, loadBundle, saveBundle, type ProfileBundle } from "./profile-store.ts";
import type { CdpClient } from "./cdp.ts";
import { captureState, type StoredState } from "./state.ts";
import type { ProviderName } from "./cli/args.ts";
import { formatReceipt } from "./cli/receipt.ts";
import { issueRunReceipt } from "./cli/run-core.ts";
import type { finalizeRun } from "./receipts/run-receipt.ts";
import {
  openBrowserUseSession, openBrowserbaseSession, openSteelSession, runInSession,
  type BaselineOutcome, type OpenedProviderSession,
} from "./cli/run-baseline.ts";

/** The live, verified session handed to the job function. */
export interface ProfileSessionHandle {
  /** Raw CDP client for the provider session (the job drives from here). */
  cdp: CdpClient;
  /** The attached page session, with the profile restored + verified. */
  sessionId: string;
  bundle: ProfileBundle;
  provider: "steel" | "browseruse" | "browserbase";
  /**
   * The provider-issued CDP endpoint (ws or http) for drivers that
   * connect from outside this process — a session capability, never
   * logged or recorded. Present with the real provider openers.
   */
  cdpUrl?: string;
}

/** Thrown when the live fingerprint fails the bundle recipe's gate. */
export class ProfileGateError extends Error {
  readonly changed: string[];
  readonly profileId: string;
  /** Signed run receipt for the refused run, when one was issued. */
  readonly receiptPath: string | null;
  constructor(changed: string[], profileId: string, receiptPath: string | null = null) {
    super(`fingerprint mismatch on: ${changed.join(", ")} — run refused before any state was released`);
    this.name = "ProfileGateError";
    this.changed = changed;
    this.profileId = profileId;
    this.receiptPath = receiptPath;
  }
}

/**
 * Thrown when the carried login does not hold — the structured pause from
 * the delight brief, as an error class with a machine-readable `status`
 * (the MCP surface returns the same shape as a result, not an error).
 */
export class LoginRequiredError extends Error {
  readonly status = "LOGIN_REQUIRED" as const;
  readonly designatedHuman?: string;
  readonly profileId: string;
  /** Signed run receipt for the paused run, when one was issued. */
  readonly receiptPath: string | null;
  constructor(bundle: ProfileBundle, receiptPath: string | null = null) {
    super(
      `LOGIN_REQUIRED — profile "${bundle.manifest.id}" did not verify as logged in; ` +
      `the designated human (${bundle.manifest.designatedHuman ?? "not recorded"}) re-captures with \`nephew capture\` and the job can be retried`,
    );
    this.name = "LoginRequiredError";
    this.designatedHuman = bundle.manifest.designatedHuman;
    this.profileId = bundle.manifest.id;
    this.receiptPath = receiptPath;
  }
}

export interface WithProfileOptions {
  /** Metrics-record job label (default "withProfile"). */
  job?: string;
  log?: (line: string) => void;
  /** Metrics directory override (tests); default the scaffold runs/. */
  runsDir?: string;
  /** Env for run-receipt resolution (signing key / receipts dir); default process.env. */
  env?: NodeJS.ProcessEnv;
  /** Receipt finalize seam (tests) — the same seam run-core exposes. */
  finalizeRunFn?: typeof finalizeRun;
  /** Session-opener seam (tests). */
  openSession?: (provider: "steel" | "browseruse" | "browserbase", log: (line: string) => void) => Promise<OpenedProviderSession>;
  /** In-session flow seam (tests). */
  runInSessionFn?: typeof runInSession;
}

/**
 * A live, verified profile session, held between openProfileSession()
 * and exactly one finish: complete() after the job ran, abort() when it
 * failed (or its driver vanished). Finishing is idempotent — a second
 * call returns the first finish's result and does nothing.
 */
export interface LiveProfileSession {
  handle: ProfileSessionHandle;
  bundle: ProfileBundle;
  provider: "steel" | "browseruse" | "browserbase";
  /** Capture the live state back into the bundle, close, receipt "completed". */
  complete(): Promise<{ receiptPath: string | null }>;
  /** Close WITHOUT capture-back; receipt "job-failed". */
  abort(): Promise<{ receiptPath: string | null }>;
}

/**
 * Everything up to the verified live session: bundle → trust receipt →
 * provider session → gate → restore + verify. Gate refusal and an
 * unverified restore close the session, receipt the run, and throw the
 * structured errors (ProfileGateError / LoginRequiredError, each
 * carrying the receipt path) — the same terminal shapes withProfile has
 * always produced.
 */
export async function openProfileSession(
  bundleDir: string,
  provider: ProviderName,
  opts: WithProfileOptions = {},
): Promise<LiveProfileSession> {
  if (provider === "modal") {
    throw new Error(
      "withProfile does not support provider \"modal\" yet: the modal runner drives its browser from inside the sandbox and exposes no host-side CDP session to hand a job function — use `nephew run --provider modal` (documented limit, src/with-profile.ts)",
    );
  }
  const log = opts.log ?? (() => {});
  const env = opts.env ?? process.env;
  const job = opts.job ?? "withProfile";
  const bundle = await loadBundle(bundleDir);
  // Trust receipt — before anything starts, on every path (through the
  // log seam: silent for library callers, on stderr for the bridge).
  for (const line of formatReceipt(bundle)) log(line);
  const startedAt = new Date();
  const receiptFor = (outcome: string, metrics?: BaselineOutcome["metrics"]) =>
    issueRunReceipt({
      bundle, job, provider, outcome, metrics, handoffUsed: false,
      startedAt, env, log, finalizeRunFn: opts.finalizeRunFn,
    });
  const open = opts.openSession ?? ((p, l) =>
    p === "steel" ? openSteelSession(l) : p === "browserbase" ? openBrowserbaseSession(l) : openBrowserUseSession(l));
  const session = await open(provider, log);
  let outcome: BaselineOutcome;
  try {
    outcome = await (opts.runInSessionFn ?? runInSession)(
      session.cdp, session.pageSessionId, job, bundle,
      provider === "steel" ? "steel-cloud" : provider === "browserbase" ? "browserbase-cloud" : "browser-use-cloud", log,
      { runsDir: opts.runsDir },
    );
  } catch (e) {
    await session.close().catch(() => { /* the opener's teardown is best-effort */ });
    throw e;
  }
  if (!outcome.gateOk) {
    await session.close();
    const receiptPath = await receiptFor("refused", outcome.metrics);
    throw new ProfileGateError(outcome.gateChanged, bundle.manifest.id, receiptPath);
  }
  if (!outcome.verified) {
    await session.close();
    const receiptPath = await receiptFor("login-required", outcome.metrics);
    throw new LoginRequiredError(bundle, receiptPath);
  }

  const handle: ProfileSessionHandle = {
    cdp: session.cdp,
    sessionId: session.pageSessionId,
    bundle,
    provider,
    ...(session.cdpUrl ? { cdpUrl: session.cdpUrl } : {}),
  };
  let closed = false;
  let finishResult: { receiptPath: string | null } | null = null;
  const closeOnce = async () => {
    if (closed) return;
    closed = true;
    await session.close();
  };
  return {
    handle,
    bundle,
    provider,
    async complete() {
      if (finishResult) return finishResult;
      // Capture-back: seal the job's session state into the same bundle,
      // so the next run — on either provider — continues from here. A
      // capture failure still closes the session and propagates, exactly
      // as withProfile has always behaved (no receipt: the run's own
      // ending is the error).
      try {
        const state = JSON.parse(decryptState(bundle.encryptedState)) as StoredState;
        const captured = await captureState(session.cdp, session.pageSessionId, state.origins.map((o) => o.origin));
        await saveBundle({
          ...bundle,
          manifest: { ...bundle.manifest, updatedAt: new Date().toISOString() },
          encryptedState: encryptState(JSON.stringify(captured)),
        }, bundleDir);
        log(`captured    state sealed back into the owner bundle`);
      } finally {
        await closeOnce();
      }
      const receiptPath = await receiptFor("completed", outcome.metrics);
      finishResult = { receiptPath };
      return finishResult;
    },
    async abort() {
      if (finishResult) return finishResult;
      await closeOnce();
      const receiptPath = await receiptFor("job-failed", outcome.metrics);
      finishResult = { receiptPath };
      return finishResult;
    },
  };
}

export async function withProfile<T>(
  bundleDir: string,
  provider: ProviderName,
  fn: (session: ProfileSessionHandle) => Promise<T>,
  opts: WithProfileOptions = {},
): Promise<T> {
  const live = await openProfileSession(bundleDir, provider, opts);
  let result: T;
  try {
    result = await fn(live.handle);
  } catch (e) {
    // A failed job's half-mutated state never seals over the owner's
    // bundle: close without capture-back, then the job's error stands.
    await live.abort();
    throw e;
  }
  await live.complete();
  return result;
}

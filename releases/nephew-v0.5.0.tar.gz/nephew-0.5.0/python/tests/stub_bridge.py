#!/usr/bin/env python3
"""Stub `nephew` executable for the package tests: speaks just enough
of the bridge protocol to exercise the client. Behavior from env:

  STUB_MODE     ready | login | refused | error   (default ready)
  STUB_RECORD   file to append every received line to (JSON per line)
  STUB_RECEIPT  receipt path to create and report in events
"""
import json
import os
import sys


def main() -> int:
    mode = os.environ.get("STUB_MODE", "ready")
    record = os.environ.get("STUB_RECORD")
    receipt = os.environ.get("STUB_RECEIPT")

    def log(obj: dict) -> None:
        if record:
            with open(record, "a", encoding="utf8") as f:
                f.write(json.dumps(obj) + "\n")

    def send(obj: dict) -> None:
        sys.stdout.write(json.dumps(obj) + "\n")
        sys.stdout.flush()

    first = sys.stdin.readline()
    if not first:
        return 0
    start = json.loads(first)
    log(start)

    if mode == "error":
        send({"type": "error", "message": "boom from the stub bridge"})
        return 1
    if receipt:
        with open(receipt, "w", encoding="utf8") as f:
            f.write("{}\n")
    if mode == "login":
        send({
            "type": "login_required", "status": "LOGIN_REQUIRED",
            "job": start.get("job"), "provider": start.get("provider"),
            "profile": "wp-1", "designatedHuman": "Ben", "handoff": None,
            "action": "the designated human re-captures the login (`nephew capture`) — the job can then be retried unchanged",
            "receiptPath": receipt,
        })
        return 0
    if mode == "refused":
        send({
            "type": "refused", "status": "REFUSED", "reason": "fingerprint-mismatch",
            "job": start.get("job"), "provider": start.get("provider"),
            "profile": "wp-1", "changed": ["timezone"], "receiptPath": receipt,
        })
        return 0

    send({
        "type": "ready", "cdpUrl": "ws://stub.invalid/cdp", "sessionId": "page-1",
        "profile": "wp-1", "provider": start.get("provider"), "job": start.get("job"),
    })
    line = sys.stdin.readline()
    if not line:
        return 0
    close = json.loads(line)
    log(close)
    ok = bool(close.get("ok"))
    send({
        "type": "finalized",
        "outcome": "completed" if ok else "job-failed",
        "capturedBack": ok,
        "receiptPath": receipt,
    })
    return 0


if __name__ == "__main__":
    sys.exit(main())

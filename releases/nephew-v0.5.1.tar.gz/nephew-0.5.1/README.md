# Nephew — your logged-in identity, in any agent sandbox

**The product in one line:** the browser profile lives with the owner and travels
across agent providers, computers and runs — *bring your logged-in identity to any
agent run.*

Nephew is the **profile layer** for the sandbox providers you already use. It
carries one logged-in browser identity — cookies, session state, a coherent
fingerprint, and a pinned egress IP — *into* Modal, Steel, Browser Use, and
Browserbase. It is
not another sandbox, and it does not replace them: your jobs still run on your
provider, under your account. Nephew is the identity they run *as*.

Pillars: **Portable · Continuous · Yours.**

## Install

```bash
curl -fsSL https://nephew.ai/install | sh
```

The installer writes exactly two things — the app to `~/.local/lib/nephew` and a
launcher to `~/.local/bin/nephew` — after verifying the download against the
published SHA256SUMS. No sudo. Requires Node.js 22 or newer.

## Quickstart

```bash
nephew init       # 1. connect YOUR OWN provider accounts (skip any you don't use)
nephew capture    # 2. sign in once, in your own local browser → encrypted bundle
nephew run nightly-recon --provider modal     # 3. run anywhere
nephew revoke     #    destroy the bundle, with a signed deletion receipt
nephew receipt verify <file>   #    check a run's signed receipt (PASS/FAIL)
```

Budgets on the happy path: under 5 minutes wall clock and under 60 seconds of
human attention from install to first run, excluding the one login you choose
to capture.

### 1. `nephew init` — your accounts, your keys

Walks Modal (token pair — read from your environment or your own
`~/.modal.toml`), Steel (API key), Browser Use (API key), and Bright Data
(API token + the zone your egress is pinned to). Each provider gets one live,
read-only verification call. Skip any provider you don't use — one connected
provider is a working setup.

Keys are read from your environment only. They are never printed and never
stored: `~/.nephew/config.json` (mode 0600) records **references** — which env
var holds each key, the Bright Data customer id + zone, and whether the check
passed. There is no Nephew account and no Nephew cloud in the middle; provider
billing stays yours.

### 2. `nephew capture` — sign in once, in your own browser

Three one-idea steps:

1. **Your logins.** A seeded fingerprint-chromium window opens on your machine.
   The browser is the pinned fingerprint-chromium 150.0.7871.186 build:
   capture keeps a sha256-verified copy under `~/.nephew/browsers`
   (downloaded from the fingerprint-chromium release on first use), or
   opens yours when `OWN_STACK_CHROME_PATH` names one.
   Name the profile and its **designated human** — the person a paused run
   routes its handoff to (whoever receives that account's codes today). Log in
   to your sites the way you normally would: password manager, MFA, passkeys,
   all untouched by us. We never see your passwords.
2. **Review.** The inventory: which sites were captured, with cookie/storage
   counts. Remove any site by hostname — what you remove never enters the bundle.
3. **Where it lives.** The session (cookies + per-origin localStorage) is sealed
   into an encrypted bundle **you** hold, under a key **you** hold
   (`PROFILE_ENCRYPTION_KEY` — it never sits with the bundle). The fingerprint
   recipe — seed, user agent, timezone, screen, WebGL — is measured from the
   capture browser and pinned into the bundle, along with the designated human
   and the pinned-egress reference from your Bright Data zone.

### 3. `nephew run` — the same identity, on any provider

```bash
nephew run <job> --provider steel|browseruse|modal|browserbase [--dry-run] [--bundle <dir>] [--handoff]
```

Every run opens with the three-line trust receipt — whose profile, the
fingerprint it must match, the egress it must come from:

```
profile     modal-proxy-20261030 · owner-held bundle · loaded from your vault
fingerprint 2ef43e20ca · seed 1000 · windows/Chrome
egress      brightdata-zone-isp_proxy3 · pinned
```

The run then measures the live browser in the provider session and checks it
against the recipe. **The fingerprint gate must accept before any state is
released** — on a mismatch the run refuses, rather than logging in as a stranger
device. When the job ends, the live session is captured back into the same
bundle: one identity, no forks.

If a site challenges the run, it pauses with `LOGIN_REQUIRED`. With
`--handoff` (Steel + Browser Use + Browserbase), the live session is held instead of
closed: the bundle's designated human takes over on a loopback page —
screencast stream in, mouse and keyboard back — under a hard deadline
(360 s by default) that late arrival cannot extend. Resume captures the
fixed session back into the bundle; end or expire captures nothing. Modal
exposes no host-side session to lend, so a Modal run returns the plain
pause.

### `nephew revoke`

```bash
nephew revoke [--bundle <dir>] [--key-file <file>] [--receipt <file>]
```

Destroys the bundle (and key material you explicitly name) and leaves an
Ed25519-signed deletion receipt you can verify independently. Demonstrated:
a throwaway bundle revoked in 289 ms, receipt verified from a separate process.

### `nephew receipt verify`

```bash
nephew receipt verify <file>
```

Every run leaves a signed run receipt under `~/.nephew/receipts/` —
profile, run, provider, the fingerprint hashes it measured, the egress it
observed, start and end times, the outcome, how many minutes of human
attention it took, and whether a handoff was used — signed with the same
owner Ed25519 key as the deletion receipt. `verify` prints PASS, or FAIL
naming the field that changed, so anyone you hand the receipt to can check
a run's record against your public key without trusting us.

## Surfaces

- **CLI** — `nephew init / capture / run / revoke / receipt verify`, above,
  plus `nephew login` and `nephew plan` (see Plans).
- **MCP** — `nephew mcp` serves one tool on stdio:

  ```json
  { "tool": "profile_run",
    "args": { "job": "nightly-recon", "provider": "steel", "bundle": "/path/to/bundle" } }
  ```

  Same receipt + gate as the CLI (one shared run core). The calling model never
  sees a cookie or the bundle. A run whose carried login doesn't hold returns a
  structured **`LOGIN_REQUIRED`** pause result — status, profile, and the
  designated human — not an error.
- **TypeScript helper** — `withProfile(bundleDir, provider, fn)` in
  `src/with-profile.ts`: opens the session, gates, restores, verifies, hands
  your function the live CDP page session, then captures back. Steel +
  Browser Use + Browserbase — Modal's driver runs inside its sandbox and exposes no
  host-side CDP handle, so Modal goes through `nephew run` (the limit is
  documented in the file, not papered over).
- **Python decorator** — `with_profile(bundle, provider)` in the `nephew`
  Python package (`python/` in the release): the same carried identity for
  Python jobs. A context manager and a decorator that hand your function a
  session carrying the provider's CDP endpoint (drive it with Playwright's
  `connect_over_cdp`, or anything that speaks CDP), then capture back and
  close. Same gate, same signed run receipts — it drives the `nephew bridge`
  stdio command, so the Python side holds no keys and stores nothing. Steel +
  Browser Use + Browserbase, like the TS helper; Modal goes through `nephew run`.

  ```python
  from nephew import with_profile

  @with_profile(bundle="/path/to/bundle", provider="steel")
  def nightly_recon(session):
      ...  # session.cdp_url — already logged in as the owner
  ```

## Measured proof (runs/ has the record for every number)

- **Steel baseline:** bundle state restored + verified in a fresh session,
  0 login prompts, 0 MFA prompts, 6,366 ms.
- **Browser Use baseline:** same bundle shape, same result — 0 prompts, 7,815 ms.
- **Browserbase baseline:** same bundle shape, same result — 0 prompts, 5,688 ms.
  Sessions are created key-only (no project id) and never with a Browserbase
  Context — the owner bundle is the only state they see.
- **Modal, two environments:** the same profile measured on this machine and
  inside a Modal sandbox produced **identical fingerprints — all 10 measured
  elements, canvas included** — with the pinned font pack in both environments.
- **Pinned egress in Modal:** a run egressed from exactly **91.108.223.136** —
  the profile's own dedicated Bright Data IP — gate accepted, session restored,
  0 prompts.
- **Full Modal runs:** 10–27 s in-session across the proof runs.
- **Install:** the `curl | sh` flow was exercised end-to-end against a clean
  HOME (locally served payload): install, `nephew --help`, and a Modal dry run
  all pass (`packaging/PROOF-2026-10-30.md`).
- **Managed-cloud drift, stated plainly:** in Steel, Browser Use, and
  Browserbase the recipe-pinned elements (user agent, timezone, screen) hold;
  computed elements (canvas, WebGL, audio, fonts) drift — those providers offer
  no seed/binary controls. The gate pins what the provider can hold; the
  own-stack track (fingerprint-chromium on Modal) is where the full fingerprint
  holds.

## Plain limits

- **A site can still challenge a run.** When it does, the run pauses with
  `LOGIN_REQUIRED`, the designated human completes a short handoff, and the
  cleared session captures back into the same bundle. The promise is not zero
  human touches forever — it is that a rare challenge costs a short handoff,
  not a babysat login flow.
- **One dedicated IP per identity.** That pinning is the product, and it is
  per-profile by design.
- **No "works on every site" claims.** Above are the runs actually measured;
  every run writes its own metrics record in `runs/`, measured the same way.
- **Browserbase session windows:** the 5-minute timeout in a project's
  settings is the default when no timeout is requested. Nephew requests an
  explicit 1-hour window — measured granted in full, including a probe at the
  21,600-second API maximum.
- Proof status: the baselines, the Modal runs, pinned egress, and the install
  path are proved. One owner-designated real-account workload is still being
  proven (the Amazon gate test in `runs/`) — `runs/VERDICT.md` stays DRAFT
  until it resolves.

## Plans

Two plans, both bring-your-own provider accounts (provider billing stays
yours): https://nephew.ai/#pricing

- **Free** ($0) — 2 profiles, 1 run at a time. No key, no login: the CLI as
  it is out of the box.
- **BYO** ($19/mo) — 10 profiles, 3 runs at a time. Your welcome page and
  the email from Nephew carry a licence key (`NPW-BYO-XXXX-XXXX-XXXX-XXXX`);
  turn it on once with `nephew login <key>`.

```bash
nephew login NPW-BYO-XXXX-XXXX-XXXX-XXXX   # You're on BYO: 10 profiles, 3 runs at a time. Renews Dec 1.
nephew login                               # no key: re-check the stored one (asks for one when none is stored)
nephew plan                                # the plan you're on and its limits
nephew login --forget                      # back to Free
```

What is kept, and where:

- `~/.nephew/licence.json` (mode 0600) — the key, plan, status, limits,
  renewal date and when it was last checked. Override the path with
  `NEPHEW_LICENCE` (like `NEPHEW_CONFIG`). Free has no file at all.
- `~/.nephew/runs/locks/` — one small lock file per live run (pid, start
  time, bundle dir), removed when the run ends, including on Ctrl-C and
  errors; a lock whose process is gone, older than 24 h, or from before this
  boot is dead. Its own folder beside the run records and `handoffs/` in the
  runs dir, so sweeping a dead lock never touches a record; `NEPHEW_RUNS_DIR`
  moves the whole runs dir.
- `NEPHEW_BILLING_URL` — the licence service (default: nephew.ai's). Only
  `nephew login` and a BYO re-check call it; Free never does.

A cached BYO answer is trusted for a day, then re-checked quietly (8 s
timeout, never a prompt). If the plan has been turned off you are told once
and run as Free; if nephew.ai cannot be reached for 7 days you run as Free
until it answers again. The limits are enforced where they bite, with the
way out in the message: a new `nephew capture` at the profile limit says so
(`Free includes 2 profiles and you have 2. BYO has 10: … Or free one up:
nephew revoke --bundle …`), and a `nephew run`, MCP `profile_run`, TS
`withProfile` session, or Python `with_profile` session (the bridge) at
the runs-at-a-time limit is refused before any session is created — all
four share the same run locks and count each other (the MCP tool and
the bridge return a structured `REFUSED` result, reason `plan-limit`;
the Python client raises `PlanLimitError`). `revoke`,
`plan`, `login`, `init`, `receipt verify` and `--dry-run` are never blocked.

## For builders picking this up cold

1. `MISSION.md` — the assignment, with a checkable DONE MEANS end state.
2. `AGENTS.md` — working rules for any agent building in this folder.
3. `docs/ARCHITECTURE.md` — components, provider adapters, profile format.
4. `docs/SECURITY_REVIEW.md` — read before touching profile data. Profiles hold
   session tokens = account access; the controls there are requirements.
5. `docs/TEST_PLAN.md` — the proof runs, measures, and the pre-committed kill
   criterion.
6. `docs/FINGERPRINT_RESEARCH_FINDINGS.md` — the fingerprint split into 3
   layers, and why the moat needs a browser build we control (own-stack),
   with the managed clouds as measured baselines.
7. `../2026-10-29-browser-profile-priority.json` — the decision record this
   scaffold implements. If this scaffold and that file disagree, that file
   wins until the owner changes it.
8. `memory.md` — durable build notes, failures included, newest first.

## Layout

```
bin/nephew.js           the installed CLI shim
src/nephew.ts           CLI dispatch
src/cli/args.ts         argument parsing (pure)
src/cli/config.ts       ~/.nephew/config.json — references only, mode 0600
src/cli/init.ts         nephew init — BYO credential checks (read-only)
src/cli/plan.ts         plans + limits: nephew login / plan, ~/.nephew/licence.json, run locks
src/cli/capture.ts      nephew capture — local-browser capture, 3 steps
src/cli/run-core.ts     the one run path behind CLI + MCP
src/cli/receipt.ts      the 3-line trust receipt + fingerprint gate
src/cli/run-baseline.ts steel / browseruse / browserbase sessions (openers + baselines)
src/cli/run-modal.ts    modal runner (driver co-located in the sandbox)
src/cli/revoke.ts       signed deletion receipts
src/mcp/server.ts       MCP server: profile_run
src/with-profile.ts     TS helper: withProfile(bundle, provider, fn)
src/profile-store.ts    the owner-held encrypted bundle
src/state.ts            Layer 1 capture/restore (cookies + localStorage)
src/fingerprint.ts      fingerprint probe + diff (one probe everywhere)
src/providers/          provider adapters (own-stack = the moat track)
tools/modal_bridge.py   Modal SDK bridge (create / run / terminate / check)
tools/modal_driver.py   in-sandbox CDP driver
test/                   unit tests (npm test) — offline, providers faked
runs/                   one metrics record per run
packaging/              deterministic release + install.sh + site payload
```

## Development

```bash
npm ci
npm run typecheck
npm test
```

Secrets for development arrive via environment variables only — see
`.env.example`. Never commit a key, a cookie value, or a zone password.

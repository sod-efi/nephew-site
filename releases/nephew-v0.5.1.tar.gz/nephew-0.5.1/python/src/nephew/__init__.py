"""nephew — run Python jobs inside your own portable browser profile.

The Python surface of Nephew: the same carried identity the TypeScript
helper (`withProfile`) offers, with the same fingerprint gate and the
same signed run receipts. This package is a thin driver over the
`nephew bridge` stdio command in the Nephew CLI — the session itself
(bundle, gate, restore, capture-back, receipts) lives in the CLI, so
the Python side holds no keys, stores nothing, and never sees the
bundle. Your environment is inherited by the bridge as-is: the same
variables the CLI reads (PROFILE_ENCRYPTION_KEY, provider keys) are
the only secrets involved, and they arrive by environment only.

Usage — context manager:

    from nephew import with_profile

    with with_profile(bundle="/path/to/bundle", provider="steel") as session:
        # session.cdp_url is the live session's CDP endpoint, already
        # logged in as the profile owner. Drive it with anything that
        # speaks CDP — Playwright is NOT a dependency of this package;
        # if you use it, the pattern is:
        #
        #     from playwright.sync_api import sync_playwright
        #     with sync_playwright() as pw:
        #         browser = pw.chromium.connect_over_cdp(session.cdp_url)
        #         page = browser.contexts[0].pages[0]
        ...
    # On exit the live state is captured back into the bundle, the
    # session closes, and a signed run receipt lands on disk —
    # session.receipt_path names it.

Usage — decorator (the wrapped function receives the session first):

    @with_profile(bundle="/path/to/bundle", provider="steel")
    def nightly_recon(session):
        ...

The pause: when the carried login does not hold, entering the context
raises LoginRequiredError — the structured LOGIN_REQUIRED pause,
carrying the payload (status, profile, designated human, receipt
path), not a bare failure. A fingerprint-gate refusal raises
GateRefusedError with the changed elements. When the plan's
runs-at-a-time limit is already in use (the same licence limit
`nephew run` and MCP `profile_run` obey — sessions here share their
run locks), entering raises PlanLimitError with the plan, its limits,
and the one-line message; no session was created. Providers are steel,
browseruse, and browserbase, exactly like the TS helper; Modal
exposes no host-side CDP session and stays CLI-only
(`nephew run --provider modal`) — the bridge says so rather than
faking a session.
"""
from __future__ import annotations

import functools
import os
import shutil
from dataclasses import dataclass
from typing import Any, Callable, Optional

from ._bridge import BridgeProcess

__version__ = "0.5.1"
__all__ = [
    "with_profile",
    "ProfileSession",
    "NephewError",
    "GateRefusedError",
    "LoginRequiredError",
    "PlanLimitError",
    "__version__",
]


class NephewError(Exception):
    """The bridge or the run failed (no session, or it could not finalize)."""


class GateRefusedError(NephewError):
    """The fingerprint gate refused the run before any state was released."""

    def __init__(self, payload: dict):
        self.payload = payload
        self.changed: list = list(payload.get("changed") or [])
        self.profile = payload.get("profile")
        self.receipt_path = payload.get("receiptPath")
        super().__init__(
            "fingerprint mismatch on: " + ", ".join(self.changed)
            + " — run refused before any state was released"
        )


class PlanLimitError(NephewError):
    """The plan's runs-at-a-time limit is already in use — nothing ran.

    The bridge refused the start before any provider session was
    created, with the same structured shape the MCP profile_run tool
    returns for this refusal (status REFUSED, reason "plan-limit").
    Carries the plan name, its limits, and the one-line message that
    names the way out (wait for a run to finish, or upgrade).
    """

    status = "REFUSED"
    reason = "plan-limit"

    def __init__(self, payload: dict):
        self.payload = payload
        self.plan = payload.get("plan")
        self.limits = payload.get("limits")
        self.message = payload.get("message") or "the plan's runs at a time are all in use"
        super().__init__(self.message)


class LoginRequiredError(NephewError):
    """The carried login did not hold — the structured LOGIN_REQUIRED pause."""

    status = "LOGIN_REQUIRED"

    def __init__(self, payload: dict):
        self.payload = payload
        self.profile = payload.get("profile")
        self.designated_human = payload.get("designatedHuman")
        self.receipt_path = payload.get("receiptPath")
        super().__init__(
            f"LOGIN_REQUIRED — profile {self.profile!r} did not verify as logged in; "
            f"the designated human ({self.designated_human}) re-captures with "
            "`nephew capture` and the job can be retried"
        )


@dataclass
class ProfileSession:
    """The live, verified session handed to your job.

    `cdp_url` is the provider session's CDP endpoint (ws or http) — a
    session capability: use it to drive the browser, never log or store
    it. `receipt_path` and `outcome` are filled in when the session
    finalizes (context exit / decorated call return).
    """

    cdp_url: str
    session_id: str
    profile: Optional[str] = None
    provider: Optional[str] = None
    job: Optional[str] = None
    receipt_path: Optional[str] = None
    outcome: Optional[str] = None
    close_error: Optional[str] = None


def _resolve_cli(cli: Optional[str]) -> str:
    if cli:
        return cli
    env_cli = os.environ.get("NEPHEW_CLI")
    if env_cli:
        return env_cli
    found = shutil.which("nephew")
    if found:
        return found
    raise NephewError(
        "nephew CLI not found — install Nephew first (this package drives its "
        "`nephew bridge` command), or set NEPHEW_CLI to the CLI's path"
    )


class _WithProfile:
    """One with_profile configuration; a context manager and a decorator."""

    def __init__(self, bundle: str, provider: str, job: Optional[str], cli: Optional[str]):
        self._bundle = bundle
        self._provider = provider
        self._job = job
        self._cli = cli
        self._bridge: Optional[BridgeProcess] = None
        self.session: Optional[ProfileSession] = None

    def __enter__(self) -> ProfileSession:
        bridge = BridgeProcess(_resolve_cli(self._cli))
        self._bridge = bridge
        job = self._job or "python"
        try:
            bridge.send({
                "type": "start",
                "bundle": self._bundle,
                "provider": self._provider,
                "job": job,
            })
            event = bridge.read_event()
        except (OSError, ValueError) as e:
            bridge.reap()
            raise NephewError(f"nephew bridge failed during start: {e}") from e
        if event is None:
            rc = bridge.reap()
            raise NephewError(f"nephew bridge exited (code {rc}) before the session was ready")
        kind = event.get("type")
        if kind == "ready":
            self.session = ProfileSession(
                cdp_url=event["cdpUrl"],
                session_id=event["sessionId"],
                profile=event.get("profile"),
                provider=event.get("provider") or self._provider,
                job=event.get("job") or job,
            )
            return self.session
        # Terminal start outcomes — the bridge exits on its own.
        bridge.reap()
        if kind == "login_required":
            raise LoginRequiredError(event)
        if kind == "refused":
            if event.get("reason") == "plan-limit":
                raise PlanLimitError(event)
            raise GateRefusedError(event)
        if kind == "error":
            raise NephewError(str(event.get("message") or "nephew bridge error"))
        raise NephewError(f"unexpected bridge event at start: {kind!r}")

    def __exit__(self, exc_type, exc, tb) -> bool:
        bridge, session = self._bridge, self.session
        self._bridge = None
        if bridge is None or session is None:
            return False
        ok = exc_type is None
        finalize_error: Optional[str] = None
        try:
            bridge.send({
                "type": "close",
                "ok": ok,
                **({"error": f"{exc_type.__name__}: {exc}"} if not ok else {}),
            })
            event = bridge.read_event()
            if event is not None and event.get("type") == "finalized":
                session.receipt_path = event.get("receiptPath")
                session.outcome = event.get("outcome")
            elif event is not None and event.get("type") == "error":
                finalize_error = str(event.get("message") or "nephew bridge error at close")
            else:
                finalize_error = "nephew bridge closed without a finalized event"
        except (OSError, ValueError) as e:
            finalize_error = f"nephew bridge failed during close: {e}"
        bridge.reap()
        if finalize_error is not None:
            if ok:
                raise NephewError(finalize_error)
            # The job's own exception stands; the close problem rides along.
            session.close_error = finalize_error
        return False

    def __call__(self, fn: Callable) -> Callable:
        @functools.wraps(fn)
        def wrapper(*args: Any, **kwargs: Any) -> Any:
            with with_profile(
                self._bundle, self._provider, job=self._job, cli=self._cli,
            ) as session:
                return fn(session, *args, **kwargs)

        return wrapper


def with_profile(
    bundle: str,
    provider: str = "steel",
    *,
    job: Optional[str] = None,
    cli: Optional[str] = None,
) -> _WithProfile:
    """Run inside the carried profile: context manager AND decorator.

        with with_profile(bundle, provider="steel") as session: ...
        @with_profile(bundle, provider="browseruse")
        def job(session): ...

    `bundle` is the owner-held bundle directory; `provider` is "steel",
    "browseruse", or "browserbase" (Modal is CLI-only). `job` labels
    the run and its metrics record (default "python"). `cli` overrides
    how the nephew CLI is located (default: $NEPHEW_CLI, else `nephew`
    on PATH).
    """
    return _WithProfile(bundle, provider, job, cli)

"""The in-sandbox driver answers proxy challenges only (2026-11-01 review)."""
from __future__ import annotations

import importlib.util
import json
import sys
import unittest
from pathlib import Path

DRIVER = Path(__file__).resolve().parents[2] / "tools" / "modal_driver.py"
spec = importlib.util.spec_from_file_location("modal_driver", DRIVER)
modal_driver = importlib.util.module_from_spec(spec)
sys.modules["modal_driver"] = modal_driver
spec.loader.exec_module(modal_driver)


class FakeWs:
    def __init__(self) -> None:
        self.sent: list[dict] = []

    def send_text(self, text: str) -> None:
        self.sent.append(json.loads(text))


def challenge(source: str, request_id: str = "r1") -> dict:
    return {
        "method": "Fetch.authRequired",
        "params": {"requestId": request_id, "authChallenge": {"source": source, "origin": "http://x", "scheme": "basic"}},
    }


class AnswerAuthTest(unittest.TestCase):
    def setUp(self) -> None:
        self.ws = FakeWs()
        self.cdp = modal_driver.Cdp(self.ws)
        self.cdp.proxy_auth = {"username": "zone-user", "password": "zone-pass"}

    def response(self) -> dict:
        return self.ws.sent[-1]["params"]["authChallengeResponse"]

    def test_proxy_challenge_gets_the_credentials_once(self) -> None:
        self.cdp._answer_auth(challenge("Proxy"))
        self.assertEqual(self.response(), {"response": "ProvideCredentials", "username": "zone-user", "password": "zone-pass"})
        self.cdp._answer_auth(challenge("Proxy"))
        self.assertEqual(self.response(), {"response": "CancelAuth"}, "a repeat for the same request means they were rejected")

    def test_a_site_401_never_sees_the_proxy_credentials(self) -> None:
        self.cdp._answer_auth(challenge("Server"))
        self.assertEqual(self.response(), {"response": "CancelAuth"})
        self.cdp._answer_auth(challenge("", "r2"))
        self.assertEqual(self.response(), {"response": "CancelAuth"})
        self.assertFalse(any("zone-pass" in json.dumps(m) for m in self.ws.sent))

    def test_without_credentials_every_challenge_is_cancelled(self) -> None:
        self.cdp.proxy_auth = None
        self.cdp._answer_auth(challenge("Proxy"))
        self.assertEqual(self.response(), {"response": "CancelAuth"})


class StorageGuardTest(unittest.TestCase):
    def test_storage_guard_precedes_access_and_redacts_page_errors(self):
        class Page:
            expression = ""
            def evaluate(self, session, expression):
                self.expression = expression
                raise RuntimeError("page exception with secret value")
        page = Page()
        with self.assertRaisesRegex(modal_driver.DriverError, "storage access refused") as caught:
            modal_driver.origin_storage(page, "s", "https://owner.test", "localStorage.setItem('token', 'secret')")
        self.assertLess(page.expression.index("location.origin !=="), page.expression.index("localStorage.setItem"))
        self.assertNotIn("secret value", str(caught.exception))
        for origin in ("file:///tmp", "https://owner.test/path", "https://user@owner.test"):
            with self.assertRaisesRegex(modal_driver.DriverError, "exact HTTP"):
                modal_driver.origin_storage(page, "s", origin, "1")


if __name__ == "__main__":
    unittest.main()

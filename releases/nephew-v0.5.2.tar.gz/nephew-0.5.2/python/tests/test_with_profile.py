"""Unit tests for the nephew Python package — the bridge subprocess is
stubbed (tests/stub_bridge.py); what's under test is the client:
the ready path, the LOGIN_REQUIRED / refused / plan-limit mappings,
close-on-exception semantics, and the receipt path surfacing on the
session.
"""
import json
import os
import shutil
import sys
import tempfile
import unittest
from pathlib import Path
from unittest import mock

sys.path.insert(0, str(Path(__file__).resolve().parent.parent / "src"))

from nephew import (  # noqa: E402
    GateRefusedError,
    LoginRequiredError,
    NephewError,
    PlanLimitError,
    with_profile,
)

HERE = Path(__file__).resolve().parent


class WithProfileTests(unittest.TestCase):
    def setUp(self) -> None:
        self.tmp = Path(tempfile.mkdtemp(prefix="nephew-py-test-"))
        self.stub = self.tmp / "stub-nephew"
        shutil.copy(HERE / "stub_bridge.py", self.stub)
        self.stub.chmod(0o755)
        self.record = self.tmp / "record.jsonl"
        self.receipt = self.tmp / "run.run-receipt.json"
        patcher = mock.patch.dict(os.environ, {
            "STUB_RECORD": str(self.record),
            "STUB_RECEIPT": str(self.receipt),
        })
        patcher.start()
        self.addCleanup(patcher.stop)
        self.addCleanup(shutil.rmtree, self.tmp, True)

    def set_mode(self, mode: str) -> None:
        os.environ["STUB_MODE"] = mode

    def recorded(self) -> list:
        if not self.record.exists():
            return []
        return [json.loads(l) for l in self.record.read_text(encoding="utf8").splitlines()]

    def open(self, **kwargs):
        return with_profile("/bundles/wp-1", provider="steel", cli=str(self.stub), **kwargs)

    def test_ready_path_context_manager(self) -> None:
        with self.open(job="nightly") as session:
            self.assertEqual(session.cdp_url, "ws://stub.invalid/cdp")
            self.assertEqual(session.session_id, "page-1")
            self.assertEqual(session.profile, "wp-1")
            self.assertEqual(session.provider, "steel")
            self.assertIsNone(session.receipt_path)
        # Finalized at exit: receipt path surfaced, outcome recorded.
        self.assertEqual(session.receipt_path, str(self.receipt))
        self.assertTrue(self.receipt.exists())
        self.assertEqual(session.outcome, "completed")
        lines = self.recorded()
        self.assertEqual([l["type"] for l in lines], ["start", "close"])
        self.assertEqual(lines[0]["bundle"], "/bundles/wp-1")
        self.assertEqual(lines[1]["ok"], True)

    def test_browserbase_provider_passes_through(self) -> None:
        with with_profile("/bundles/wp-1", provider="browserbase", cli=str(self.stub)) as session:
            self.assertEqual(session.provider, "browserbase")
            self.assertEqual(session.profile, "wp-1")
        self.assertEqual(session.outcome, "completed")
        lines = self.recorded()
        self.assertEqual([l["type"] for l in lines], ["start", "close"])
        self.assertEqual(lines[0]["provider"], "browserbase")

    def test_decorator(self) -> None:
        seen = {}

        @self.open()
        def job(session, extra):
            seen["session_id"] = session.session_id
            return f"done-{extra}"

        self.assertEqual(job("x"), "done-x")
        self.assertEqual(seen["session_id"], "page-1")
        self.assertEqual(job.__name__, "job")
        lines = self.recorded()
        self.assertEqual([l["type"] for l in lines], ["start", "close"])

    def test_login_required_mapping(self) -> None:
        self.set_mode("login")
        with self.assertRaises(LoginRequiredError) as cm:
            with self.open():
                pass
        e = cm.exception
        self.assertEqual(e.status, "LOGIN_REQUIRED")
        self.assertEqual(e.designated_human, "Ben")
        self.assertEqual(e.profile, "wp-1")
        self.assertEqual(e.payload["handoff"], None)
        self.assertEqual(e.receipt_path, str(self.receipt))

    def test_refused_mapping(self) -> None:
        self.set_mode("refused")
        with self.assertRaises(GateRefusedError) as cm:
            with self.open():
                pass
        self.assertEqual(cm.exception.changed, ["timezone"])
        self.assertEqual(cm.exception.receipt_path, str(self.receipt))

    def test_plan_limit_mapping(self) -> None:
        self.set_mode("plan-limit")
        with self.assertRaises(PlanLimitError) as cm:
            with self.open():
                pass
        e = cm.exception
        self.assertEqual(e.status, "REFUSED")
        self.assertEqual(e.reason, "plan-limit")
        self.assertEqual(e.plan, "free")
        self.assertEqual(e.limits, {"profiles": 2, "runs": 1})
        self.assertIn("Free runs 1 job at a time", str(e))
        # A plan-limit refusal is not a fingerprint refusal.
        self.assertNotIsInstance(e, GateRefusedError)

    def test_close_on_exception(self) -> None:
        holder = []
        with self.assertRaisesRegex(ValueError, "job blew up"):
            with self.open() as session:
                holder.append(session)
                raise ValueError("job blew up")
        session = holder[0]
        self.assertEqual(session.outcome, "job-failed")
        self.assertEqual(session.receipt_path, str(self.receipt))
        lines = self.recorded()
        self.assertEqual(lines[-1]["type"], "close")
        self.assertEqual(lines[-1]["ok"], False)
        self.assertIn("ValueError", lines[-1]["error"])

    def test_bridge_error_surfaces(self) -> None:
        self.set_mode("error")
        with self.assertRaisesRegex(NephewError, "boom from the stub bridge"):
            with self.open():
                pass

    def test_missing_cli_is_a_clear_error(self) -> None:
        with mock.patch.dict(os.environ, {}, clear=False):
            os.environ.pop("NEPHEW_CLI", None)
            with mock.patch("nephew.shutil.which", return_value=None):
                with self.assertRaisesRegex(NephewError, "nephew CLI not found"):
                    with with_profile("/bundles/wp-1", provider="steel"):
                        pass


if __name__ == "__main__":
    unittest.main()

/**
 * cdp — a minimal Chrome DevTools Protocol client, plus Chromium launchers.
 * No dependencies: the adapters and the proof scripts speak CDP directly,
 * the way the spikes did. Two transports: a WebSocket to a loopback
 * debugging port (the run paths), and — for the capture browser — the
 * --remote-debugging-pipe stdio pair, which opens no TCP listener at all
 * (2026-11-01 hardening; an unauthenticated loopback port is reachable by
 * any local user for the life of the capture).
 */
import { spawn, type ChildProcess } from "node:child_process";
import type { Readable, Writable } from "node:stream";
import { setTimeout as sleep } from "node:timers/promises";

/**
 * Default ceiling for any single CDP call. A dropped connection (the Bright
 * Data relay has dropped one in every Amazon run so far) otherwise leaves
 * the reply promise pending forever and the caller hangs silently. No caller
 * may wait longer than this unless it explicitly passes a larger timeout.
 */
export const CDP_DEFAULT_TIMEOUT_MS = 30_000;

export class CdpTimeoutError extends Error {
  constructor(method: string, timeoutMs: number) {
    super(`CDP ${method} timed out after ${timeoutMs} ms`);
    this.name = "CdpTimeoutError";
  }
}

/**
 * A CDP event subscriber (Fetch.requestPaused, Page.loadEventFired, …).
 * Events are the messages WITHOUT an id: { method, params, sessionId? }.
 */
export type CdpEventHandler = (params: any, sessionId?: string) => void;

interface PendingCall {
  resolve: (msg: any) => void;
  reject: (err: Error) => void;
  timer: ReturnType<typeof setTimeout>;
}

export class CdpClient {
  private ws: WebSocket;
  private nextId = 0;
  private pending = new Map<number, PendingCall>();
  private eventHandlers = new Map<string, Set<CdpEventHandler>>();
  private closedFlag = false;

  // Public so tests can inject a fake transport; production code uses connect().
  constructor(ws: WebSocket) {
    this.ws = ws;
    ws.onmessage = (ev: any) => {
      const msg = JSON.parse(typeof ev.data === "string" ? ev.data : ev.data.toString());
      if (msg.method) {
        // An event, not a call reply. Handlers must never break routing:
        // their exceptions are swallowed here (a handler that cares about
        // its own failures probes/records them itself).
        const handlers = this.eventHandlers.get(msg.method);
        if (handlers) {
          for (const handler of handlers) {
            try { handler(msg.params ?? {}, msg.sessionId); } catch { /* see above */ }
          }
        }
      }
      if (msg.id && this.pending.has(msg.id)) {
        const call = this.pending.get(msg.id)!;
        this.pending.delete(msg.id);
        clearTimeout(call.timer);
        call.resolve(msg);
      }
    };
  }

  /**
   * Subscribe to a CDP event (e.g. "Fetch.requestPaused"). Returns an
   * unsubscribe function. Events arrive on the same websocket as call
   * replies; with flatten-mode sessions they carry the emitting session's
   * id, which is passed to the handler.
   */
  onEvent(method: string, handler: CdpEventHandler): () => void {
    let set = this.eventHandlers.get(method);
    if (!set) {
      set = new Set();
      this.eventHandlers.set(method, set);
    }
    set.add(handler);
    return () => { set.delete(handler); };
  }

  /**
   * Open the websocket. Bounded: an endpoint that accepts TCP but never
   * completes the handshake used to hang the caller forever (and the
   * openers' retry loops never saw a rejection to retry on).
   */
  static async connect(wsUrl: string, timeoutMs: number = CDP_DEFAULT_TIMEOUT_MS): Promise<CdpClient> {
    const ws = new WebSocket(wsUrl);
    await new Promise<void>((resolve, reject) => {
      const timer = setTimeout(() => {
        try { ws.close(); } catch { /* never opened */ }
        reject(new CdpTimeoutError("websocket connect", timeoutMs));
      }, timeoutMs);
      ws.onopen = () => { clearTimeout(timer); resolve(); };
      ws.onerror = (e: any) => { clearTimeout(timer); reject(new Error("CDP websocket error: " + (e?.message ?? e))); };
      ws.onclose = () => { clearTimeout(timer); reject(new Error("CDP websocket closed before it opened")); };
    });
    const client = new CdpClient(ws);
    // A remote close (the browser exited, the provider dropped the session)
    // fails every call in flight at once instead of after the 30 s ceiling.
    ws.onclose = () => client.close();
    return client;
  }

  async send(
    method: string,
    params: Record<string, unknown> = {},
    sessionId?: string,
    timeoutMs: number = CDP_DEFAULT_TIMEOUT_MS,
  ): Promise<any> {
    const id = ++this.nextId;
    const reply = new Promise<any>((resolve, reject) => {
      const timer = setTimeout(() => {
        this.pending.delete(id);
        reject(new CdpTimeoutError(method, timeoutMs));
      }, timeoutMs);
      this.pending.set(id, { resolve, reject, timer });
    });
    try {
      this.ws.send(JSON.stringify({ id, method, params, ...(sessionId ? { sessionId } : {}) }));
    } catch (e) {
      const call = this.pending.get(id);
      if (call) {
        clearTimeout(call.timer);
        this.pending.delete(id);
      }
      throw e;
    }
    const msg = await reply;
    if (msg.error) throw new Error(`CDP ${method} failed: ${JSON.stringify(msg.error)}`);
    return msg.result;
  }

  /** Attach to the first page target and return its sessionId. */
  async attachToFirstPage(port: number): Promise<string> {
    const targets = await (await fetch(`http://127.0.0.1:${port}/json/list`)).json();
    const page = targets.find((t: any) => t.type === "page") ?? targets[0];
    const { sessionId } = await this.send("Target.attachToTarget", { targetId: page.id, flatten: true });
    return sessionId as string;
  }

  /**
   * Attach to the first page target over the browser-level connection
   * itself. The pipe transport has no /json/list HTTP endpoint to ask;
   * Target.getTargets over CDP is the same list. (TargetInfo carries
   * `targetId`, where /json/list calls it `id`.)
   */
  async attachToFirstPageViaTargets(): Promise<string> {
    const { targetInfos } = await this.send("Target.getTargets");
    const page = (targetInfos ?? []).find((t: any) => t.type === "page") ?? (targetInfos ?? [])[0];
    if (!page) throw new Error("CDP attach: the browser reported no targets");
    const { sessionId } = await this.send("Target.attachToTarget", { targetId: page.targetId, flatten: true });
    return sessionId as string;
  }

  async evaluate<T>(sessionId: string, expression: string, timeoutMs: number = CDP_DEFAULT_TIMEOUT_MS): Promise<T> {
    const r = await this.send(
      "Runtime.evaluate",
      { expression, returnByValue: true, awaitPromise: true },
      sessionId,
      timeoutMs,
    );
    if (r.exceptionDetails) {
      throw new Error("evaluate failed: " + JSON.stringify(r.exceptionDetails).slice(0, 300));
    }
    return r.result?.value as T;
  }

  /** True once this connection has been closed, by us or by the remote end. */
  get isClosed(): boolean {
    return this.closedFlag;
  }

  close(): void {
    this.closedFlag = true;
    // Fail anything still in flight rather than leaving it to the timeout.
    for (const call of this.pending.values()) {
      clearTimeout(call.timer);
      call.reject(new Error("CDP connection closed"));
    }
    this.pending.clear();
    try { this.ws.close(); } catch { /* already closed */ }
  }
}

/**
 * The --remote-debugging-pipe transport: CDP messages as NUL-delimited
 * JSON over the browser's stdio pair (the parent writes commands to the
 * browser's fd 3, reads its messages from fd 4). Exposes the surface
 * CdpClient consumes from a WebSocket — assignable onmessage, send,
 * close — plus onclose, fired when the browser's end of the pipe goes
 * away. No socket exists at any point: the protocol never leaves the
 * parent↔child channel, so no other local user can reach it.
 */
export class CdpPipeTransport {
  onmessage: ((ev: { data: string }) => void) | null = null;
  onclose: (() => void) | null = null;
  private read: Readable;
  private write: Writable;
  private buffer = "";
  private queued: string[] = [];
  private closed = false;

  constructor(read: Readable, write: Writable) {
    this.read = read;
    this.write = write;
    read.setEncoding("utf8");
    read.on("data", (chunk: string) => {
      this.buffer += chunk;
      let at = this.buffer.indexOf("\0");
      while (at >= 0) {
        const msg = this.buffer.slice(0, at);
        this.buffer = this.buffer.slice(at + 1);
        if (msg) this.deliver(msg);
        at = this.buffer.indexOf("\0");
      }
    });
    const gone = () => {
      if (this.closed) return;
      this.closed = true;
      this.onclose?.();
    };
    read.on("end", gone);
    read.on("error", gone);
    write.on("error", gone);
  }

  private deliver(data: string): void {
    // A message can beat the client's onmessage assignment by a tick on
    // a fast start; hold it rather than dropping the browser's first
    // words, and flush in order once a handler exists.
    if (!this.onmessage) {
      this.queued.push(data);
      return;
    }
    if (this.queued.length) {
      const held = this.queued.splice(0);
      for (const heldData of held) this.onmessage({ data: heldData });
    }
    this.onmessage({ data });
  }

  send(data: string): void {
    this.write.write(data + "\0");
  }

  close(): void {
    if (this.closed) return;
    this.closed = true;
    try { this.write.end(); } catch { /* already gone */ }
    try { this.read.destroy(); } catch { /* already gone */ }
  }
}

export interface LaunchedBrowser {
  process: ChildProcess;
  /** TCP debugging port; 0 when the browser was launched over the pipe. */
  port: number;
  /** WebSocket debugger URL; "" when the browser was launched over the pipe. */
  wsUrl: string;
  /** How CDP reaches this browser. Absent on hand-built test doubles. */
  transport?: "tcp" | "pipe";
  cdp: CdpClient;
  sessionId: string;
  close(): Promise<void>;
}

/**
 * The environment a launched browser gets: what a desktop session needs to
 * draw and find its files, and nothing else. The CLI's own environment
 * carries PROFILE_ENCRYPTION_KEY and every provider key; a renderer
 * compromise during capture must not find them in /proc/self/environ.
 */
export function browserEnv(env: NodeJS.ProcessEnv = process.env): NodeJS.ProcessEnv {
  const keep = [
    "PATH", "HOME", "USER", "LOGNAME", "SHELL", "TMPDIR", "TMP", "TEMP", "LANG", "LANGUAGE", "TZ",
    "DISPLAY", "WAYLAND_DISPLAY", "XAUTHORITY", "DBUS_SESSION_BUS_ADDRESS", "XDG_RUNTIME_DIR",
    "XDG_SESSION_TYPE", "XDG_DATA_DIRS", "XDG_CONFIG_HOME", "XDG_CACHE_HOME", "FONTCONFIG_FILE",
    "LD_LIBRARY_PATH", "SYSTEMROOT", "SystemRoot", "WINDIR", "APPDATA", "LOCALAPPDATA", "USERPROFILE", "ProgramData",
  ];
  const out: NodeJS.ProcessEnv = {};
  for (const k of Object.keys(env)) {
    if (keep.includes(k) || k.startsWith("LC_")) out[k] = env[k];
  }
  return out;
}

export async function launchChromium(
  exe: string,
  args: string[],
  port: number,
): Promise<LaunchedBrowser> {
  const proc = spawn(exe, [
    ...args,
    `--remote-debugging-port=${port}`,
    "--remote-debugging-address=127.0.0.1",
    "about:blank",
  ], { stdio: "ignore", env: browserEnv() });

  let wsUrl = "";
  for (let i = 0; i < 60 && !wsUrl; i++) {
    try {
      const r = await fetch(`http://127.0.0.1:${port}/json/version`);
      wsUrl = (await r.json()).webSocketDebuggerUrl;
    } catch { await sleep(500); }
  }
  if (!wsUrl) {
    proc.kill("SIGKILL");
    throw new Error(`Chromium did not open a CDP endpoint on port ${port}`);
  }
  const cdp = await CdpClient.connect(wsUrl);
  const sessionId = await cdp.attachToFirstPage(port);
  await cdp.send("Page.enable", {}, sessionId);
  await cdp.send("Runtime.enable", {}, sessionId);
  return {
    process: proc, port, wsUrl, transport: "tcp", cdp, sessionId,
    async close() {
      cdp.close();
      proc.kill("SIGKILL");
    },
  };
}

/**
 * Launch Chromium with CDP over --remote-debugging-pipe instead of a
 * debugging port: the browser's fds 3/4 carry the protocol, and nothing
 * listens on any socket. Used by the capture browser, which holds the
 * owner's live logins while a person works in it — the window where an
 * unauthenticated loopback port is exposed to every local user.
 *
 * A launch failure says why: the browser's stderr tail rides the error
 * (a sandbox refusal, a missing binary), where the port-polling launcher
 * could only report that nothing answered.
 */
export async function launchChromiumPipe(
  exe: string,
  args: string[],
): Promise<LaunchedBrowser> {
  const proc = spawn(exe, [
    ...args,
    "--remote-debugging-pipe",
    "about:blank",
  ], { stdio: ["ignore", "ignore", "pipe", "pipe", "pipe"], env: browserEnv() });

  let stderrTail = "";
  proc.stderr?.on("data", (d: Buffer) => {
    stderrTail = (stderrTail + d.toString()).slice(-4096);
  });
  let spawnErr: Error | null = null;
  proc.once("error", (e) => { spawnErr = e; });
  // Read through a getter: the assignment happens in the error callback,
  // which the type checker's flow analysis cannot see.
  const getSpawnErr = (): Error | null => spawnErr;

  const transport = new CdpPipeTransport(
    proc.stdio[4] as Readable,
    proc.stdio[3] as Writable,
  );
  const cdp = new CdpClient(transport as unknown as WebSocket);
  // The browser going away (exit, crash) fails every call in flight at
  // once, exactly as a websocket close does on the TCP path.
  transport.onclose = () => cdp.close();

  const launchFailure = (what: string): Error => {
    const tail = stderrTail.trim();
    return new Error(
      `Chromium ${what}` + (tail ? ` — the browser said: ${tail.split("\n").slice(-3).join(" | ")}` : ""),
    );
  };

  try {
    // Readiness: Target.getTargets with a short ceiling until the
    // browser answers, inside a 30 s deadline. A timed-out probe's late
    // reply is harmless (its id is no longer pending and is ignored);
    // a dead browser rejects the probe at once through the transport
    // close above.
    let ready = false;
    const deadline = Date.now() + 30_000;
    while (!ready && Date.now() < deadline) {
      if (getSpawnErr()) throw launchFailure(`could not be started (${getSpawnErr()!.message})`);
      if (proc.exitCode !== null) throw launchFailure(`exited with code ${proc.exitCode} before CDP answered`);
      try {
        await cdp.send("Target.getTargets", {}, undefined, 3_000);
        ready = true;
      } catch (e) {
        if (getSpawnErr()) throw launchFailure(`could not be started (${getSpawnErr()!.message})`);
        if (proc.exitCode !== null || (e instanceof Error && /connection closed/i.test(e.message))) {
          throw launchFailure("died before CDP answered");
        }
        await sleep(500);
      }
    }
    if (!ready) throw launchFailure("did not answer CDP over --remote-debugging-pipe within 30 s");
    const sessionId = await cdp.attachToFirstPageViaTargets();
    await cdp.send("Page.enable", {}, sessionId);
    await cdp.send("Runtime.enable", {}, sessionId);
    return {
      process: proc, port: 0, wsUrl: "", transport: "pipe", cdp, sessionId,
      async close() {
        cdp.close();
        proc.kill("SIGKILL");
      },
    };
  } catch (e) {
    try { cdp.close(); } catch { /* already closed */ }
    try { proc.kill("SIGKILL"); } catch { /* already dead */ }
    throw e;
  }
}

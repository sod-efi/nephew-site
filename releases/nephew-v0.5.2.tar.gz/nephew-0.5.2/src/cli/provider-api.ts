/**
 * cli/provider-api — direct provider API access for the managed-cloud
 * runners (src/cli/run-baseline.ts).
 *
 * v0.4.0 shelled out to vault-backed helper CLIs that exist only on the
 * maintainer's machine, so every non-Modal run failed for an outside user
 * and the keys `nephew init` verifies were never the keys `run` used.
 * This module is the fix: the CLI calls the provider APIs itself, with
 * the customer's OWN key, read from the environment variable that
 * `nephew init` verified and recorded as a reference in
 * ~/.nephew/config.json (cli/config.ts — values never stored). One key
 * source for init and run, by construction.
 *
 * Discipline (unchanged from the vault-CLI era): response bodies are
 * never logged (they carry session capability URLs), error surfaces
 * name the HTTP status only, and a missing key fails with the init
 * instruction — never a prompt for the value.
 */
import { loadNephewConfig, nephewConfigPath, type NephewConfig } from "./config.ts";

export type ManagedProvider = "steel" | "browseruse" | "browserbase";

export interface ProviderApiSpec {
  base: string;
  /** Header the provider expects its API key in. */
  header: string;
  /** Env var `nephew init` verifies when the config names no other. */
  defaultSecretEnv: string;
  label: string;
}

export const PROVIDER_API: Record<ManagedProvider, ProviderApiSpec> = {
  steel: {
    base: "https://api.steel.dev",
    header: "steel-api-key",
    defaultSecretEnv: "STEEL_API_KEY",
    label: "Steel",
  },
  browseruse: {
    base: "https://api.browser-use.com",
    header: "X-Browser-Use-API-Key",
    defaultSecretEnv: "BROWSER_USE_API_KEY",
    label: "Browser Use",
  },
  browserbase: {
    base: "https://api.browserbase.com",
    header: "X-BB-API-Key",
    defaultSecretEnv: "BROWSERBASE_API_KEY",
    label: "Browserbase",
  },
};

type FetchFn = (
  url: string,
  init?: {
    method?: string;
    headers?: Record<string, string>;
    body?: string;
    signal?: AbortSignal;
  },
) => Promise<{ ok: boolean; status: number; text: () => Promise<string> }>;

export interface ProviderApiDeps {
  env?: NodeJS.ProcessEnv;
  fetchFn?: FetchFn;
  /** Pre-loaded config (tests); default: read from configPath. */
  config?: NephewConfig | null;
  configPath?: string;
}

/**
 * The env var that holds this provider's key on this machine: the
 * reference `nephew init` recorded in the config when there is one,
 * else the standard name init verifies.
 */
export function providerSecretEnv(
  provider: ManagedProvider,
  config: NephewConfig | null,
): string {
  return config?.providers[provider]?.secretEnv ?? PROVIDER_API[provider].defaultSecretEnv;
}

let configCache: { path: string; promise: Promise<NephewConfig | null> } | undefined;

function loadConfigCached(path: string): Promise<NephewConfig | null> {
  if (!configCache || configCache.path !== path) {
    configCache = { path, promise: loadNephewConfig(path) };
  }
  return configCache.promise;
}

/**
 * One provider API call with the customer's key. Returns the parsed
 * body ({} for an empty one). Throws an error naming the provider and
 * the HTTP status — never the body, never the key.
 */
export async function providerApi(
  provider: ManagedProvider,
  method: string,
  path: string,
  body?: string,
  deps: ProviderApiDeps = {},
): Promise<any> {
  const spec = PROVIDER_API[provider];
  const env = deps.env ?? process.env;
  const config = deps.config !== undefined
    ? deps.config
    : await loadConfigCached(deps.configPath ?? nephewConfigPath(env));
  const envName = providerSecretEnv(provider, config);
  const key = env[envName];
  if (!key) {
    throw new Error(
      `${spec.label} is not connected — ${envName} is not set in the environment. ` +
      `Run \`nephew init\` to connect your ${spec.label} account, then retry.`,
    );
  }
  const fetchFn = deps.fetchFn ?? (fetch as unknown as FetchFn);
  let res: { ok: boolean; status: number; text: () => Promise<string> };
  try {
    res = await fetchFn(`${spec.base}${path}`, {
      method,
      headers: {
        [spec.header]: key,
        Accept: "application/json",
        ...(body ? { "Content-Type": "application/json" } : {}),
      },
      ...(body ? { body } : {}),
      signal: AbortSignal.timeout(120_000),
    });
  } catch (e) {
    throw new Error(`${spec.label} API ${method} ${path} failed (network: ${(e as Error).name || "error"})`);
  }
  if (!res.ok) {
    throw new Error(`${spec.label} API ${method} ${path} failed (HTTP ${res.status})`);
  }
  const text = await res.text();
  if (!text.trim()) return {};
  try {
    return JSON.parse(text);
  } catch {
    throw new Error(`${spec.label} API ${method} ${path} returned an unreadable body`);
  }
}

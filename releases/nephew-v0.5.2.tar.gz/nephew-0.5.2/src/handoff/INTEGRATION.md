# handoff — integration note

Everything the handoff feature changed **outside** `src/handoff/`, and
why. The module itself (`types.ts`, `session.ts`, `server.ts`,
`record.ts`, `index.ts`, `README.md`) is new and self-contained.

## Wiring changes

### `src/cli/run-baseline.ts`
- `BaselineOutcome` gains optional `handoffControl` and a new
  `BaselineHoldOptions` ({ holdForHandoff }) parameter on
  `runSteelBaseline` / `runBrowserUseBaseline`.
- Why: the live provider session existed only inside these runners and
  was closed in all paths. When asked to hold and the restore does not
  verify (gate held), the runner now returns the session as a
  `HandoffControlSource` ({ cdp, sessionId, captureBack, close }) via
  the new private `controlFrom()` instead of closing it — ownership
  transfers to run-core. `captureBack` reuses the already-imported
  `captureState`/`decryptState` (bundled origins only).
- Behavior preserved: without the hold flag, verified, gate-refused,
  and throwing runs close the session exactly as before (close-on-throw
  kept explicitly).

### `src/cli/run-core.ts`
- `RunOutcome` "login-required" gains optional `handoff` (the
  serializable handle), `handoffSession` (the live session object),
  and `handoffUnavailable` (reason string). `runProfileJob` input gains
  `handoff?: RunHandoffOptions` and `onHandoffRequired`, and
  `RunCoreDeps` gains the `openHandoffFn` test seam.
- Why: run-core is the one run path behind both surfaces. It forwards
  the hold flag to steel/browseruse, and on login-required it starts
  the handoff over the held session, emits the **`handoff_required`
  signal** ({ type, handle }) to `onHandoffRequired`, and logs the
  handoff lines. Teardown hooks live here: on "resume",
  `onBeforeTeardown` captures the live state and seals it into the
  owner bundle (`saveBundle` + `encryptState`); `onTeardown` runs the
  runner's normal session close. Every fallback path (no control, no
  designated human, handoff start failure) closes the held session so
  it never leaks, and reports `handoffUnavailable` instead of a handle.
- Modal: no hold is requested (its runner has no host-side CDP), so a
  Modal pause reports the documented `handoffUnavailable` reason.

### `src/cli/args.ts`
- `RunCommand` gains optional `handoff: { ttlMs?, port? }` (the key is
  omitted entirely when no handoff flag was given, keeping the parsed
  shape for plain runs byte-identical). New flags: `--handoff`,
  `--handoff-ttl <seconds>` (positive integer), `--handoff-port <n>`
  (0–65535), with validation errors in the existing style. `USAGE` /
  `RUN_USAGE` document them.

### `src/nephew.ts`
- `runCommand` passes the parsed handoff options into `runProfileJob`;
  on login-required with a live handoff it prints the wait line, awaits
  `handoffSession.waitForOutcome()`, and prints the closing line for
  resumed / ended / expired / aborted (exit code stays 1 — the job did
  not complete). With `handoffUnavailable` + `--handoff` it prints the
  reason and the re-capture fallback. Without `--handoff` the output is
  unchanged (single failure line).
- `MainDeps` gains a `run` seam (typeof runProfileJob) so the CLI's
  handoff behavior is unit-testable without a provider; `main()` passes
  deps through to `runCommand`.

### `src/mcp/server.ts`
- `profile_run` gains an optional `handoff` boolean argument (default
  true — the MCP pause exists to be routed; pass `handoff: false` to
  opt out), forwarded to run-core.
- The `LOGIN_REQUIRED` structured result keeps its shape and gains the
  **`handoff` field** (the handle, or null) plus `handoffUnavailable`
  when a handoff was requested but impossible; the `action` text
  branches to describe routing the live handoff when a handle exists.

## Tests (new files)

- `test/handoff.test.ts` — the module over a fake CDP transport + fake
  clock: screencast start/ack/relay, input forwarding, token
  rejection, expiry at the absolute deadline incl. delayed entry and
  wall-clock jumps, single-session and single-controller enforcement,
  teardown idempotence, input validation, and the loopback HTTP
  surface (page, SSE frames, 401/409, resume).
- `test/handoff-wiring.test.ts` — the seams above: run-core signal +
  capture-back sealing + ownership on fallback paths, MCP handle field
  and default-enable, CLI flag parsing, CLI print/wait behavior, and
  the unchanged no-handoff outcome.

## Receipts follow-up (landed after this note was first written)

- Run-core now consumes the event record: for a live-handoff run, the
  signed run receipt (src/receipts/) is issued at handoff teardown,
  chained off `waitForOutcome()`, and reads the finalized record from
  `handle.eventFile` for the receipt's `endedAt` and
  `humanAttentionMinutes` (the record's startedAt → endedAt span),
  with `handoffUsed: true`. See src/receipts/INTEGRATION.md. The
  handoff module itself needed no change for this — the record was
  already the interface.

## Explicitly NOT changed

- `src/cli/receipt.ts`, `src/cli/revoke.ts`, and all receipts/revoke
  code — untouched, per the build brief. The handoff event record
  (README.md) is the interface the receipts work consumes.
- `src/cli/run-modal.ts` — Modal's in-sandbox driver exposes no
  host-side CDP session; the limit is surfaced, not faked.
- `src/with-profile.ts` — a job function that throws `LoginRequiredError`
  still closes its session in `finally`; offering it the same live
  handoff is a follow-up that can reuse `HandoffControlSource` from
  `openBrowserUseSession`/`openSteelSession` unchanged.

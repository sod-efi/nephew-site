# handoff — challenge recovery via streamed human handoff

When a run's carried login does not hold, the run pauses at
`LOGIN_REQUIRED`. Until now the only recovery was a full re-capture
(`nephew capture`) and a retry. This module adds the live option: the
profile's **designated human takes over the running provider session**
in their own browser, fixes the login/challenge in place, and hands
control back.

## How it works

1. A baseline runner (steel / browseruse) whose restore does not verify
   can **lend its live session** to the handoff instead of closing it:
   it returns a `HandoffControlSource` ({ cdp, sessionId, captureBack?,
   close }) with its result. Nothing changes when no handoff is
   requested — the runner closes the session exactly as before.
2. Run-core (`src/cli/run-core.ts`), when handoff is enabled on the run,
   starts a `HandoffSession` over that CDP connection and emits a
   **`handoff_required` signal** carrying the `HandoffHandle`
   ({ handoffId, url, token, designatedHuman, profile, provider, job,
   startedAt, expiresAt, eventFile }). `nephew run` prints the handoff
   URL + token; the MCP `profile_run` result gains a `handoff` field
   with the same handle.
3. The human opens the URL. The loopback page (127.0.0.1 only) streams
   the live page from CDP `Page.startScreencast` frames (relayed over
   Server-Sent Events as JPEG data URLs) and forwards their input back:
   mouse via `Input.dispatchMouseEvent`, keyboard via
   `Input.dispatchKeyEvent`. Frames are acked
   (`Page.screencastFrameAck`) as CDP requires.
4. The human clicks **Done — hand control back** (resume) or **End the
   run** (end), or the deadline expires the handoff. Resuming runs the
   control source's capture-back: the live state is captured and
   run-core seals it into the owner bundle, so the next run starts from
   the fixed login. Ending/expiring captures nothing.

## Rules (enforced, not advisory)

- **Single session.** At most one handoff is active per process
  (`HandoffBusyError` otherwise), and at most one controller stream may
  attach to it (a second `/events` gets HTTP 409).
- **Designated human only.** Every route requires the per-handoff
  token, minted fresh at start (192-bit random) and bound to the
  bundle's `manifest.designatedHuman`. A bundle with no designated
  human cannot start a handoff. The CLI prints the token at the owner's
  own terminal; it is single-handoff, loopback-only, and expires with
  the handoff. It is never written to run metrics or the event record.
- **Hard expiry, absolute monotonic cutoff.** Default **360 s**,
  configurable per run (`ttlMs`). The deadline is computed from a
  monotonic clock at start; late arrival, page reloads, stream
  reconnects, and wall-clock changes cannot extend it (the R15 lesson:
  delayed entry cannot extend acceptance). The session's own timer
  tears it down at the deadline; every entry point re-checks it too.
- **Clean teardown, ownership respected.** Teardown runs exactly once:
  stop screencast, unsubscribe, finalize the event record, then the
  owner's `onTeardown` (capture-back + the runner's normal session
  close). The handoff never closes the CDP client itself — the run
  owns the provider session end to end.
- **Modal limit (documented, not faked).** The Modal runner drives its
  browser from inside the sandbox and exposes no host-side CDP session,
  so a live handoff cannot attach there yet — the same limit
  `withProfile` documents. A Modal run that needs a login still returns
  the plain `LOGIN_REQUIRED` pause with no handoff handle.

## Event record (for the receipts work)

One plain JSON file per handoff, written at start (outcome `active`)
and finalized at teardown:

- **Default path:** `runs/handoffs/<YYYY-MM-DD>-<profile>-<handoffId>.json`
  (scaffold-relative; overridable via `eventDir` / `eventFile`, and the
  exact path is always in `handle.eventFile`).

Schema (version 1):

```json
{
  "version": 1,
  "handoffId": "a1b2c3d4e5f6",
  "profile": "ben-main",
  "designatedHuman": "Ben",
  "provider": "steel",
  "job": "nightly",
  "startedAt": "2026-10-30T00:00:00.000Z",
  "expiresAt": "2026-10-30T00:06:00.000Z",
  "resumedAt": "2026-10-30T00:03:12.000Z",
  "endedAt": "2026-10-30T00:03:12.000Z",
  "outcome": "resumed",
  "framesRelayed": 412,
  "inputEventsForwarded": 37,
  "captureBackAttempted": true
}
```

- `outcome`: `active` | `resumed` | `ended` | `expired` | `aborted`.
- `resumedAt` is set only for `resumed`; `endedAt` is set at any
  teardown (including resume — it is when the handoff ended).
- Counts and identifiers only: no frames, no keystrokes, no page
  content, no token, no profile state (AGENTS.md #3).

## API

- `openHandoff(opts)` → { session, server, handle } — start + bind.
- `HandoffSession` — lifecycle: `forwardInput`, `claimController`,
  `onFrame`, `resume()`, `end()`, `abort()`, `waitForOutcome()`,
  `snapshot()`, `tokenOk()`, `expired`.
- `bindHandoffServer(session, { host, port })` — the loopback page:
  `GET /`, `GET /events` (SSE frames), `POST /input`, `POST /resume`,
  `POST /end`, `GET /status`; all token-gated.
- `formatHandoffLines(handle)` — the CLI's printed lines (pure).

/**
 * handoff — challenge recovery via streamed human handoff.
 *
 * When a run pauses at LOGIN_REQUIRED, the profile's designated human can
 * take over the LIVE provider session in their browser: the page is
 * streamed from the session's own CDP screencast, their mouse/keyboard
 * is forwarded back over CDP, and a hard absolute deadline (default
 * 360 s) ends the handoff no matter what. See README.md for the design
 * and the event-record schema the receipts work consumes.
 */
import { startHandoffSession, type HandoffSession } from "./session.ts";
import { bindHandoffServer, type HandoffServer } from "./server.ts";
import type { HandoffHandle, HandoffSessionOptions } from "./types.ts";

export * from "./types.ts";
export * from "./record.ts";
export {
  HandoffSession, startHandoffSession, activeHandoff,
  HandoffBusyError, HandoffExpiredError, HandoffEndedError,
} from "./session.ts";
export { bindHandoffServer, handoffPageHtml, validateHandoffInput, type HandoffServer } from "./server.ts";

export interface OpenHandoff {
  session: HandoffSession;
  server: HandoffServer;
  handle: HandoffHandle;
}

/**
 * Start a handoff and bind its loopback server in one call — the shape
 * run-core uses. The server closes itself when the session tears down.
 */
export async function openHandoff(
  opts: HandoffSessionOptions & { serverHost?: string; serverPort?: number },
): Promise<OpenHandoff> {
  const session = await startHandoffSession(opts);
  let server: HandoffServer;
  try {
    server = await bindHandoffServer(session, { host: opts.serverHost ?? opts.host, port: opts.serverPort ?? opts.port });
  } catch (e) {
    await session.abort();
    throw e;
  }
  void session.waitForOutcome().then(() => server.close()).catch(() => { /* already closed */ });
  return { session, server, handle: session.handle };
}

/** The lines `nephew run` prints when a handoff is offered. Pure. */
export function formatHandoffLines(handle: HandoffHandle): string[] {
  return [
    `handoff     ${handle.designatedHuman} — take over the live session: ${handle.url}`,
    `handoff     token ${handle.token} · expires ${handle.expiresAt} (hard deadline, cannot be extended)`,
    `handoff     record ${handle.eventFile}`,
  ];
}

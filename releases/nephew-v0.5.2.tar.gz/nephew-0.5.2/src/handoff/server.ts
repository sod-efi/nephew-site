/**
 * handoff/server — the loopback page the designated human drives.
 *
 *   GET  /            the takeover page (token required)
 *   GET  /events      Server-Sent Events: screencast frames as data URLs
 *                     (single controller — a second stream gets 409)
 *   POST /input       one mouse/key event -> Input.dispatch* on the page
 *   POST /resume      hand control back to the run
 *   POST /end         end the handoff (and the run's pause) outright
 *   GET  /status      session snapshot (counts, expiry)
 *
 * Every route requires the per-handoff token (query ?token=, the
 * x-handoff-token header, or a JSON body field). The server binds
 * 127.0.0.1 only. Frames are relayed from the session's CDP
 * Page.startScreencast stream — this layer holds no browser state.
 */
import { createServer, type Server } from "node:http";
import type { HandoffSession } from "./session.ts";
import { HandoffEndedError, HandoffExpiredError } from "./session.ts";
import type { HandoffInputEvent } from "./types.ts";

export interface HandoffServer {
  server: Server;
  /** The URL the CLI prints (token included — it is the human's key). */
  url: string;
  close(): Promise<void>;
}

function escapeHtml(s: string): string {
  return s.replace(/[&<>"']/g, (c) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[c]!));
}

export function handoffPageHtml(session: HandoffSession): string {
  const h = session.handle;
  return `<!doctype html>
<html lang="en"><head><meta charset="utf-8">
<title>Nephew handoff — ${escapeHtml(h.profile)}</title>
<style>body{font-family:system-ui;margin:16px;background:#111;color:#eee}
img{max-width:100%;border:1px solid #444;background:#000}
button{margin-right:8px;padding:8px 14px;font-size:15px}
#meta{opacity:.8;margin:8px 0}</style></head>
<body>
<h2>Take over: ${escapeHtml(h.profile)}</h2>
<div id="meta">Designated human: ${escapeHtml(h.designatedHuman)} · job ${escapeHtml(h.job)} on ${escapeHtml(h.provider)} ·
expires <span id="exp">${escapeHtml(h.expiresAt)}</span> (hard deadline — it cannot be extended)</div>
<img id="screen" alt="live browser session">
<div style="margin-top:10px">
<button id="resume">Done — hand control back</button>
<button id="end">End the run</button>
<span id="state"></span>
</div>
<script>
const token = new URLSearchParams(location.search).get("token");
const img = document.getElementById("screen");
const state = document.getElementById("state");
const es = new EventSource("/events?token=" + encodeURIComponent(token));
es.onmessage = (m) => { const f = JSON.parse(m.data); img.src = "data:image/jpeg;base64," + f.data; };
es.onerror = () => { state.textContent = "stream closed"; };
async function post(path, body) {
  const r = await fetch(path, { method: "POST", headers: { "content-type": "application/json", "x-handoff-token": token }, body: JSON.stringify(body || {}) });
  if (!r.ok) { state.textContent = path + " -> " + r.status; }
  return r;
}
function scale(e) {
  const r = img.getBoundingClientRect();
  return { x: Math.round((e.clientX - r.left) * (img.naturalWidth / r.width)), y: Math.round((e.clientY - r.top) * (img.naturalHeight / r.height)) };
}
img.addEventListener("mousemove", (e) => { const p = scale(e); post("/input", { event: { kind: "mouse", type: "mouseMoved", x: p.x, y: p.y } }); });
img.addEventListener("mousedown", (e) => { const p = scale(e); post("/input", { event: { kind: "mouse", type: "mousePressed", x: p.x, y: p.y, button: "left", clickCount: 1 } }); });
img.addEventListener("mouseup", (e) => { const p = scale(e); post("/input", { event: { kind: "mouse", type: "mouseReleased", x: p.x, y: p.y, button: "left", clickCount: 1 } }); });
img.addEventListener("wheel", (e) => { const p = scale(e); post("/input", { event: { kind: "mouse", type: "mouseWheel", x: p.x, y: p.y, deltaX: e.deltaX, deltaY: e.deltaY } }); });
window.addEventListener("keydown", (e) => { post("/input", { event: { kind: "key", type: "keyDown", key: e.key, code: e.code, text: e.key.length === 1 ? e.key : undefined, windowsVirtualKeyCode: e.keyCode } }); });
window.addEventListener("keyup", (e) => { post("/input", { event: { kind: "key", type: "keyUp", key: e.key, code: e.code, windowsVirtualKeyCode: e.keyCode } }); });
document.getElementById("resume").onclick = async () => { await post("/resume"); state.textContent = "handed back — you can close this tab"; es.close(); };
document.getElementById("end").onclick = async () => { await post("/end"); state.textContent = "run ended — you can close this tab"; es.close(); };
</script></body></html>`;
}

const MOUSE_TYPES = new Set(["mousePressed", "mouseReleased", "mouseMoved", "mouseWheel"]);
const KEY_TYPES = new Set(["keyDown", "keyUp", "rawKeyDown", "char"]);
const BUTTONS = new Set(["none", "left", "middle", "right"]);

/** Validate an untrusted page payload into a HandoffInputEvent, or null. */
export function validateHandoffInput(raw: unknown): HandoffInputEvent | null {
  if (!raw || typeof raw !== "object") return null;
  const ev = raw as Record<string, unknown>;
  const coord = (v: unknown) => typeof v === "number" && Number.isFinite(v) && v >= 0 && v <= 100_000;
  if (ev.kind === "mouse") {
    if (!MOUSE_TYPES.has(String(ev.type)) || !coord(ev.x) || !coord(ev.y)) return null;
    if (ev.button !== undefined && !BUTTONS.has(String(ev.button))) return null;
    return {
      kind: "mouse", type: ev.type as never, x: ev.x as number, y: ev.y as number,
      ...(ev.button !== undefined ? { button: ev.button as never } : {}),
      ...(typeof ev.clickCount === "number" ? { clickCount: ev.clickCount } : {}),
      ...(typeof ev.deltaX === "number" ? { deltaX: ev.deltaX } : {}),
      ...(typeof ev.deltaY === "number" ? { deltaY: ev.deltaY } : {}),
    };
  }
  if (ev.kind === "key") {
    if (!KEY_TYPES.has(String(ev.type)) || typeof ev.key !== "string" || !ev.key || ev.key.length > 64) return null;
    const str = (v: unknown, max: number) => (typeof v === "string" && v.length <= max ? v : undefined);
    const num = (v: unknown) => (typeof v === "number" && Number.isFinite(v) ? v : undefined);
    return {
      kind: "key", type: ev.type as never, key: ev.key,
      ...(str(ev.code, 64) !== undefined ? { code: str(ev.code, 64) } : {}),
      ...(str(ev.text, 256) !== undefined ? { text: str(ev.text, 256) } : {}),
      ...(num(ev.modifiers) !== undefined ? { modifiers: num(ev.modifiers) } : {}),
      ...(num(ev.windowsVirtualKeyCode) !== undefined ? { windowsVirtualKeyCode: num(ev.windowsVirtualKeyCode) } : {}),
      ...(num(ev.nativeVirtualKeyCode) !== undefined ? { nativeVirtualKeyCode: num(ev.nativeVirtualKeyCode) } : {}),
    };
  }
  return null;
}

async function readBody(req: import("node:http").IncomingMessage): Promise<string> {
  return new Promise((resolve, reject) => {
    const chunks: Buffer[] = []; let size = 0;
    req.on('data', (c: Buffer) => {
      size += c.length;
      if (size > 16_384) { chunks.length = 0; reject(new Error('body too large')); }
      else chunks.push(c);
    });
    req.on('end', () => resolve(Buffer.concat(chunks).toString('utf8')));
    req.on('error', reject);
  });
}

export async function bindHandoffServer(
  session: HandoffSession,
  opts: { host?: string; port?: number } = {},
): Promise<HandoffServer> {
  const host = opts.host ?? "127.0.0.1";
  if (host !== '127.0.0.1') throw new Error('handoff must bind to 127.0.0.1');
  const server = createServer(async (req, res) => {
    res.setHeader('Cache-Control', 'no-store');
    res.setHeader('Referrer-Policy', 'no-referrer');
    res.setHeader('X-Content-Type-Options', 'nosniff');
    res.setHeader('X-Frame-Options', 'DENY');
    res.setHeader('Content-Security-Policy', "default-src 'none'; script-src 'unsafe-inline'; style-src 'unsafe-inline'; img-src data:; connect-src 'self'; frame-ancestors 'none'; base-uri 'none'; form-action 'none'");
    const send = (code: number, body: string, type = "application/json") => {
      res.writeHead(code, { "content-type": type });
      res.end(body);
    };
    try {
      const address = server.address();
      const expectedHost = `127.0.0.1:${typeof address === 'object' && address ? address.port : 0}`;
      if (req.headers.host !== expectedHost || (req.headers.origin && req.headers.origin !== `http://${expectedHost}`)) {
        return send(403, JSON.stringify({ error: 'foreign host or origin' }));
      }
      const u = new URL(req.url ?? "/", "http://127.0.0.1");
      let body: any = {};
      if (req.method === "POST") {
        const raw = await readBody(req);
        try { body = raw ? JSON.parse(raw) : {}; } catch { return send(400, JSON.stringify({ error: "invalid JSON" })); }
      }
      const token = u.searchParams.get("token")
        ?? (typeof req.headers["x-handoff-token"] === "string" ? req.headers["x-handoff-token"] : null)
        ?? (typeof body?.token === "string" ? body.token : null);
      if (!session.tokenOk(token)) return send(401, JSON.stringify({ error: "invalid or missing handoff token" }));

      if (req.method === "GET" && u.pathname === "/") {
        return send(200, handoffPageHtml(session), "text/html; charset=utf-8");
      }
      if (req.method === "GET" && u.pathname === "/status") {
        return send(200, JSON.stringify(session.snapshot()));
      }
      if (req.method === "GET" && u.pathname === "/events") {
        session.assertAccepting();
        if (!session.claimController()) return send(409, JSON.stringify({ error: "a controller is already attached" }));
        res.writeHead(200, { "content-type": "text/event-stream", "cache-control": "no-store", connection: "keep-alive" });
        // Headers are not flushed until the first write — open the stream
        // explicitly or the client's fetch() never resolves.
        res.write(": handoff stream open\n\n");
        const off = session.onFrame((f) => {
          res.write(`data: ${JSON.stringify({ data: f.data, metadata: f.metadata })}\n\n`);
        });
        req.on("close", () => { off(); session.releaseController(); });
        return;
      }
      if (req.method === "POST" && u.pathname === "/input") {
        const ev = validateHandoffInput(body?.event);
        if (!ev) return send(400, JSON.stringify({ error: "invalid input event" }));
        await session.forwardInput(ev);
        return send(200, JSON.stringify({ ok: true }));
      }
      if (req.method === "POST" && u.pathname === "/resume") {
        session.assertAccepting();
        // Respond first; teardown (capture-back + session close) can take
        // seconds and the human's feedback should be immediate.
        send(200, JSON.stringify({ ok: true, outcome: "resumed" }));
        await session.resume();
        return;
      }
      if (req.method === "POST" && u.pathname === "/end") {
        session.assertAccepting();
        send(200, JSON.stringify({ ok: true, outcome: "ended" }));
        await session.end();
        return;
      }
      return send(404, JSON.stringify({ error: "not found" }));
    } catch (e) {
      if (res.headersSent) return;
      if ((e as Error).message === 'body too large') return send(413, JSON.stringify({ error: 'body too large' }));
      if (e instanceof HandoffExpiredError) return send(410, JSON.stringify({ error: "handoff expired" }));
      if (e instanceof HandoffEndedError) return send(410, JSON.stringify({ error: "handoff ended" }));
      return send(500, JSON.stringify({ error: 'handoff operation failed' }));
    }
  });

  await new Promise<void>((resolve, reject) => {
    server.once("error", reject);
    server.listen(opts.port ?? 0, host, () => resolve());
  });
  const addr = server.address();
  const port = typeof addr === "object" && addr ? addr.port : (opts.port ?? 0);
  const url = `http://${host}:${port}/?token=${encodeURIComponent(session.handle.token)}`;
  session.handle.url = url;

  let closed = false;
  return {
    server,
    url,
    async close() {
      if (closed) return;
      closed = true;
      (server as { closeAllConnections?: () => void }).closeAllConnections?.();
      await new Promise<void>((resolve) => server.close(() => resolve()));
    },
  };
}

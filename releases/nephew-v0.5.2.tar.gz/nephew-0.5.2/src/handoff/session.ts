/**
 * handoff/session — one streamed human handoff over a live CDP session.
 *
 * Lifecycle: start() pins an ABSOLUTE monotonic deadline (startedAt +
 * ttl). Nothing — not the human arriving late, not a clock change, not
 * reconnecting the stream — extends it (the R15 lesson: delayed entry
 * cannot extend acceptance). At the deadline the session expires on its
 * own timer; every public entry point also re-checks the deadline, so a
 * stalled timer can never keep the session alive.
 *
 * Teardown (resume / end / expire / abort) runs exactly once: stop the
 * screencast, unsubscribe, finalize the event record, then hand control
 * back via onTeardown. The session NEVER closes the CDP client — the run
 * that opened the provider session owns it and tears it down.
 *
 * Single-session: a process-wide slot allows at most one active handoff.
 * A second start while one is live fails with HandoffBusyError.
 */
import { randomBytes, timingSafeEqual } from "node:crypto";
import {
  DEFAULT_HANDOFF_TTL_MS, systemHandoffClock,
  type HandoffClock, type HandoffEventRecord, type HandoffHandle,
  type HandoffInputEvent, type HandoffOutcome, type HandoffSessionOptions,
} from "./types.ts";
import { defaultHandoffEventDir, handoffEventFileName, writeHandoffRecord } from "./record.ts";

export class HandoffBusyError extends Error {
  constructor(activeId: string) {
    super(`a handoff is already active (${activeId}) — only one human handoff can be live at a time`);
    this.name = "HandoffBusyError";
  }
}

export class HandoffExpiredError extends Error {
  constructor() {
    super("handoff expired — the absolute deadline passed and acceptance cannot be extended");
    this.name = "HandoffExpiredError";
  }
}

export class HandoffEndedError extends Error {
  constructor() {
    super("handoff has ended");
    this.name = "HandoffEndedError";
  }
}

let activeSession: HandoffSession | null = null;

/** The process's one active handoff, if any (single-session enforcement). */
export function activeHandoff(): HandoffSession | null {
  return activeSession;
}

type FrameListener = (frame: { data: string; metadata: Record<string, unknown> }) => void;

export class HandoffSession {
  readonly handle: HandoffHandle;
  private readonly opts: HandoffSessionOptions;
  private readonly clock: HandoffClock;
  private readonly deadlineMonotonic: number;
  private readonly expiryTimer: unknown;
  private readonly record: HandoffEventRecord;
  private unsubscribeFrame: (() => void) | null = null;
  private frameListeners = new Set<FrameListener>();
  private latestFrame: { data: string; metadata: Record<string, unknown> } | null = null;
  private controllerClaimed = false;
  private teardownPromise: Promise<HandoffEventRecord> | null = null;
  private completion: Promise<HandoffEventRecord>;
  private resolveCompletion!: (rec: HandoffEventRecord) => void;
  /** Set by the wiring when capture-back ran during teardown (record fidelity). */
  captureBackAttempted = false;

  private constructor(opts: HandoffSessionOptions, handle: HandoffHandle, record: HandoffEventRecord) {
    this.opts = opts;
    this.handle = handle;
    this.record = record;
    this.clock = opts.clock ?? systemHandoffClock;
    this.deadlineMonotonic = this.clock.monotonicMs() + (opts.ttlMs ?? DEFAULT_HANDOFF_TTL_MS);
    this.completion = new Promise((res) => { this.resolveCompletion = res; });
    this.expiryTimer = this.clock.setTimer(() => { void this.teardown("expired"); }, opts.ttlMs ?? DEFAULT_HANDOFF_TTL_MS);
  }

  static async start(opts: HandoffSessionOptions): Promise<HandoffSession> {
    if (activeSession) throw new HandoffBusyError(activeSession.handle.handoffId);
    const ttlMs = opts.ttlMs ?? DEFAULT_HANDOFF_TTL_MS;
    if (!Number.isFinite(ttlMs) || ttlMs <= 0) throw new Error(`handoff ttlMs must be a positive number, got ${ttlMs}`);
    if (!opts.designatedHuman) throw new Error("handoff requires the profile's designated human — there is nobody to bind the token to");
    const clock = opts.clock ?? systemHandoffClock;
    const startedMs = clock.nowMs();
    const startedAt = new Date(startedMs).toISOString();
    const expiresAt = new Date(startedMs + ttlMs).toISOString();
    const handoffId = opts.handoffId ?? randomBytes(6).toString("hex");
    const token = opts.token ?? randomBytes(24).toString("base64url");
    const eventFile = opts.eventFile
      ?? join2(opts.eventDir ?? defaultHandoffEventDir(), handoffEventFileName({ startedAt, profile: opts.profile, handoffId }));

    const record: HandoffEventRecord = {
      version: 1, handoffId, profile: opts.profile, designatedHuman: opts.designatedHuman,
      provider: opts.provider, job: opts.job, startedAt, expiresAt,
      resumedAt: null, endedAt: null, outcome: "active",
      framesRelayed: 0, inputEventsForwarded: 0, captureBackAttempted: false,
    };
    // URL is filled in by the server layer (bindHandoffServer) once the
    // loopback port is known; start() callers use session.handle.url.
    const handle: HandoffHandle = {
      handoffId, url: "", token, designatedHuman: opts.designatedHuman,
      profile: opts.profile, provider: opts.provider, job: opts.job,
      startedAt, expiresAt, eventFile,
    };
    const session = new HandoffSession({ ...opts, ttlMs }, handle, record);
    activeSession = session;
    try {
      await writeHandoffRecord(record, eventFile);
      session.unsubscribeFrame = opts.cdp.onEvent("Page.screencastFrame", (params) => session.onScreencastFrame(params));
      const sc = opts.screencast ?? {};
      await opts.cdp.send("Page.startScreencast", {
        format: "jpeg",
        quality: sc.quality ?? 60,
        maxWidth: sc.maxWidth ?? 1280,
        maxHeight: sc.maxHeight ?? 800,
        everyNthFrame: sc.everyNthFrame ?? 1,
      }, opts.sessionId);
    } catch (e) {
      activeSession = null;
      session.clock.clearTimer(session.expiryTimer);
      throw e;
    }
    return session;
  }

  /** Absolute deadline check — entry can never extend acceptance. */
  get expired(): boolean {
    return this.clock.monotonicMs() >= this.deadlineMonotonic;
  }

  get ended(): boolean {
    return this.teardownPromise !== null;
  }

  get outcome(): HandoffOutcome {
    return this.record.outcome;
  }

  /** Constant-time token check (the one credential this module knows). */
  tokenOk(candidate: string | null | undefined): boolean {
    if (!candidate) return false;
    const a = Buffer.from(candidate);
    const b = Buffer.from(this.handle.token);
    return a.length === b.length && timingSafeEqual(a, b);
  }

  /**
   * Claim the single controller stream. Returns false when a controller
   * is already attached (single session = one pair of hands).
   */
  claimController(): boolean {
    if (this.ended || this.expired) return false;
    if (this.controllerClaimed) return false;
    this.controllerClaimed = true;
    return true;
  }

  releaseController(): void {
    this.controllerClaimed = false;
  }

  /** Subscribe to relayed screencast frames; replays the latest at once. */
  onFrame(fn: FrameListener): () => void {
    this.frameListeners.add(fn);
    if (this.latestFrame) {
      try { fn(this.latestFrame); } catch { /* a listener must not break relay */ }
    }
    return () => { this.frameListeners.delete(fn); };
  }

  private onScreencastFrame(params: any): void {
    if (this.ended) return;
    const frameSessionId = params?.sessionId;
    // Ack first: an unacked frame stalls the screencast.
    void this.opts.cdp
      .send("Page.screencastFrameAck", { sessionId: frameSessionId }, this.opts.sessionId)
      .catch(() => { /* ack best-effort; relay continues */ });
    if (typeof params?.data !== "string" || !params.data) return;
    const frame = { data: params.data, metadata: (params.metadata ?? {}) as Record<string, unknown> };
    this.latestFrame = frame;
    this.record.framesRelayed += 1;
    for (const fn of this.frameListeners) {
      try { fn(frame); } catch { /* see onFrame */ }
    }
  }

  /** Forward one validated page input event to the live page via CDP. */
  async forwardInput(ev: HandoffInputEvent): Promise<void> {
    this.assertAccepting();
    if (ev.kind === "mouse") {
      await this.opts.cdp.send("Input.dispatchMouseEvent", {
        type: ev.type, x: ev.x, y: ev.y,
        button: ev.button ?? (ev.type === "mouseMoved" ? "none" : "left"),
        ...(ev.clickCount !== undefined ? { clickCount: ev.clickCount } : {}),
        ...(ev.deltaX !== undefined ? { deltaX: ev.deltaX } : {}),
        ...(ev.deltaY !== undefined ? { deltaY: ev.deltaY } : {}),
      }, this.opts.sessionId);
    } else {
      await this.opts.cdp.send("Input.dispatchKeyEvent", {
        type: ev.type, key: ev.key,
        ...(ev.code !== undefined ? { code: ev.code } : {}),
        ...(ev.text !== undefined ? { text: ev.text } : {}),
        ...(ev.modifiers !== undefined ? { modifiers: ev.modifiers } : {}),
        ...(ev.windowsVirtualKeyCode !== undefined ? { windowsVirtualKeyCode: ev.windowsVirtualKeyCode } : {}),
        ...(ev.nativeVirtualKeyCode !== undefined ? { nativeVirtualKeyCode: ev.nativeVirtualKeyCode } : {}),
      }, this.opts.sessionId);
    }
    this.record.inputEventsForwarded += 1;
  }

  /** Throw when the handoff can no longer accept anything. */
  assertAccepting(): void {
    if (this.ended) throw new HandoffEndedError();
    if (this.expired) {
      void this.teardown("expired");
      throw new HandoffExpiredError();
    }
  }

  /** Human hands control back — the run resumes ownership of the session. */
  resume(): Promise<HandoffEventRecord> {
    return this.teardown("resumed");
  }

  /** Human ends the run's pause outright — teardown, no resume. */
  end(): Promise<HandoffEventRecord> {
    return this.teardown("ended");
  }

  /** Owner-side abort (the run is going away for another reason). */
  abort(): Promise<HandoffEventRecord> {
    return this.teardown("aborted");
  }

  /** Resolves with the finalized record once teardown completes. */
  waitForOutcome(): Promise<HandoffEventRecord> {
    return this.completion;
  }

  snapshot(): HandoffEventRecord {
    return { ...this.record };
  }

  private teardown(outcome: Exclude<HandoffOutcome, "active">): Promise<HandoffEventRecord> {
    if (this.teardownPromise) return this.teardownPromise;
    this.teardownPromise = (async () => {
      this.clock.clearTimer(this.expiryTimer);
      const endedAt = new Date(this.clock.nowMs()).toISOString();
      this.record.outcome = outcome;
      this.record.endedAt = endedAt;
      if (outcome === "resumed") this.record.resumedAt = endedAt;
      // Owner's pre-teardown work (capture-back) still needs the live
      // page; it runs before the screencast stops and before the record
      // is finalized, so its effect lands in the record.
      try { await this.opts.onBeforeTeardown?.(outcome, this); } catch { /* must not hang teardown */ }
      this.record.captureBackAttempted = this.captureBackAttempted;
      try {
        await this.opts.cdp.send("Page.stopScreencast", {}, this.opts.sessionId);
      } catch { /* the page may already be gone; teardown proceeds */ }
      this.unsubscribeFrame?.();
      this.frameListeners.clear();
      if (activeSession === this) activeSession = null;
      try { await writeHandoffRecord(this.record, this.handle.eventFile); } catch { /* record best-effort at teardown */ }
      // Owner teardown (capture-back, session close) finishes BEFORE the
      // completion resolves, so a caller awaiting waitForOutcome() knows
      // the session is fully handed back / closed, not merely stopping.
      try { await this.opts.onTeardown?.({ ...this.record }); } catch { /* owner's teardown must not hang the handoff */ }
      this.resolveCompletion({ ...this.record });
      return { ...this.record };
    })();
    return this.teardownPromise;
  }
}

/** Convenience: the one-call start used by run-core wiring. */
export async function startHandoffSession(opts: HandoffSessionOptions): Promise<HandoffSession> {
  return HandoffSession.start(opts);
}

function join2(a: string, b: string): string {
  return a.endsWith("/") ? a + b : `${a}/${b}`;
}

/**
 * handoff/types — the shared shapes for challenge recovery via streamed
 * human handoff (see README.md in this directory for the full design).
 *
 * The handoff borrows a LIVE provider session's CDP connection while a run
 * is paused at LOGIN_REQUIRED. It never owns the session: the run that
 * opened it keeps ownership and closes it (the baseline runners' existing
 * teardown) once the handoff hands control back.
 */

/** Minimal CDP surface the handoff needs — CdpClient satisfies it. */
export interface HandoffCdp {
  send(method: string, params?: Record<string, unknown>, sessionId?: string, timeoutMs?: number): Promise<any>;
  onEvent(method: string, handler: (params: any, sessionId?: string) => void): () => void;
}

/**
 * A live provider session a baseline runner can lend to a handoff when a
 * restore does not verify. The runner transfers ownership by returning
 * this instead of closing the session itself.
 */
export interface HandoffControlSource {
  cdp: HandoffCdp;
  /** Attached page session id inside `cdp`. */
  sessionId: string;
  /**
   * Capture the live session state (cookies + bundled-origin
   * localStorage) WITHOUT sealing it — run-core seals it into the owner
   * bundle when a handoff ends in "resume". Optional: a source that
   * cannot capture simply resumes without capture-back.
   */
  captureBack?: () => Promise<unknown>;
  /** The runner's normal session teardown (CDP close + provider release/stop). */
  close(): Promise<void>;
}

/** Injectable clock: wall time for records, monotonic time for expiry. */
export interface HandoffClock {
  nowMs(): number;
  monotonicMs(): number;
  setTimer(fn: () => void, ms: number): unknown;
  clearTimer(handle: unknown): void;
}

export const systemHandoffClock: HandoffClock = {
  nowMs: () => Date.now(),
  monotonicMs: () => performance.now(),
  setTimer: (fn, ms) => {
    const t = setTimeout(fn, ms);
    (t as { unref?: () => void }).unref?.();
    return t;
  },
  clearTimer: (h) => clearTimeout(h as ReturnType<typeof setTimeout>),
};

/** How a handoff ended. "active" is the pre-teardown record state. */
export type HandoffOutcome = "active" | "resumed" | "ended" | "expired" | "aborted";

/**
 * The public handle for one handoff — everything a surface (CLI, MCP)
 * needs to route the pause to the designated human. Serializable: the
 * token is a bearer capability for THIS handoff only and is never logged
 * by run metrics (AGENTS.md #3 applies to profile state, not to a
 * single-use, expiring, loopback-only handoff token the CLI prints for
 * the owner at their own terminal).
 */
export interface HandoffHandle {
  handoffId: string;
  /** Local page the designated human opens (token carried in the query). */
  url: string;
  /** Per-handoff token; the page and every input call must present it. */
  token: string;
  designatedHuman: string;
  profile: string;
  provider: string;
  job: string;
  startedAt: string;
  expiresAt: string;
  /** File the JSON handoff event record is written to (see README.md). */
  eventFile: string;
}

/** The signal run-core emits when a paused run offers a live handoff. */
export interface HandoffRequiredSignal {
  type: "handoff_required";
  handle: HandoffHandle;
}

/**
 * The plain JSON handoff event record (schema version 1) — written to
 * handle.eventFile on start (outcome "active") and finalized at
 * teardown. The receipts work consumes this file; see README.md.
 */
export interface HandoffEventRecord {
  version: 1;
  handoffId: string;
  profile: string;
  designatedHuman: string;
  provider: string;
  job: string;
  startedAt: string;
  expiresAt: string;
  /** When the human handed control back ("resume"), else null. */
  resumedAt: string | null;
  /** When the handoff fully tore down, else null while active. */
  endedAt: string | null;
  outcome: HandoffOutcome;
  framesRelayed: number;
  inputEventsForwarded: number;
  /** True when a resumed handoff's live state was captured back for sealing. */
  captureBackAttempted: boolean;
}

/** Mouse input as accepted from the handoff page (validated in server.ts). */
export interface HandoffMouseEvent {
  kind: "mouse";
  type: "mousePressed" | "mouseReleased" | "mouseMoved" | "mouseWheel";
  x: number;
  y: number;
  button?: "none" | "left" | "middle" | "right";
  clickCount?: number;
  deltaX?: number;
  deltaY?: number;
}

/** Keyboard input as accepted from the handoff page (validated in server.ts). */
export interface HandoffKeyEvent {
  kind: "key";
  type: "keyDown" | "keyUp" | "rawKeyDown" | "char";
  key: string;
  code?: string;
  text?: string;
  modifiers?: number;
  windowsVirtualKeyCode?: number;
  nativeVirtualKeyCode?: number;
}

export type HandoffInputEvent = HandoffMouseEvent | HandoffKeyEvent;

export interface HandoffSessionOptions {
  cdp: HandoffCdp;
  sessionId: string;
  designatedHuman: string;
  profile: string;
  provider: string;
  job: string;
  /** Hard expiry budget, ms. Default 360_000 (360 s). Must be > 0. */
  ttlMs?: number;
  /** HTTP bind host — loopback only by default and by design. */
  host?: string;
  /** HTTP port; 0 (default) picks an ephemeral loopback port. */
  port?: number;
  /** Directory for the event record; default runs/handoffs/ (record.ts). */
  eventDir?: string;
  /** Explicit event record path (overrides eventDir). */
  eventFile?: string;
  /** Token override (tests); default a fresh 192-bit random token. */
  token?: string;
  /** Handoff id override (tests); default random. */
  handoffId?: string;
  clock?: HandoffClock;
  /** Screencast tuning (tests may shrink these). */
  screencast?: { quality?: number; maxWidth?: number; maxHeight?: number; everyNthFrame?: number };
  /**
   * Called exactly once during teardown, BEFORE the record is finalized
   * and the screencast stops — the place for work that still needs the
   * live page and belongs in the record (run-core's capture-back on
   * "resume" sets session.captureBackAttempted from here). Errors are
   * swallowed by the session (teardown must not hang on them).
   */
  onBeforeTeardown?: (outcome: Exclude<HandoffOutcome, "active">, session: HandoffSessionLike) => void | Promise<void>;
  /**
   * Called exactly once at teardown, after the record is finalized.
   * The session's owner uses it to run session teardown (the runner's
   * normal close). Errors are swallowed by the session.
   */
  onTeardown?: (record: HandoffEventRecord) => void | Promise<void>;
}

export const DEFAULT_HANDOFF_TTL_MS = 360_000;

/** The slice of HandoffSession the teardown hooks may touch. */
export interface HandoffSessionLike {
  captureBackAttempted: boolean;
  readonly handle: HandoffHandle;
}

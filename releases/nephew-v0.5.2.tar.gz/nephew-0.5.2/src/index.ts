/**
 * CLI entry (npm scripts). The shipped CLI is src/nephew.ts; this shim
 * forwards the commands that exist there and keeps `compare` as the one
 * honest stub.
 *   npm run capture                     capture a bundle from a fresh login (test account)
 *   npm run run -- --provider <name>    load bundle, run workload, record metrics
 *   npm run compare -- <runA> <runB>    fingerprint delta between two run records
 *   npm run revoke                      destroy the bundle (signed deletion receipt)
 */
const [cmd, ...rest] = process.argv.slice(2);

if (cmd === "capture" || cmd === "run" || cmd === "revoke" || cmd === "init" || cmd === "mcp" || cmd === "receipt") {
  const { main } = await import("./nephew.ts");
  process.exitCode = await main([cmd, ...rest]);
} else switch (cmd) {
  case "compare":
    // TODO(fable): wire profile-store + providers + fingerprint + workload + measure.
    console.error(`"${cmd}" is scaffolded, not implemented yet (args: ${rest.join(" ")})`);
    process.exitCode = 1;
    break;
  default:
    console.error("usage: capture | init | run --provider <name> | compare <a> <b> | revoke | mcp");
    process.exitCode = 1;
}

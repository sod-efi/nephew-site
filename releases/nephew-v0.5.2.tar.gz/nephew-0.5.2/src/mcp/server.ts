/**
 * mcp/server — the Nephew MCP server (`nephew mcp`, stdio transport).
 *
 * One tool, from the delight brief §3 Shape C:
 *
 *   profile_run { job, provider: "steel"|"browseruse"|"modal"|"browserbase", bundle? }
 *
 * It wraps the SAME run core as the CLI (cli/run-core.ts): same trust
 * receipt, same fingerprint gate before any state is released, same
 * metrics record. The model driving it never sees a cookie, a token, or
 * the bundle — results carry identifiers, counts, and outcomes only.
 *
 * The delightful failure is a RESULT, not an error: when the carried
 * login does not hold, profile_run returns structuredContent
 * { status: "LOGIN_REQUIRED", profile, designatedHuman, … } with
 * isError false — the calling agent pauses and routes the handoff to the
 * profile's designated human instead of parsing an exception. A gate
 * refusal is likewise a structured result ({ status: "REFUSED", … }), and
 * so is a plan refusal (reason "plan-limit": the plan's runs at a time are
 * all in use — cli/plan.ts). Only genuine failures (bundle unreadable,
 * provider unreachable, Modal not connected) come back isError true.
 *
 * Protocol: MCP over stdio — newline-delimited JSON-RPC 2.0. Implemented
 * directly on the standard library (no SDK dependency): initialize,
 * ping, tools/list, tools/call. Notifications get no response.
 */
import { readFileSync } from "node:fs";
import { createInterface } from "node:readline";
import { PROVIDERS, type ProviderName } from "../cli/args.ts";
import { PRICING_URL } from "../cli/plan.ts";
import { runProfileJob, type RunOutcome } from "../cli/run-core.ts";

export const MCP_PROTOCOL_VERSION = "2024-11-05";
/** The one version: package.json's (the release build keeps it equal to its own). */
export const NEPHEW_VERSION: string = JSON.parse(readFileSync(new URL("../../package.json", import.meta.url), "utf8")).version;

export interface McpDeps {
  env?: NodeJS.ProcessEnv;
  runProfile?: typeof runProfileJob;
}

interface JsonRpcRequest {
  jsonrpc?: string;
  id?: string | number | null;
  method?: string;
  params?: any;
}

const PROFILE_RUN_TOOL = {
  name: "profile_run",
  description:
    "Run a job with the owner's portable browser profile on a chosen provider (steel | browseruse | modal | browserbase). " +
    "The profile's session state is restored only after the live browser passes the bundle's fingerprint gate. " +
    "Returns a structured result: COMPLETED, REFUSED (fingerprint mismatch, or the plan's runs-at-a-time limit is in use — nothing ran), or LOGIN_REQUIRED " +
    "(a pause, not a failure: the carried login did not hold; route the handoff to the named designated human). " +
    "On LOGIN_REQUIRED the result carries a `handoff` handle (live-session URL + token) for steel/browseruse/browserbase, " +
    "unless the caller passes handoff: false; modal exposes no host-side session and reports handoffUnavailable.",
  inputSchema: {
    type: "object",
    properties: {
      job: { type: "string", description: "Job name — labels the run and its metrics record." },
      provider: { type: "string", enum: [...PROVIDERS], description: "Provider to run on." },
      bundle: { type: "string", description: "Owner-held bundle directory (default: the configured default bundle)." },
      handoff: { type: "boolean", description: "Offer a streamed human handoff on a LOGIN_REQUIRED pause (default: true; steel/browseruse/browserbase only)." },
    },
    required: ["job", "provider"],
  },
};

function result(id: string | number | null, value: unknown) {
  return { jsonrpc: "2.0", id, result: value };
}

function errorResult(id: string | number | null, code: number, message: string) {
  return { jsonrpc: "2.0", id, error: { code, message } };
}

function toolResult(structured: Record<string, unknown>, isError = false) {
  return {
    content: [{ type: "text", text: JSON.stringify(structured) }],
    structuredContent: structured,
    isError,
  };
}

/** Map a run-core outcome onto the profile_run tool result. Pure. */
export function profileRunToolResult(outcome: RunOutcome, input: { job: string; provider: ProviderName }) {
  switch (outcome.kind) {
    case "completed":
      return toolResult({
        status: "COMPLETED",
        job: input.job,
        provider: input.provider,
        profile: outcome.bundle.manifest.id,
        loggedIn: true,
        loginPrompts: 0,
        latencyMs: outcome.latencyMs,
        receipt: outcome.receipt,
        // The signed run receipt (src/receipts/), when one was issued.
        receiptPath: outcome.receiptPath ?? null,
      });
    case "refused":
      return toolResult({
        status: "REFUSED",
        reason: "fingerprint-mismatch",
        job: input.job,
        provider: input.provider,
        profile: outcome.bundle.manifest.id,
        changed: outcome.changed,
        receipt: outcome.receipt,
        receiptPath: outcome.receiptPath ?? null,
      });
    case "login-required":
      return toolResult({
        status: "LOGIN_REQUIRED",
        job: input.job,
        provider: input.provider,
        profile: outcome.bundle.manifest.id,
        designatedHuman: outcome.bundle.manifest.designatedHuman ?? null,
        // The live handoff handle, when run-core started one: the
        // calling agent routes THIS URL + token to the designated human,
        // who takes over the paused session in their browser. The token
        // is single-handoff, loopback-only, and dies at expiresAt.
        handoff: outcome.handoff ?? null,
        ...(outcome.handoffUnavailable ? { handoffUnavailable: outcome.handoffUnavailable } : {}),
        action: outcome.handoff
          ? "route the handoff URL + token to the designated human — they take over the live session and hand control back; the job can then be retried unchanged"
          : "the designated human re-captures the login (`nephew capture`) — the job can then be retried unchanged",
        receipt: outcome.receipt,
        // The signed run receipt (src/receipts/), when one was issued
        // before this result returned. A live-handoff run is receipted
        // at handoff teardown — after this pause result — so its
        // receiptPath is null here; the receipt still lands on disk.
        receiptPath: outcome.receiptPath ?? null,
      });
    case "plan-limit":
      // A refusal like the gate's: structured, isError false — the calling
      // agent tells the owner (wait for a run to finish, or upgrade).
      return toolResult({
        status: "REFUSED",
        reason: "plan-limit",
        job: input.job,
        provider: input.provider,
        plan: outcome.plan,
        limits: outcome.limits,
        message: outcome.message,
        upgrade: PRICING_URL,
      });
    case "not-connected":
      return toolResult({ status: "ERROR", job: input.job, provider: input.provider, message: outcome.message }, true);
    case "failed":
      return toolResult({ status: "ERROR", job: input.job, provider: input.provider, message: outcome.message }, true);
  }
}

async function callProfileRun(params: any, deps: McpDeps) {
  const args = params?.arguments ?? {};
  const job = typeof args.job === "string" && args.job ? args.job : null;
  const provider = (PROVIDERS as readonly string[]).includes(args.provider) ? (args.provider as ProviderName) : null;
  if (!job || !provider) {
    return toolResult({ status: "ERROR", message: "profile_run needs { job: string, provider: steel|browseruse|modal|browserbase }" }, true);
  }
  const logs: string[] = [];
  const outcome = await (deps.runProfile ?? runProfileJob)(
    {
      job, provider,
      bundleDir: typeof args.bundle === "string" ? args.bundle : undefined,
      env: deps.env ?? process.env, log: (l) => logs.push(l),
      // The MCP pause exists to be routed: enable the live handoff by
      // default so LOGIN_REQUIRED carries its handle (opt out with
      // handoff: false).
      handoff: { enabled: args.handoff !== false },
    },
  );
  // The run's own narration (trust receipt, session, gate, receipt path)
  // rides along: it names the receipt file and the handoff lines, which
  // the agent otherwise never sees. Counts, identifiers and outcomes only,
  // like every run log.
  const r = profileRunToolResult(outcome, { job, provider });
  const structured = { ...r.structuredContent, logs };
  return { ...r, structuredContent: structured, content: [{ type: "text", text: JSON.stringify(structured) }] };
}

/** Handle one JSON-RPC message. Returns the response object, or null for notifications. */
export async function handleMcpMessage(msg: JsonRpcRequest, deps: McpDeps = {}): Promise<unknown | null> {
  const isNotification = msg.id === undefined || msg.id === null;
  switch (msg.method) {
    case "initialize":
      return result(msg.id ?? null, {
        protocolVersion: MCP_PROTOCOL_VERSION,
        capabilities: { tools: {} },
        serverInfo: { name: "nephew", version: NEPHEW_VERSION },
      });
    case "ping":
      return isNotification ? null : result(msg.id ?? null, {});
    case "tools/list":
      return result(msg.id ?? null, { tools: [PROFILE_RUN_TOOL] });
    case "tools/call": {
      if (msg.params?.name !== "profile_run") {
        return isNotification ? null : errorResult(msg.id ?? null, -32602, `unknown tool "${String(msg.params?.name)}"`);
      }
      const value = await callProfileRun(msg.params, deps);
      return isNotification ? null : result(msg.id ?? null, value);
    }
    default:
      return isNotification ? null : errorResult(msg.id ?? null, -32601, `method not found: ${String(msg.method)}`);
  }
}

/** Serve MCP on stdio until stdin closes. Logs go to stderr — stdout is the protocol. */
export async function serveMcpStdio(deps: McpDeps = {}): Promise<void> {
  const rl = createInterface({ input: process.stdin });
  // Requests are dispatched, not awaited in the read loop: a profile_run
  // takes tens of seconds (minutes with a handoff), and a client that
  // pings meanwhile must get its answer or it drops the server.
  const inFlight = new Set<Promise<void>>();
  for await (const line of rl) {
    const trimmed = line.trim();
    if (!trimmed) continue;
    let msg: JsonRpcRequest;
    try {
      msg = JSON.parse(trimmed) as JsonRpcRequest;
    } catch {
      process.stdout.write(JSON.stringify(errorResult(null, -32700, "parse error")) + "\n");
      continue;
    }
    const task = handleMcpMessage(msg, deps).then(
      (response) => { if (response !== null) process.stdout.write(JSON.stringify(response) + "\n"); },
      (e) => {
        const id = msg?.id ?? null;
        process.stdout.write(
          JSON.stringify(errorResult(id, -32603, (e instanceof Error ? e.message : String(e)).split("\n")[0])) + "\n",
        );
      },
    );
    inFlight.add(task);
    void task.finally(() => inFlight.delete(task));
  }
  await Promise.all(inFlight);
}

/**
 * measure — one metrics record per run, appended to runs/ in the exact format
 * of docs/TEST_PLAN.md. These records are the self-improving loop's input:
 * failure/block/drift signals feed retry and recovery settings; setting
 * changes are checked against prior runs before promotion, previous settings
 * retained for rollback. A run without a record didn't happen (AGENTS.md #5).
 */
import { appendFile, mkdir } from "node:fs/promises";
import { homedir } from "node:os";
import { join } from "node:path";
import type { FingerprintCapture } from "./fingerprint.ts";

/**
 * Where run records live for an installed CLI: ~/.nephew/runs (or
 * NEPHEW_RUNS_DIR). Never inside the package: the installer replaces the
 * package directory on every upgrade, which erased every record.
 */
export function defaultRunsDir(env: NodeJS.ProcessEnv = process.env): string {
  return env.NEPHEW_RUNS_DIR ?? join(homedir(), ".nephew", "runs");
}

export interface RunRecord {
  runId: string;
  date: string;
  environment: string;
  workloadCompleted: boolean;
  loggedInAtStart: boolean;
  loggedInAtEnd: boolean;
  loginPrompts: number;
  mfaPrompts: number;
  blocksOrChallenges: number;
  latencyMs: number;
  humanAttentionMinutes: number;
  costUsd: number;
  egressIp: string;
  proxyPinned: boolean;
  fingerprint: Partial<FingerprintCapture>;
  fingerprintDeltaVsBundle: { changed: string[]; unchanged: string[] };
  notes: string; // counts and outcomes only — never secrets
}

export async function recordRun(rec: RunRecord, runsDir = "runs"): Promise<string> {
  await mkdir(runsDir, { recursive: true });
  const path = `${runsDir}/${rec.date.slice(0, 10)}-${rec.environment}-${rec.runId}.json`;
  await appendFile(path, JSON.stringify(rec, null, 2) + "\n");
  return path;
}

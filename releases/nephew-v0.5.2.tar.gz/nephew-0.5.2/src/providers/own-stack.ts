/**
 * Own-stack adapter — THE MOAT TRACK.
 *
 * A patched Chromium (fingerprint-chromium) launched with the bundle's seed:
 *   chrome --fingerprint=<seed> --user-data-dir=<bundle profile dir>
 *          --timezone=<cfg> --proxy-server=<pinned proxy>
 * Same seed + same profile dir + same proxy = same presented device, on any of
 * our hosts (findings §2.3). Optionally fronted by self-hosted Steel:
 * CHROME_EXECUTABLE_PATH=<patched binary>, CHROME_ARGS carries the seed,
 * SKIP_FINGERPRINT_INJECTION=true (the binary handles it natively — Steel's
 * built-in JS injection is the detectable layer, findings §2.2).
 *
 * The host image is part of the fingerprint: font pack is pinned in the image.
 * Screen size is set over CDP (Emulation.setDeviceMetricsOverride) — the
 * --window-size flag does NOT set screen.width headless (spike, 2026-10-29).
 */
import { mkdir, mkdtemp } from "node:fs/promises";
import { tmpdir } from "node:os";
import { join } from "node:path";
import type { ProviderAdapter, Session } from "./index.ts";
import type { ProfileBundle } from "../profile-store.ts";
import { launchChromium, type LaunchedBrowser } from "../cdp.ts";

// Pid-derived base: a crashed run can orphan its Chromium still holding the
// debug port, and a fixed base would make the next run attach to that orphan
// (different flags, different profile) instead of its own browser.
let portCounter = 9400 + (process.pid % 300);

export interface OwnStackSession extends Session {
  browser: LaunchedBrowser;
  userDataDir: string;
}

/**
 * Build the launch flags from the bundle's fingerprint config. Pure —
 * unit-testable. Run paths use these args as built (their browsers live
 * in provider sandboxes/containers, where --no-sandbox is the norm).
 * Capture (cli/capture.ts) starts from these args, drops --headless=new,
 * and probes away the sandbox flags — see planCaptureLaunch there.
 */
export function launchArgsFor(bundle: ProfileBundle, userDataDir: string): string[] {
  const fp = bundle.fingerprint;
  const args = [
    // Headed mode (OWN_STACK_HEADED=1): omit the headless flag; the caller
    // runs the process under a virtual display (xvfb-run). Added 2026-10-29
    // on the owner's direction for the Amazon gate test — headless is a
    // detection surface.
    ...(process.env.OWN_STACK_HEADED === "1" ? [] : ["--headless=new"]),
    "--no-sandbox",
    "--disable-dev-shm-usage",
    "--disable-gpu-sandbox",
    "--use-angle=swiftshader",
    `--fingerprint=${fp.seed}`,
    `--user-data-dir=${userDataDir}`,
  ];
  if (fp.platform) args.push(`--fingerprint-platform=${fp.platform}`);
  if (fp.brand) args.push(`--fingerprint-brand=${fp.brand}`);
  if (fp.timezone) args.push(`--timezone=${fp.timezone}`);
  if (fp.locale) args.push(`--lang=${fp.locale}`, `--accept-lang=${fp.locale},en`);
  if (bundle.network.proxyUrl) args.push(`--proxy-server=${bundle.network.proxyUrl}`);
  // Host quirk, off by default: some build hosts egress through a TLS-
  // intercepting proxy whose CA the browser doesn't trust (the Steel
  // baseline's Env A is one). Opt in per run via env; never for real logins.
  if (process.env.OWN_STACK_IGNORE_CERT_ERRORS === "1") args.push("--ignore-certificate-errors");
  return args;
}

export const ownStackAdapter: ProviderAdapter & {
  startFull(bundle: ProfileBundle): Promise<OwnStackSession>;
} = {
  name: "own-stack",
  async start(bundle) {
    return this.startFull(bundle);
  },
  async startFull(bundle: ProfileBundle): Promise<OwnStackSession> {
    const exe = process.env.OWN_STACK_CHROME_PATH;
    if (!exe) throw new Error("OWN_STACK_CHROME_PATH is not set (see .env.example)");
    // PROFILE_DIR (env): reuse an existing on-disk profile dir instead
    // of a fresh temp dir — the sign-in/verify runs (AMZ_MODE=signin)
    // resume on the exact profile a previous run left behind, cookies
    // and all. Unset, the historical behavior stands: a fresh mkdtemp
    // per launch.
    const reuseDir = process.env.PROFILE_DIR;
    let userDataDir: string;
    if (reuseDir) {
      await mkdir(reuseDir, { recursive: true });
      userDataDir = reuseDir;
    } else {
      userDataDir = await mkdtemp(join(tmpdir(), "own-stack-profile-"));
    }
    const port = ++portCounter;
    const browser = await launchChromium(exe, launchArgsFor(bundle, userDataDir), port);
    const vp = bundle.fingerprint.viewport;
    if (vp) {
      await browser.cdp.send(
        "Emulation.setDeviceMetricsOverride",
        {
          width: vp.width, height: vp.height,
          deviceScaleFactor: vp.deviceScaleFactor ?? 1,
          mobile: false, screenWidth: vp.width, screenHeight: vp.height,
        },
        browser.sessionId,
      );
    }
    return {
      cdpUrl: browser.wsUrl,
      provider: "own-stack",
      browser,
      userDataDir,
      close: () => browser.close(),
    };
  },
};

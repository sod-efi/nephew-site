# Run receipts — integration notes

Status: module built and tested (`src/receipts/`, `test/receipts.test.ts`),
and **wired into run-core** (`src/cli/run-core.ts`), with wiring tests in
`test/receipts-wiring.test.ts`. This file describes the wiring as landed.

## The one call

`runProfileJob` (src/cli/run-core.ts) captures `startedAt` immediately
before the provider call and issues exactly one receipt per terminal
run through a local `issueReceipt()` helper that wraps
`receipts.finalizeRun`:

- **completed / refused** — issued after the baseline returns, before
  the outcome returns; the path rides the outcome as `receiptPath`.
- **login-required without a live handoff** (handoff not requested,
  session not held, no designated human, handoff start failure) —
  issued the same way, `handoffUsed: false`.
- **login-required with a live handoff** — the run truly ends at
  handoff teardown, so issuance is deferred to it: run-core chains off
  `session.waitForOutcome()` and exposes the pending issuance as the
  outcome's `receiptPromise` (resolves to the path, or null on failure;
  never rejects). At teardown the finalized handoff event record —
  read from `handle.eventFile`, which the session writes before
  resolving (src/handoff/README.md); the record `waitForOutcome()`
  resolves with is the fallback — supplies the receipt's `endedAt` and
  `humanAttentionMinutes` (the record's startedAt → endedAt span), and
  `handoffUsed` is `true`.
- **not-connected / failed** — no receipt: no profile was carried, no
  run happened.

Rules the call site keeps:

- **Never let receipting change the outcome.** `issueReceipt()` catches
  every finalize error, logs one line (`receipt     FAILED to issue:
  <reason>`), and yields no path; a success logs `receipt     signed
  run receipt: <path>`. A run never fails because its receipt could
  not be written — and the failure is never silent.
- **Test seam:** `RunCoreDeps.finalizeRunFn` overrides the finalize
  call (the wiring test uses it to force a failure and prove the
  outcome is untouched).
- Signing key + receipts dir resolve from the run's env via
  `finalizeRun` (`NEPHEW_RECEIPT_SIGNING_KEY_FILE`,
  `NEPHEW_RECEIPTS_DIR`).

## Field sourcing (as wired)

| Receipt field | Source |
|---|---|
| `profileId` | `bundle.manifest.id` |
| `runId` | the metrics record's `runId` (both runners return it on `BaselineOutcome.metrics`); the raw job name when the run wrote no metrics record (gate refusal) |
| `provider` | `input.provider` |
| `environment` | `metrics.fingerprint` — only `canvasHash` / `audioHash` / `fontsHash` cross over; an empty hash is "not captured" and is dropped, so the field is `null` when the run captured none |
| `egressIp` | `metrics.egressIp` (observed egress, not the pin's config); empty → `null` |
| `startedAt` / `endedAt` | run start (captured before the provider call) / outcome time — for a live-handoff run, the handoff record's `endedAt` |
| `outcome` | the RunOutcome kind: `completed` \| `refused` \| `login-required` |
| `humanAttentionMinutes` | `metrics.humanAttentionMinutes` (0 from today's runners); for a live-handoff run, the handoff event record's pause span replaces it |
| `handoffUsed` | `true` only when a handoff session was actually opened for the run |

The runners (run-baseline.ts `runInSession`, run-modal.ts) return the
metrics they recorded on `BaselineOutcome.metrics`
(`BaselineMetrics`: runId, fingerprint, egressIp,
humanAttentionMinutes) — present only when a metrics record was
written, i.e. the gate held; a gate refusal carries none.

## Verification surface

- Library: `receipts.verify(signed)` / `receipts.verifyFile(path)` →
  `{ ok, status: "PASS" | "FAIL", tamperedFields, reason }`.
- CLI: `nephew receipt verify <file>` → exit 0 PASS, 1 FAIL (reason
  names the differing field), 2 usage error.
- Signing key: the owner's existing receipt-signing key (same file and
  construction as the deletion receipt — `NEPHEW_RECEIPT_SIGNING_KEY_FILE`
  or `~/.nephew/receipt-signing-key.json`). Run receipts and deletion
  receipts verify against the same owner public key.
- Storage: `~/.nephew/receipts/<YYYY-MM-DD>-<profileId>-<runId>.run-receipt.json`,
  mode 0600 (dir override: `NEPHEW_RECEIPTS_DIR`).

## MCP surface (landed with the wiring)

`profile_run` results carry `receiptPath` alongside the existing fields
on COMPLETED, REFUSED, and LOGIN_REQUIRED — the path when a receipt was
issued before the result returned, else `null`. A live-handoff run is
receipted at teardown, after the LOGIN_REQUIRED pause result has
already been returned, so its `receiptPath` is `null` there; the
receipt still lands on disk under the deterministic name above.

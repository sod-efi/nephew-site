/**
 * receipts — the public surface of the signed run-receipt module.
 *
 *   import { receipts } from "./receipts/index.ts";
 *   const { signed, receiptPath } = await receipts.finalizeRun({ ... });
 *   const verdict = receipts.verify(signed);            // { ok, status, tamperedFields, reason }
 *   const fileVerdict = await receipts.verifyFile(path);
 *
 * finalizeRun is the ONE call run-core makes at run end — see
 * INTEGRATION.md in this directory for the exact wiring.
 */
import { finalizeRun, verifyRunReceipt, verifyRunReceiptFile } from "./run-receipt.ts";

export const receipts = {
  finalizeRun,
  /** Verify a signed run receipt (object form). PASS/FAIL verdict; tampered fields are named. */
  verify: verifyRunReceipt,
  /** Read a receipt file from disk and verify it. */
  verifyFile: verifyRunReceiptFile,
};

export {
  finalizeRun,
  verifyRunReceipt,
  verifyRunReceiptFile,
  canonicalRunReceiptJson,
  computeFieldDigests,
  signRunReceipt,
  RUN_RECEIPT_FIELDS,
} from "./run-receipt.ts";
export type {
  FinalizeRunInput,
  FinalizeRunResult,
  RunEnvironment,
  RunMetricsSlice,
  RunReceipt,
  RunReceiptField,
  RunReceiptVerdict,
  SignedRunReceipt,
} from "./run-receipt.ts";

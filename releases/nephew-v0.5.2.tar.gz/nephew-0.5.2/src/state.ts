/**
 * state — Layer 1 capture/restore: cookies + per-origin localStorage.
 *
 * Capture reads cookies at browser level (Storage.getCookies) and walks the
 * origins the workload touched, reading localStorage in each origin's own
 * context (the only place it can be read). Restore reverses both. The result
 * is the plaintext state JSON that profile-store encrypts into the bundle —
 * this module never writes it to disk.
 */
import type { CdpClient } from "./cdp.ts";
import { setTimeout as sleep } from "node:timers/promises";

export interface StoredOrigin {
  origin: string;
  localStorage: { name: string; value: string }[];
}

export interface StoredState {
  cookies: Record<string, unknown>[];
  origins: StoredOrigin[];
}

async function navigate(cdp: CdpClient, sessionId: string, url: string): Promise<void> {
  await cdp.send("Page.navigate", { url }, sessionId);
  await sleep(1200);
}

/** Check and access storage in one JS task, so redirects cannot move secrets to another origin. */
export function originStorageExpression(origin: string, expression: string): string {
  const url = new URL(origin);
  if (!['http:', 'https:'].includes(url.protocol) || url.origin !== origin) {
    throw new Error('profile storage requires an exact HTTP(S) origin');
  }
  return `(() => { if (location.origin !== ${JSON.stringify(origin)}) throw new Error("profile storage origin mismatch"); return (${expression}); })()`;
}

async function storage<T>(cdp: CdpClient, sessionId: string, origin: string, expression: string): Promise<T> {
  try {
    return await cdp.evaluate<T>(sessionId, originStorageExpression(origin, expression));
  } catch {
    // Runtime exception details can contain page-controlled strings or the evaluated secret.
    throw new Error('profile storage access refused or failed; saved state was not updated');
  }
}

export async function captureState(
  cdp: CdpClient,
  sessionId: string,
  origins: string[],
): Promise<StoredState> {
  const { cookies } = await cdp.send("Storage.getCookies", {});
  const stored: StoredOrigin[] = [];
  for (const origin of origins) {
    await navigate(cdp, sessionId, origin + "/");
    const entries = await storage<{ name: string; value: string }[]>(
      cdp, sessionId, origin,
      `Object.entries(localStorage).map(([name, value]) => ({ name, value }))`,
    );
    stored.push({ origin, localStorage: entries ?? [] });
  }
  return { cookies: cookies ?? [], origins: stored };
}

export async function restoreState(
  cdp: CdpClient,
  sessionId: string,
  state: StoredState,
): Promise<void> {
  if (state.cookies.length) {
    await cdp.send("Storage.setCookies", { cookies: state.cookies });
  }
  for (const o of state.origins) {
    await navigate(cdp, sessionId, o.origin + "/");
    for (const { name, value } of o.localStorage) {
      await storage(
        cdp, sessionId, o.origin,
        `localStorage.setItem(${JSON.stringify(name)}, ${JSON.stringify(value)})`,
      );
    }
  }
}

/** Read back one origin's localStorage for verification. */
export async function readOriginStorage(
  cdp: CdpClient,
  sessionId: string,
  origin: string,
): Promise<{ name: string; value: string }[]> {
  await navigate(cdp, sessionId, origin + "/");
  return (
    (await storage<{ name: string; value: string }[]>(
      cdp, sessionId, origin,
      `Object.entries(localStorage).map(([name, value]) => ({ name, value }))`,
    )) ?? []
  );
}

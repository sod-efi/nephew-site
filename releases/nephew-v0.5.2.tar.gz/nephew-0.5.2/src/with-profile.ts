/**
 * with-profile — the TypeScript decorator/helper surface (delight brief §3,
 * Shape B): run a job function inside a carried, verified profile session.
 *
 *   import { withProfile } from "./src/with-profile.ts";
 *   await withProfile(bundleDir, "steel", async ({ cdp, sessionId }) => {
 *     // already logged in as the owner — no login code in this file
 *   });
 *
 * What it does, in order: load the owner-held bundle → print the trust
 * receipt through the log seam → open a provider session (the same
 * openers `nephew run` uses) → apply the bundle's emulation overrides →
 * FINGERPRINT GATE → restore the bundle state and verify it (all of that
 * is run-baseline's runInSession, reused, not reimplemented) → hand the
 * live session to fn → capture the session state back into the same
 * bundle (cookies + per-origin localStorage, via state.ts) → close the
 * session.
 *
 * The lifecycle is split in two so another driver can hold the session
 * between start and finish: openProfileSession() performs everything up
 * to the verified live session and returns it with complete() (capture
 * back, close, receipt) and abort() (close without capture-back,
 * receipt). withProfile() is the composition open → fn → complete/abort,
 * and the Python bridge (src/cli/python-bridge.ts) drives the same pair
 * over stdio for the `nephew` Python package — one lifecycle, never a
 * second implementation.
 *
 * Every terminal outcome that carried a profile is receipted exactly
 * once — refused / login-required at the pause, completed at
 * complete(), job-failed at abort() — through run-core's
 * issueRunReceipt → receipts.finalizeRun, the same construction
 * `nephew run` and the MCP surface use. Receipting never changes an
 * outcome: issuance failure logs one line and yields no path.
 *
 * PLAN GATE (cli/plan.ts): a session here counts against the same
 * licence runs-at-a-time limit `nephew run` / MCP `profile_run` obey.
 * openProfileSession() is the one entry both this helper and the
 * Python bridge ride on, and runProfileJob does NOT route through it
 * (run-core drives the baseline runners directly), so gating here
 * counts every bridge / library session exactly once and can never
 * double-count a CLI / MCP run. The gate mirrors run-core exactly:
 * resolve currentPlan(), write a run lock in the same locks directory
 * (~/.nephew/runs/locks/, or under NEPHEW_RUNS_DIR), rank it among the
 * live locks, and refuse with PlanLimitError BEFORE any provider
 * session is opened when the rank is past the plan's slots. The lock
 * is released on every exit path — complete(), abort(), a job error,
 * a capture-back failure, a gate / login refusal inside the open, and
 * a driver that vanishes (the bridge aborts on EOF). There is no
 * --dry-run on this surface (`nephew run --dry-run` never reaches
 * here), so nothing here needs a dry-run exemption.
 *
 * HONEST LIMITS of this subset (marked, not faked):
 *  1. Providers: steel + browseruse + browserbase. Modal is NOT supported here —
 *     its runner drives the browser from INSIDE the sandbox and exposes
 *     no host-side CDP session to hand to a job function. Use
 *     `nephew run --provider modal` for Modal. Calling withProfile with
 *     "modal" throws immediately and says exactly this.
 *  2. The handle is the baseline page session after restore+verify, left
 *     on the bundle's first origin. Multi-tab work, extra targets, and
 *     job navigation are the job function's own business (raw CDP).
 *  3. Capture-back covers the bundle's OWN origins (the Layer-1 subset
 *     every surface here carries: cookies are browser-wide; localStorage
 *     is per bundled origin). A login created mid-job on a NEW origin is
 *     not folded into the bundle by this helper — re-capture it with
 *     `nephew capture`.
 *  4. If fn throws, the session is closed WITHOUT capture-back: a failed
 *     job's half-mutated state never seals over the owner's bundle.
 */
import { join } from "node:path";
import { decryptState, encryptState, loadBundle, saveBundle, sealAad, type ProfileBundle } from "./profile-store.ts";
import { CdpClient, CdpTimeoutError } from "./cdp.ts";
import { captureState, type StoredState } from "./state.ts";
import type { ProviderName } from "./cli/args.ts";
import {
  acquireRunLock, currentPlan, liveRunLocks, runLimitProblem, runLocksDir, runRank,
  type CurrentPlan, type PlanLimits, type PlanName, type RunLock,
} from "./cli/plan.ts";
import { formatReceipt } from "./cli/receipt.ts";
import { issueRunReceipt } from "./cli/run-core.ts";
import type { finalizeRun } from "./receipts/run-receipt.ts";
import {
  openBrowserUseSession, openBrowserbaseSession, openSteelSession, resolveWsUrl, runInSession, writeRunRecord,
  type BaselineOutcome, type OpenedProviderSession,
} from "./cli/run-baseline.ts";

/** The live, verified session handed to the job function. */
export interface ProfileSessionHandle {
  /** Raw CDP client for the provider session (the job drives from here). */
  cdp: CdpClient;
  /** The attached page session, with the profile restored + verified. */
  sessionId: string;
  bundle: ProfileBundle;
  provider: "steel" | "browseruse" | "browserbase";
  /**
   * The provider-issued CDP endpoint (ws or http) for drivers that
   * connect from outside this process — a session capability, never
   * logged or recorded. Present with the real provider openers.
   */
  cdpUrl?: string;
}

/** Thrown when the live fingerprint fails the bundle recipe's gate. */
export class ProfileGateError extends Error {
  readonly changed: string[];
  readonly profileId: string;
  /** Signed run receipt for the refused run, when one was issued. */
  readonly receiptPath: string | null;
  constructor(changed: string[], profileId: string, receiptPath: string | null = null) {
    super(`fingerprint mismatch on: ${changed.join(", ")} — run refused before any state was released`);
    this.name = "ProfileGateError";
    this.changed = changed;
    this.profileId = profileId;
    this.receiptPath = receiptPath;
  }
}

/**
 * Thrown when the carried login does not hold — the structured pause from
 * the delight brief, as an error class with a machine-readable `status`
 * (the MCP surface returns the same shape as a result, not an error).
 */
export class LoginRequiredError extends Error {
  readonly status = "LOGIN_REQUIRED" as const;
  readonly designatedHuman?: string;
  readonly profileId: string;
  /** Signed run receipt for the paused run, when one was issued. */
  readonly receiptPath: string | null;
  constructor(bundle: ProfileBundle, receiptPath: string | null = null) {
    super(
      `LOGIN_REQUIRED — profile "${bundle.manifest.id}" did not verify as logged in; ` +
      `the designated human (${bundle.manifest.designatedHuman ?? "not recorded"}) re-captures with \`nephew capture\` and the job can be retried`,
    );
    this.name = "LoginRequiredError";
    this.designatedHuman = bundle.manifest.designatedHuman;
    this.profileId = bundle.manifest.id;
    this.receiptPath = receiptPath;
  }
}

/**
 * Thrown when the plan's runs-at-a-time limit is already in use — the
 * session-surface shape of run-core's "plan-limit" outcome (the MCP
 * surface maps the same facts to status REFUSED, reason "plan-limit").
 * Nothing ran: no provider session was opened, no bundle state was
 * released, and no run receipt is issued (run-core receipts none for a
 * plan-limit refusal either). `message` is the one line run-core's
 * runLimitProblem produces for this plan and live count.
 */
export class PlanLimitError extends Error {
  readonly status = "REFUSED" as const;
  readonly reason = "plan-limit" as const;
  readonly plan: PlanName;
  readonly limits: PlanLimits;
  constructor(plan: PlanName, limits: PlanLimits, message: string) {
    super(message);
    this.name = "PlanLimitError";
    this.plan = plan;
    this.limits = limits;
  }
}

export interface WithProfileOptions {
  /** Metrics-record job label (default "withProfile"). */
  job?: string;
  log?: (line: string) => void;
  /** Metrics directory override (tests); default the scaffold runs/. */
  runsDir?: string;
  /** Env for run-receipt resolution (signing key / receipts dir); default process.env. */
  env?: NodeJS.ProcessEnv;
  /** Receipt finalize seam (tests) — the same seam run-core exposes. */
  finalizeRunFn?: typeof finalizeRun;
  /** Session-opener seam (tests). */
  openSession?: (provider: "steel" | "browseruse" | "browserbase", log: (line: string) => void) => Promise<OpenedProviderSession>;
  /** In-session flow seam (tests). */
  runInSessionFn?: typeof runInSession;
  /** Fresh-connection seam (tests) for capture-back after the session's own connection died. */
  connectFresh?: (cdpUrl: string) => Promise<CdpClient>;
  /** Plan seam (tests); default cli/plan.currentPlan — the same seam run-core exposes. */
  currentPlanFn?: (deps: { env: NodeJS.ProcessEnv; now?: () => Date }) => Promise<CurrentPlan>;
  /**
   * Run-lock directory override (tests); default: <runsDir>/locks when
   * runsDir is set, else the shared runLocksDir(env)
   * (~/.nephew/runs/locks/, or under NEPHEW_RUNS_DIR) — the very
   * directory run-core's locks live in, so the two surfaces count
   * each other's runs.
   */
  locksDir?: string;
  /** Liveness seam for other runs' lock pids (tests) — forwarded to the lock helpers. */
  isPidAlive?: (pid: number) => boolean;
  /** Boot-time seam for the pre-boot lock check (tests). */
  bootTime?: () => number;
  /** Clock seam (tests) — the plan check and this session's lock stamp. */
  now?: () => Date;
}

/**
 * A live, verified profile session, held between openProfileSession()
 * and exactly one finish: complete() after the job ran, abort() when it
 * failed (or its driver vanished). Finishing is idempotent — a second
 * call returns the first finish's result and does nothing.
 */
export interface LiveProfileSession {
  handle: ProfileSessionHandle;
  bundle: ProfileBundle;
  provider: "steel" | "browseruse" | "browserbase";
  /** Capture the live state back into the bundle, close, receipt "completed". */
  complete(): Promise<{ receiptPath: string | null }>;
  /** Close WITHOUT capture-back; receipt "job-failed". */
  abort(): Promise<{ receiptPath: string | null }>;
}

/**
 * Everything up to the verified live session: plan gate (PlanLimitError
 * before anything else when the plan's runs are all in use) → bundle →
 * trust receipt → provider session → fingerprint gate → restore +
 * verify. Gate refusal and an unverified restore close the session,
 * receipt the run, and throw the structured errors (ProfileGateError /
 * LoginRequiredError, each carrying the receipt path) — the same
 * terminal shapes withProfile has always produced.
 */
/**
 * Capture-back that survives a job driving its OWN CDP client (the
 * documented Python pattern: Playwright connect_over_cdp on the cdpUrl).
 * When that client disconnects, the bridge's connection can be closed
 * under us (Browserbase ends a session on disconnect unless keepAlive is
 * set), or left silent until the 30 s timeout. So: try the session's own
 * connection first; if it is closed or fails, capture over a freshly
 * established connection to the same endpoint (browser-level cookies need
 * no page session; localStorage is read through a page target we attach
 * to). If even that cannot connect, say what happened instead of leaving
 * a bare "CDP connection closed".
 */
export async function captureStateResilient(
  session: Pick<OpenedProviderSession, "cdp" | "pageSessionId" | "cdpUrl">,
  origins: string[],
  log: (line: string) => void = () => {},
  /** Seam (tests): how the fresh connection is opened. */
  connect: (cdpUrl: string) => Promise<CdpClient> = async (u) => CdpClient.connect(await resolveWsUrl(u), 15_000),
): Promise<StoredState> {
  let firstError: unknown = null;
  if (!session.cdp.isClosed) {
    try {
      return await captureState(session.cdp, session.pageSessionId, origins);
    } catch (e) {
      // Only a lost connection (closed or silent) is worth a second one;
      // any other failure is the real error and stands.
      if (!(session.cdp.isClosed || e instanceof CdpTimeoutError || /CDP connection closed/.test(String((e as Error)?.message)))) throw e;
      firstError = e;
    }
  } else {
    firstError = new Error("CDP connection closed");
  }
  if (!session.cdpUrl) throw firstError;
  log(`capture     the session's own connection was unusable — capturing over a fresh one`);
  let fresh: CdpClient;
  try {
    fresh = await connect(session.cdpUrl);
  } catch (e) {
    throw new Error(
      "capture-back failed: the provider session ended when the job's own CDP client disconnected, " +
      `and it could not be reached again (${(e instanceof Error ? e.message : String(e)).split("\n")[0]}). ` +
      "Nothing was sealed over the bundle.",
    );
  }
  try {
    const { targetInfos } = await fresh.send("Target.getTargets", {});
    const page = (targetInfos as Array<{ type: string; targetId: string }>).find((t) => t.type === "page");
    const targetId: string = page
      ? page.targetId
      : (await fresh.send("Target.createTarget", { url: "about:blank" })).targetId;
    const { sessionId } = await fresh.send("Target.attachToTarget", { targetId, flatten: true });
    return await captureState(fresh, sessionId as string, origins);
  } finally {
    fresh.close();
  }
}

export async function openProfileSession(
  bundleDir: string,
  provider: ProviderName,
  opts: WithProfileOptions = {},
): Promise<LiveProfileSession> {
  if (provider === "modal") {
    throw new Error(
      "withProfile does not support provider \"modal\" yet: the modal runner drives its browser from inside the sandbox and exposes no host-side CDP session to hand a job function — use `nephew run --provider modal` (documented limit, src/with-profile.ts)",
    );
  }
  const log = opts.log ?? (() => {});
  const env = opts.env ?? process.env;
  const job = opts.job ?? "withProfile";

  // ---- Plan gate: the same licence runs-at-a-time limit run-core
  // enforces for `nephew run` / MCP profile_run, mirrored exactly
  // (see the header). This runs before the bundle is loaded and long
  // before any provider session exists; a refusal releases its own
  // lock and throws PlanLimitError with run-core's one line.
  const plan = await (opts.currentPlanFn ?? currentPlan)({ env, now: opts.now });
  if (plan.note) log(`plan        ${plan.note}`);
  // plan.ts's lock helpers take the locks directory itself as their
  // `runsDir` dep (the default being runLocksDir(env)).
  const lockDeps = {
    env,
    runsDir: opts.locksDir ?? (opts.runsDir ? join(opts.runsDir, "locks") : runLocksDir(env)),
    now: opts.now,
    isPidAlive: opts.isPidAlive,
    bootTime: opts.bootTime,
  };
  const lock: RunLock = await acquireRunLock({ bundleDir, job, provider }, lockDeps);
  let lockHeld = true;
  const releaseLock = async (): Promise<void> => {
    if (!lockHeld) return;
    lockHeld = false;
    await lock.release().catch(() => { /* release is idempotent; a swept lock is already gone */ });
  };
  const liveLocks = await liveRunLocks(lockDeps);
  const problem = runLimitProblem(plan, runRank(liveLocks, lock.path) + 1);
  if (problem) {
    await releaseLock();
    throw new PlanLimitError(plan.plan, plan.limits, problem);
  }

  // Everything from here to the returned LiveProfileSession is covered
  // by this catch: any failure (bundle load, provider open, in-session
  // flow, fingerprint gate, unverified restore) releases the lock
  // before the error stands. On success the lock's ownership moves to
  // the returned session, whose complete()/abort() release it.
  try {
    return await openProfileSessionGated(bundleDir, provider, opts, { log, env, job, releaseLock });
  } catch (e) {
    await releaseLock();
    throw e;
  }
}

/**
 * The pre-gate lifecycle, unchanged: bundle → trust receipt → provider
 * session → gate → restore + verify → the live session. Split out so
 * openProfileSession's plan gate wraps it whole; `releaseLock` is the
 * gate's idempotent release, called by the returned session's finish
 * paths (and by openProfileSession itself when this throws).
 */
async function openProfileSessionGated(
  bundleDir: string,
  provider: "steel" | "browseruse" | "browserbase",
  opts: WithProfileOptions,
  gate: {
    log: (line: string) => void;
    env: NodeJS.ProcessEnv;
    job: string;
    releaseLock: () => Promise<void>;
  },
): Promise<LiveProfileSession> {
  const { log, env, job, releaseLock } = gate;
  const bundle = await loadBundle(bundleDir);
  // Trust receipt — before anything starts, on every path (through the
  // log seam: silent for library callers, on stderr for the bridge).
  for (const line of formatReceipt(bundle)) log(line);
  const startedAt = new Date();
  const receiptFor = (outcome: string, metrics?: BaselineOutcome["metrics"]) =>
    issueRunReceipt({
      bundle, job, provider, outcome, metrics, handoffUsed: false,
      startedAt, env, log, finalizeRunFn: opts.finalizeRunFn,
    });
  const open = opts.openSession ?? ((p, l) =>
    p === "steel" ? openSteelSession(l) : p === "browserbase" ? openBrowserbaseSession(l) : openBrowserUseSession(l));
  const session = await open(provider, log);
  let outcome: BaselineOutcome;
  try {
    outcome = await (opts.runInSessionFn ?? runInSession)(
      session.cdp, session.pageSessionId, job, bundle,
      provider === "steel" ? "steel-cloud" : provider === "browserbase" ? "browserbase-cloud" : "browser-use-cloud", log,
      // Deferred: the metrics record is written after the session's
      // close (below, or in closeOnce at the finish) so its notes carry
      // the rule-6 residue outcome — writeRunRecord consumes it.
      { runsDir: opts.runsDir, deferRecord: true },
    );
  } catch (e) {
    await session.close().catch(() => { /* the opener's teardown is best-effort */ });
    throw e;
  }
  if (!outcome.gateOk) {
    await session.close();
    await writeRunRecord(outcome, session.residueCheck, log);
    const receiptPath = await receiptFor("refused", outcome.metrics);
    throw new ProfileGateError(outcome.gateChanged, bundle.manifest.id, receiptPath);
  }
  if (!outcome.verified) {
    await session.close();
    await writeRunRecord(outcome, session.residueCheck, log);
    const receiptPath = await receiptFor("login-required", outcome.metrics);
    throw new LoginRequiredError(bundle, receiptPath);
  }

  const handle: ProfileSessionHandle = {
    cdp: session.cdp,
    sessionId: session.pageSessionId,
    bundle,
    provider,
    ...(session.cdpUrl ? { cdpUrl: session.cdpUrl } : {}),
  };
  let closed = false;
  let finishResult: { receiptPath: string | null } | null = null;
  const closeOnce = async () => {
    if (closed) return;
    closed = true;
    await session.close();
    // The run's metrics record lands here, at the finish: written
    // after close so its notes carry the residue outcome.
    await writeRunRecord(outcome, session.residueCheck, log);
  };
  return {
    handle,
    bundle,
    provider,
    async complete() {
      if (finishResult) return finishResult;
      // The plan lock is released on EVERY finish path — capture-back
      // failure included — via this finally (releaseLock is
      // idempotent, and issueRunReceipt never throws, so a completed
      // finish releases exactly once, after its receipt is issued).
      try {
        // Capture-back: seal the job's session state into the same bundle,
        // so the next run — on either provider — continues from here. A
        // capture failure still closes the session and propagates, exactly
        // as withProfile has always behaved (no receipt: the run's own
        // ending is the error).
        try {
          const state = JSON.parse(decryptState(bundle.encryptedState, sealAad(bundle))) as StoredState;
          const captured = await captureStateResilient(session, state.origins.map((o) => o.origin), log, opts.connectFresh);
          await saveBundle({
            ...bundle,
            manifest: { ...bundle.manifest, updatedAt: new Date().toISOString() },
            encryptedState: encryptState(JSON.stringify(captured), sealAad(bundle)),
          }, bundleDir);
          log(`captured    state sealed back into the owner bundle`);
        } finally {
          await closeOnce();
        }
        const receiptPath = await receiptFor("completed", outcome.metrics);
        finishResult = { receiptPath };
        return finishResult;
      } finally {
        await releaseLock();
      }
    },
    async abort() {
      if (finishResult) return finishResult;
      try {
        await closeOnce();
        const receiptPath = await receiptFor("job-failed", outcome.metrics);
        finishResult = { receiptPath };
        return finishResult;
      } finally {
        await releaseLock();
      }
    },
  };
}

export async function withProfile<T>(
  bundleDir: string,
  provider: ProviderName,
  fn: (session: ProfileSessionHandle) => Promise<T>,
  opts: WithProfileOptions = {},
): Promise<T> {
  const live = await openProfileSession(bundleDir, provider, opts);
  let result: T;
  try {
    result = await fn(live.handle);
  } catch (e) {
    // A failed job's half-mutated state never seals over the owner's
    // bundle: close without capture-back, then the job's error stands.
    await live.abort();
    throw e;
  }
  await live.complete();
  return result;
}

#!/usr/bin/env python3
"""
modal_driver — the in-sandbox half of `nephew run --provider modal`.

WHY THIS EXISTS (the architectural fix, 2026-10-30): the previous Modal
runner drove the sandbox browser from the HOST over the Modal tunnel —
and this host cannot reach *.modal.host tunnel hosts at all (Node fetch,
curl, and Python all fail to connect, while sandbox creation succeeds in
~2.5 s). So the driving step moved to where the browser is: this driver
runs INSIDE the sandbox, talks CDP to Chromium on loopback (reachable by
construction), and returns only the structured result. Co-location is
also the better product architecture: the browser-driving step belongs
next to the browser; only results cross back.

Protocol: one JSON request object on stdin, exactly one JSON response
line on stdout, exit code 0 whenever a response was produced (failures
are {"ok": false, "error": ...}). It mirrors tools/modal_bridge.py.

Phases (the host runs them in order, gating between them):
  probe   {phase, overrides, probeUrl, probeExpression, egressExpression}
          -> {ok, phase: "probe", fpLive}
          Attach, apply the bundle's Emulation overrides, capture the
          fingerprint with the host-supplied probe expression. NO state
          is in this payload: the host sends state only after its
          fingerprint gate accepts fpLive.
  restore {phase, state, captureBack}
          -> {ok, phase: "restore", verified, capturedState?}
          Restore cookies + per-origin localStorage, verify every
          origin (sorted localStorage compare + cookie count), and —
          only when verified AND asked — capture the live state back
          out for the host to re-seal into the owner bundle.

Either phase's payload may carry `proxyAuth` {username, password} when
the bundle pins a proxy: Chromium was launched with --proxy-server by
the host, and the driver answers its 407 challenges on the page session
via CDP Fetch auth (Fetch.enable + Fetch.continueWithAuth). The
credentials arrive only in this request (the run's secret channel),
stay in process memory, and never appear in a result line or log.

The step order, waits (1200 ms navigate settle, 1500 ms probe settle),
and verification semantics mirror src/state.ts + src/fingerprint.ts so a
modal run measures the same thing the baselines measure. The probe and
egress expressions ARRIVE in the payload (the host exports them from
src/fingerprint.ts) — there is no second copy here to drift.

Stdlib only: the sandbox image carries no pip packages for this driver.
The WebSocket client below is the minimal client side of RFC 6455 that
CDP needs (masked sends, fragmented receives, ping -> pong).
"""
import base64
import json
import os
import socket
import struct
import sys
import time
import urllib.request
from urllib.parse import urlparse

CDP_HTTP = "http://127.0.0.1:9222"
BOOT_POLL_ATTEMPTS = 40
BOOT_POLL_DELAY_S = 0.75
SOCKET_TIMEOUT_S = 30
NAVIGATE_SETTLE_S = 1.2   # src/state.ts navigate()
PROBE_SETTLE_S = 1.5      # src/fingerprint.ts captureFingerprint()


class DriverError(Exception):
    pass


# ---------------------------------------------------------------- WebSocket

class WsClient:
    def __init__(self, url: str):
        u = urlparse(url)
        host = u.hostname or "127.0.0.1"
        port = u.port or 80
        path = u.path or "/"
        if u.query:
            path += "?" + u.query
        self.sock = socket.create_connection((host, port), timeout=SOCKET_TIMEOUT_S)
        key = base64.b64encode(os.urandom(16)).decode()
        handshake = (
            f"GET {path} HTTP/1.1\r\n"
            f"Host: {host}:{port}\r\n"
            "Upgrade: websocket\r\n"
            "Connection: Upgrade\r\n"
            f"Sec-WebSocket-Key: {key}\r\n"
            "Sec-WebSocket-Version: 13\r\n\r\n"
        )
        self.sock.sendall(handshake.encode())
        buf = b""
        while b"\r\n\r\n" not in buf:
            chunk = self.sock.recv(4096)
            if not chunk:
                raise DriverError("websocket handshake closed early")
            buf += chunk
            if len(buf) > 65536:
                raise DriverError("websocket handshake headers too large")
        head, _, self._rest = buf.partition(b"\r\n\r\n")
        status = head.split(b"\r\n", 1)[0]
        if b" 101" not in status:
            raise DriverError(f"websocket upgrade refused: {status.decode(errors='replace')[:80]}")

    def _read_exact(self, n: int) -> bytes:
        while len(self._rest) < n:
            chunk = self.sock.recv(65536)
            if not chunk:
                raise DriverError("websocket connection closed")
            self._rest += chunk
        out, self._rest = self._rest[:n], self._rest[n:]
        return out

    def _read_message(self) -> str:
        payload = b""
        while True:
            b0, b1 = self._read_exact(2)
            fin = bool(b0 & 0x80)
            opcode = b0 & 0x0F
            length = b1 & 0x7F
            if length == 126:
                length = struct.unpack(">H", self._read_exact(2))[0]
            elif length == 127:
                length = struct.unpack(">Q", self._read_exact(8))[0]
            data = self._read_exact(length) if length else b""
            if opcode == 0x8:
                raise DriverError("websocket closed by the browser")
            if opcode == 0x9:  # ping -> pong, echoing the payload
                self._send_frame(0xA, data)
                continue
            if opcode in (0x1, 0x2, 0x0):
                payload += data
                if fin:
                    return payload.decode("utf-8", errors="replace")
            # pong and anything else: ignore

    def _send_frame(self, opcode: int, data: bytes) -> None:
        mask = os.urandom(4)
        header = bytearray([0x80 | opcode])
        n = len(data)
        if n < 126:
            header.append(0x80 | n)
        elif n <= 0xFFFF:
            header.append(0x80 | 126)
            header += struct.pack(">H", n)
        else:
            header.append(0x80 | 127)
            header += struct.pack(">Q", n)
        masked = bytes(b ^ mask[i % 4] for i, b in enumerate(data))
        self.sock.sendall(bytes(header) + mask + masked)

    def send_text(self, text: str) -> None:
        self._send_frame(0x1, text.encode())


# --------------------------------------------------------------------- CDP

class Cdp:
    """Strictly sequential CDP: one call in flight, events skipped —
    except Fetch events, which are answered inline (see below)."""

    def __init__(self, ws: WsClient):
        self.ws = ws
        self._next_id = 0
        # Proxy credentials for Fetch auth challenges, set by
        # attach_page when the driver request carries proxyAuth. They
        # live only in this process's memory: never logged, never in a
        # result line (AGENTS.md #3).
        self.proxy_auth: dict | None = None
        self._auth_answered: set = set()

    def _answer_auth(self, event: dict) -> None:
        """Answer a Fetch.authRequired challenge (proxy 407 / server 401).

        Fire-and-forget: the continueWithAuth reply carries a fresh id,
        which the sequential reader skips like any stray reply. Each
        requestId gets credentials at most once — a repeat challenge for
        the same request means the credentials were rejected, and
        cancelling beats an auth loop that would starve the awaited
        reply forever.
        """
        params = event.get("params") or {}
        request_id = params.get("requestId")
        # Only the proxy's own 407 gets the proxy credentials. A page (or
        # any subresource it loads) answering 401 with a Basic challenge
        # would otherwise be handed the owner's zone username and
        # password — and with them the dedicated egress IP.
        challenge = params.get("authChallenge") or {}
        from_proxy = challenge.get("source") == "Proxy"
        if self.proxy_auth and from_proxy and request_id not in self._auth_answered:
            self._auth_answered.add(request_id)
            response = {
                "response": "ProvideCredentials",
                "username": self.proxy_auth.get("username", ""),
                "password": self.proxy_auth.get("password", ""),
            }
        else:
            response = {"response": "CancelAuth"}
        self._next_id += 1
        msg: dict = {
            "id": self._next_id,
            "method": "Fetch.continueWithAuth",
            "params": {"requestId": request_id, "authChallengeResponse": response},
        }
        if event.get("sessionId"):
            msg["sessionId"] = event["sessionId"]
        self.ws.send_text(json.dumps(msg))

    def _continue_request(self, event: dict) -> None:
        """Release a Fetch.requestPaused request, unchanged.

        Enabling the Fetch domain pauses every request at the Request
        stage (the enable call in attach_page pins that stage
        explicitly); a paused request waits forever unless continued,
        which starved the awaited CDP reply until the socket timeout —
        the probe-phase "timed out" failures of 2026-10-30. Fire-and-
        forget, same shape as _answer_auth: fresh id, stray reply
        skipped by the reader.
        """
        params = event.get("params") or {}
        self._next_id += 1
        msg: dict = {
            "id": self._next_id,
            "method": "Fetch.continueRequest",
            "params": {"requestId": params.get("requestId")},
        }
        if event.get("sessionId"):
            msg["sessionId"] = event["sessionId"]
        self.ws.send_text(json.dumps(msg))

    def send(self, method: str, params: dict | None = None, session_id: str | None = None) -> dict:
        self._next_id += 1
        call_id = self._next_id
        msg: dict = {"id": call_id, "method": method, "params": params or {}}
        if session_id:
            msg["sessionId"] = session_id
        self.ws.send_text(json.dumps(msg))
        while True:
            reply = json.loads(self.ws._read_message())
            if reply.get("method") == "Fetch.authRequired":
                self._answer_auth(reply)
                continue  # an auth challenge mid-call — handled, keep waiting
            if reply.get("method") == "Fetch.requestPaused":
                self._continue_request(reply)
                continue  # a paused request mid-call — released, keep waiting
            if reply.get("id") != call_id:
                continue  # an event or a stray reply — not ours
            if "error" in reply:
                raise DriverError(f"CDP {method} failed: {json.dumps(reply['error'])[:200]}")
            return reply.get("result") or {}

    def evaluate(self, session_id: str, expression: str):
        r = self.send(
            "Runtime.evaluate",
            {"expression": expression, "returnByValue": True, "awaitPromise": True},
            session_id,
        )
        if r.get("exceptionDetails"):
            raise DriverError(f"page evaluation failed: {json.dumps(r['exceptionDetails'])[:200]}")
        return (r.get("result") or {}).get("value")


# ------------------------------------------------------------------ helpers

def wait_for_browser() -> str:
    last: Exception | None = None
    for _ in range(BOOT_POLL_ATTEMPTS):
        try:
            with urllib.request.urlopen(CDP_HTTP + "/json/version", timeout=5) as resp:
                version = json.loads(resp.read())
            url = version.get("webSocketDebuggerUrl")
            if url:
                return url
        except Exception as e:  # Chromium still booting — poll again
            last = e
        time.sleep(BOOT_POLL_DELAY_S)
    raise DriverError(f"sandbox Chromium never answered on {CDP_HTTP}: {last}")


def attach_page(cdp: Cdp, proxy_auth: dict | None = None) -> str:
    targets = (cdp.send("Target.getTargets").get("targetInfos")) or []
    page = next((t for t in targets if t.get("type") == "page"), targets[0] if targets else None)
    if not page:
        raise DriverError("sandbox browser exposed no page target")
    session_id = cdp.send(
        "Target.attachToTarget", {"targetId": page["targetId"], "flatten": True}
    )["sessionId"]
    cdp.send("Page.enable", {}, session_id)
    cdp.send("Runtime.enable", {}, session_id)
    if proxy_auth:
        # The sandbox Chromium was launched with --proxy-server; its 407
        # challenges surface on this session as Fetch.authRequired,
        # which Cdp.send answers from cdp.proxy_auth. Enabling Fetch
        # also pauses requests at the Request stage — the patterns pin
        # that stage explicitly, and Cdp.send releases each paused
        # request via Fetch.continueRequest. Enabled before any
        # navigation so the probe page itself loads through the proxy.
        cdp.proxy_auth = proxy_auth
        cdp.send(
            "Fetch.enable",
            {
                "handleAuthRequests": True,
                "patterns": [{"urlPattern": "*", "requestStage": "Request"}],
            },
            session_id,
        )
    return session_id


def navigate(cdp: Cdp, session_id: str, url: str, settle_s: float = NAVIGATE_SETTLE_S) -> None:
    cdp.send("Page.navigate", {"url": url}, session_id)
    time.sleep(settle_s)


def origin_storage(cdp: Cdp, session_id: str, origin: str, expression: str):
    # The guard and operation run atomically in the same page task, including after redirects.
    from urllib.parse import urlsplit
    parsed = urlsplit(origin)
    if parsed.scheme not in ("http", "https") or not parsed.netloc or parsed.path or parsed.query or parsed.fragment or parsed.username:
        raise DriverError("profile storage requires an exact HTTP(S) origin")
    guarded = f'(() => {{ if (location.origin !== {json.dumps(origin)}) throw new Error("profile storage origin mismatch"); return ({expression}); }})()'
    try:
        return cdp.evaluate(session_id, guarded)
    except Exception:
        raise DriverError("profile storage access refused or failed; saved state was not updated") from None


def read_origin_storage(cdp: Cdp, session_id: str, origin: str) -> list:
    navigate(cdp, session_id, origin + "/")
    entries = origin_storage(
        cdp, session_id, origin,
        "Object.entries(localStorage).map(([name, value]) => ({ name, value }))",
    )
    return entries or []


def apply_overrides(cdp: Cdp, session_id: str, overrides: dict) -> None:
    if overrides.get("userAgent"):
        cdp.send("Emulation.setUserAgentOverride", {"userAgent": overrides["userAgent"]}, session_id)
    if overrides.get("timezone"):
        cdp.send("Emulation.setTimezoneOverride", {"timezoneId": overrides["timezone"]}, session_id)
    if overrides.get("locale"):
        cdp.send("Emulation.setLocaleOverride", {"locale": overrides["locale"]}, session_id)
    viewport = overrides.get("viewport")
    if viewport:
        cdp.send(
            "Emulation.setDeviceMetricsOverride",
            {
                "width": viewport["width"],
                "height": viewport["height"],
                "deviceScaleFactor": viewport.get("deviceScaleFactor") or 1,
                "mobile": False,
                "screenWidth": viewport["width"],
                "screenHeight": viewport["height"],
            },
            session_id,
        )


def as_str(value) -> str:
    return "" if value is None else str(value)


# ------------------------------------------------------------------- phases

def do_probe(cdp: Cdp, req: dict) -> dict:
    session_id = attach_page(cdp, req.get("proxyAuth"))
    apply_overrides(cdp, session_id, req.get("overrides") or {})
    navigate(cdp, session_id, req["probeUrl"], settle_s=PROBE_SETTLE_S)
    probe = cdp.evaluate(session_id, req["probeExpression"]) or {}
    try:
        egress = cdp.evaluate(session_id, req["egressExpression"])
    except Exception:
        egress = ""
    try:
        concurrency = int(probe.get("hardwareConcurrency") or 0)
    except (TypeError, ValueError):
        concurrency = 0
    return {
        "ok": True,
        "phase": "probe",
        "fpLive": {
            "userAgent": as_str(probe.get("userAgent")),
            "timezone": as_str(probe.get("timezone")),
            "canvasHash": as_str(probe.get("canvasHash")),
            "webglVendor": as_str(probe.get("webglVendor")),
            "webglRenderer": as_str(probe.get("webglRenderer")),
            "audioHash": as_str(probe.get("audioHash")),
            "fontsHash": as_str(probe.get("fontsHash")),
            "screen": as_str(probe.get("screen")),
            "hardwareConcurrency": concurrency,
            "egressIp": as_str(egress),
        },
    }


def sorted_entries(entries: list) -> list:
    return sorted(entries, key=lambda e: e.get("name", ""))


def do_restore(cdp: Cdp, req: dict) -> dict:
    session_id = attach_page(cdp, req.get("proxyAuth"))
    state = req["state"]
    cookies = state.get("cookies") or []
    origins = state.get("origins") or []

    if cookies:
        cdp.send("Storage.setCookies", {"cookies": cookies})
    for origin in origins:
        navigate(cdp, session_id, origin["origin"] + "/")
        for entry in origin.get("localStorage") or []:
            origin_storage(
                cdp, session_id, origin["origin"],
                f"localStorage.setItem({json.dumps(entry['name'])}, {json.dumps(entry['value'])})",
            )

    ls_all_match = True
    for origin in origins:
        restored = read_origin_storage(cdp, session_id, origin["origin"])
        if sorted_entries(restored) != sorted_entries(origin.get("localStorage") or []):
            ls_all_match = False
    live_cookies = cdp.send("Storage.getCookies", {}).get("cookies") or []
    verified = ls_all_match and len(live_cookies) == len(cookies)

    out: dict = {"ok": True, "phase": "restore", "verified": verified}
    # Capture-back ONLY on a verified restore — sealing a stranger's state
    # over the owner's is the one outcome this flow must never produce.
    if verified and req.get("captureBack"):
        captured_cookies = cdp.send("Storage.getCookies", {}).get("cookies") or []
        captured_origins = [
            {"origin": o["origin"], "localStorage": read_origin_storage(cdp, session_id, o["origin"])}
            for o in origins
        ]
        out["capturedState"] = {"cookies": captured_cookies, "origins": captured_origins}
    return out


def main() -> int:
    # GUARD: never write request or state data to stderr (no debug
    # prints of payloads, credentials, cookies, or page content). The
    # bridge folds the driver's stderr tail into host-visible errors,
    # so anything logged here crosses the trust boundary.
    try:
        req = json.loads(sys.stdin.read())
        cdp = Cdp(WsClient(wait_for_browser()))
        phase = req.get("phase")
        if phase == "probe":
            out = do_probe(cdp, req)
        elif phase == "restore":
            out = do_restore(cdp, req)
        else:
            out = {"ok": False, "error": f"unknown driver phase: {phase!r}"}
    except Exception as e:  # one JSON line, first line of the message only
        out = {"ok": False, "error": str(e).split("\n")[0][:300]}
    print(json.dumps(out))
    return 0


if __name__ == "__main__":
    sys.exit(main())

/**
 * cli/args — argument parsing for the `nephew` CLI. Pure and unit-tested:
 * no I/O, no env reads except through the injected env map in
 * modalConnectionProblem(). The command surface is the owner's decision
 * (../2026-10-29-nephew-cli-decision.md): `nephew run` is the product.
 */

export type ProviderName = "steel" | "browseruse" | "modal" | "browserbase";

export const PROVIDERS: readonly ProviderName[] = ["steel", "browseruse", "modal", "browserbase"];

export interface RunCommand {
  command: "run";
  job: string;
  provider: ProviderName;
  dryRun: boolean;
  bundleDir?: string;
  /**
   * Streamed human handoff on a LOGIN_REQUIRED pause (src/handoff/):
   * present only when --handoff (or a tuning flag) was given.
   */
  handoff?: { ttlMs?: number; port?: number };
}

export interface RevokeCommand {
  command: "revoke";
  bundleDir?: string;
  /** Extra copy of the signed deletion receipt to write. */
  receiptFile?: string;
  /** Key-material file to destroy together with the bundle (owner-named only). */
  keyFile?: string;
}

export interface InitCommand {
  command: "init";
}

export interface CaptureCommand {
  command: "capture";
  bundleDir?: string;
  /** Profile id (also the default bundle directory name). */
  name?: string;
  /** The profile's designated human — who a paused run calls on. */
  human?: string;
  /** Extra origins to capture localStorage for, beyond the open pages. */
  sites: string[];
  /** Fingerprint seed for the new profile (default: freshly drawn). */
  seed?: number;
}

export interface McpCommand {
  command: "mcp";
}

export interface BridgeCommand {
  command: "bridge";
}

export interface ReceiptVerifyCommand {
  command: "receipt";
  action: "verify";
  /** Signed run-receipt file to verify (see src/receipts/). */
  file: string;
}

export interface LoginCommand {
  command: "login";
  /**
   * The BYO licence key (NPW-BYO-XXXX-XXXX-XXXX-XXXX). Absent: the stored
   * key is re-checked, or asked for when none is stored; absent with --forget.
   */
  key?: string;
  /** Drop the saved key and go back to Free. */
  forget: boolean;
}

export interface PlanCommand {
  command: "plan";
}

export interface ProfilesCommand {
  command: "profiles";
  /** add: more extra profiles on the BYO plan ($3/mo each); remove: fewer. */
  action: "add" | "remove";
  /** How many (default 1). */
  count: number;
}

/** The most extra profiles one BYO plan takes (the service refuses more). */
export const MAX_EXTRA_PROFILES = 90;

export type HelpTopic = "run" | "revoke" | "init" | "capture" | "mcp" | "receipt" | "bridge" | "login" | "plan" | "profiles";

export interface HelpCommand {
  command: "help";
  topic?: HelpTopic;
}

export type CliCommand =
  | RunCommand | RevokeCommand | InitCommand | CaptureCommand | McpCommand | BridgeCommand
  | ReceiptVerifyCommand | LoginCommand | PlanCommand | ProfilesCommand | HelpCommand;

export type ParseResult =
  | { ok: true; value: CliCommand }
  | { ok: false; error: string };

export const USAGE = `nephew — run agent jobs with your own portable browser profile

usage:
  nephew init [--help]                       connect your own provider accounts
  nephew capture [--name <id>] [--human <who>] [--bundle <dir>]
  nephew run <job> --provider steel|browseruse|modal|browserbase [--dry-run] [--bundle <dir>] [--handoff]
  nephew revoke [--bundle <dir>] [--key-file <file>] [--receipt <file>]
  nephew receipt verify <file>               verify a signed run receipt
  nephew login [key] | --forget              turn on your BYO plan with its licence key (no key: re-check the stored one)
  nephew plan                                the plan you're on and its limits
  nephew profiles add|remove [n]             more or fewer extra BYO profiles ($3/mo each)
  nephew mcp                                 MCP server (stdio) exposing profile_run
  nephew bridge                              Python bridge (stdio) for the nephew Python package — not a user surface
  nephew <command> --help
  nephew --help

plans:
  Free        $0 — 2 profiles, 1 run at a time; no key needed
  BYO         $19/mo — 10 profiles, 3 runs at a time; nephew login <key> turns it on
              extra profiles $3/mo each: nephew profiles add
              https://nephew.ai/#pricing

providers:
  steel       Steel Cloud (proven baseline: bundle state restore)
  browseruse  Browser Use Cloud (proven baseline: bundle state restore)
  modal       Modal Sandbox, own-stack Chromium — needs MODAL_TOKEN_ID + MODAL_TOKEN_SECRET
  browserbase Browserbase (proven baseline: bundle state restore)

options:
  --provider <name>  provider to run on (default: steel)
  --bundle <dir>     owner-held bundle directory
                     (default: $NEPHEW_BUNDLE_DIR, else ~/.nephew/profiles/default)
  --dry-run          print the trust receipt + run plan; create no session

env:
  PROFILE_ENCRYPTION_KEY  bundle decryption key (capture + live runs)
  MODAL_TOKEN_ID / MODAL_TOKEN_SECRET  Modal connection (provider: modal)
  STEEL_API_KEY / BROWSER_USE_API_KEY / BROWSERBASE_API_KEY / BRIGHTDATA_API_KEY
                     provider keys (nephew init checks them; nephew run uses the same ones)
  NEPHEW_PROXY_USERNAME / NEPHEW_PROXY_PASSWORD  pinned-proxy credentials (modal runs)
  OWN_STACK_CHROME_PATH  your own fingerprint-chromium for capture (auto-installed on Linux x86_64)`;

export const RUN_USAGE = `usage: nephew run <job> --provider steel|browseruse|modal|browserbase [--dry-run] [--bundle <dir>] [--handoff [--handoff-ttl <seconds>] [--handoff-port <n>]]

  <job>              job name (labels the run + its metrics record)
  --provider <name>  steel | browseruse | modal | browserbase (default: steel)
  --bundle <dir>     owner-held bundle directory
  --dry-run          print the trust receipt + run plan; create no session
  --handoff          if the run pauses at LOGIN_REQUIRED, stream the live
                     session to the profile's designated human (loopback
                     page + per-handoff token) instead of only failing;
                     steel/browseruse/browserbase only — modal has no
                     host-side CDP
  --handoff-ttl <s>  handoff hard expiry in seconds (default: 360)
  --handoff-port <n> loopback port for the handoff page (default: any free port)

env:
  PROFILE_ENCRYPTION_KEY  bundle decryption key
  NEPHEW_PROXY_USERNAME / NEPHEW_PROXY_PASSWORD
                     credentials of the bundle's pinned proxy, needed for a
                     modal run of a pinned bundle (answered to the proxy only;
                     steel, browseruse and browserbase run on their own egress)
  NEPHEW_RUNS_DIR    where run records go (default: ~/.nephew/runs)`;

export const REVOKE_USAGE = `usage: nephew revoke [--bundle <dir>] [--key-file <file>] [--receipt <file>]

  Destroy the owner-held bundle and issue a signed deletion receipt
  (written next to the bundle as <bundle>.deletion-receipt.json).
  One command is the confirmation — there is no undo.

  --bundle <dir>     owner-held bundle directory
                     (default: $NEPHEW_BUNDLE_DIR, else ~/.nephew/profiles/default)
  --key-file <file>  key-material file to destroy together with the bundle
                     (only a file you name here is ever deleted)
  --receipt <file>   also write a copy of the signed deletion receipt here

env:
  NEPHEW_RECEIPT_SIGNING_KEY_FILE  owner receipt-signing key file
                     (default: ~/.nephew/receipt-signing-key.json)`;

export const INIT_USAGE = `usage: nephew init

  Connect YOUR OWN provider accounts, one at a time (skip any you don't
  use): Modal (token pair — env or your ~/.modal.toml), Steel (API key),
  Browser Use (API key), Browserbase (API key), Bright Data (API token +
  the zone your profile's egress is pinned to). Each is verified with
  one live read-only call.

  Keys are read from your environment only and are never printed or
  stored. ~/.nephew/config.json (mode 0600) records references — which
  env var holds each key, the Bright Data customer id + zone, and whether
  the check passed.

env:
  MODAL_TOKEN_ID / MODAL_TOKEN_SECRET, STEEL_API_KEY,
  BROWSER_USE_API_KEY, BROWSERBASE_API_KEY, BRIGHTDATA_API_KEY
  NEPHEW_CONFIG  config path (default: ~/.nephew/config.json)`;

export const CAPTURE_USAGE = `usage: nephew capture [--name <id>] [--human <who>] [--bundle <dir>] [--sites <url,url>] [--seed <n>]

  Capture a profile in your own local browser: a seeded
  fingerprint-chromium window opens, you log in to your sites normally,
  and on your confirmation the session (cookies + per-origin
  localStorage) is sealed into a NEW encrypted owner-held bundle.

  --name <id>        profile id (default: asked; bundle lands in
                     ~/.nephew/profiles/<id> unless --bundle says otherwise)
  --human <who>      the profile's designated human — the person a paused
                     run routes its LOGIN_REQUIRED handoff to
  --bundle <dir>     bundle directory to create (must not already exist)
  --sites <url,url>  extra origins to capture, beyond the pages you open
  --seed <n>         fingerprint seed (default: freshly drawn per profile)

  Run it in your own terminal: it waits for you to press Enter when your
  logins are done, with the browser window still open. The pinned
  fingerprint-chromium is installed for you on Linux x86_64; on macOS,
  Windows or another CPU, set OWN_STACK_CHROME_PATH to your own build.

env:
  PROFILE_ENCRYPTION_KEY  bundle encryption key (required — yours, never
                     stored with the bundle)
  OWN_STACK_CHROME_PATH   a fingerprint-chromium binary to open instead
                     of the nephew-managed one. By default capture uses
                     ~/.nephew/browsers: on first use it downloads the
                     pinned fingerprint-chromium 150.0.7871.186 release
                     (github.com/adryfish/fingerprint-chromium) there
                     and verifies its sha256 before opening it.`;

export const RECEIPT_USAGE = `usage: nephew receipt verify <file>

  Verify a signed run receipt (issued at run end by receipts.finalizeRun,
  stored under ~/.nephew/receipts/): structure, per-field digests, and the
  owner's Ed25519 signature. Prints PASS, or FAIL naming the field(s)
  that no longer match the signed record.

  exit: 0 PASS · 1 FAIL (tampered, malformed, or unreadable) · 2 usage error`;

export const MCP_USAGE = `usage: nephew mcp

  Run the Nephew MCP server on stdio. One tool:

    profile_run { job, provider: steel|browseruse|modal|browserbase, bundle? }

  Same trust receipt + fingerprint gate as "nephew run". A run whose
  carried login does not hold comes back as a structured LOGIN_REQUIRED
  pause result (not an error), naming the profile's designated human.`;

export const LOGIN_USAGE = `usage: nephew login [key]
       nephew login --forget

  Turn on your BYO plan ($19/mo: 10 profiles, 3 runs at a time) with the
  licence key from your welcome page or the email from Nephew — it looks
  like NPW-BYO-XXXX-XXXX-XXXX-XXXX. The key is checked with nephew.ai once
  and the answer is kept in ~/.nephew/licence.json (mode 0600); later
  commands re-check it quietly about once a day. With no key, the stored
  key is re-checked now; with none stored, you are asked for one. The key
  is never printed.

  Free ($0: 2 profiles, 1 run at a time) needs no key and no login.

  --forget           drop the saved key and go back to Free

  exit: 0 the plan is on (or forgotten) · 1 the key was refused or
        nephew.ai could not be reached · 2 usage error

env:
  NEPHEW_LICENCE     licence file path (default: ~/.nephew/licence.json)
  NEPHEW_BILLING_URL the licence service (default: nephew.ai's)`;

export const PLAN_USAGE = `usage: nephew plan

  Print the plan you're on and its limits — Free (2 profiles, 1 run at a
  time) or BYO (10 profiles plus any extras, 3 runs at a time, with its
  renewal date).
  A BYO answer older than a day is refreshed first when nephew.ai answers;
  when it doesn't, the cached plan stands for up to 7 days.

  More at https://nephew.ai/#pricing`;

export const PROFILES_USAGE = `usage: nephew profiles add [n]
       nephew profiles remove [n]

  More or fewer extra profiles on your BYO plan, $3/mo each, on the same
  subscription. Added ones count from now: the days until your renewal go
  on your next bill, prorated. Removed ones come off it the same way. The
  new limits are saved at once, so the next capture sees them. Up to 90
  extra profiles in all; for more, Enterprise at https://nephew.ai/#pricing

  Free has no extras: get BYO first at https://nephew.ai/#pricing

  exit: 0 changed · 1 refused or nephew.ai could not be reached · 2 usage error`;

export const BRIDGE_USAGE = `usage: nephew bridge

  The Python bridge: a stdio JSON-lines protocol the nephew Python
  package (the with_profile decorator / context manager) drives to hold
  a withProfile session from Python. Not a user surface — humans use
  "nephew run" or the TypeScript helper.

  Same gate, same signed run receipts as every other surface (it is a
  thin shell over src/with-profile.ts). Steel + Browser Use + Browserbase,
  like the TS helper; Modal runs through "nephew run". Protocol:
  src/cli/python-bridge.ts.`;

/** Split "--flag=value" and "--flag value" forms uniformly. */
function flagValue(argv: string[], i: number, flag: string): { value?: string; consumed: number } {
  const a = argv[i];
  if (a === flag) return { value: argv[i + 1], consumed: argv[i + 1] !== undefined ? 2 : 1 };
  if (a.startsWith(flag + "=")) return { value: a.slice(flag.length + 1), consumed: 1 };
  return { consumed: 0 };
}

export function parseCliArgs(argv: string[]): ParseResult {
  const [first, ...rest] = argv;
  if (first === undefined || first === "--help" || first === "-h" || first === "help") {
    return { ok: true, value: { command: "help" } };
  }
  if (first === "revoke") {
    if (rest.includes("--help") || rest.includes("-h")) {
      return { ok: true, value: { command: "help", topic: "revoke" } };
    }
    let bundleDir: string | undefined;
    let receiptFile: string | undefined;
    let keyFile: string | undefined;
    for (let i = 0; i < rest.length; i++) {
      const a = rest[i];
      const target = a === "--bundle" || a.startsWith("--bundle=")
        ? "--bundle"
        : a === "--receipt" || a.startsWith("--receipt=")
          ? "--receipt"
          : a === "--key-file" || a.startsWith("--key-file=")
            ? "--key-file"
            : null;
      if (target) {
        const { value, consumed } = flagValue(rest, i, target);
        i += consumed - 1;
        if (!value) return { ok: false, error: `${target} needs a value` };
        if (target === "--bundle") bundleDir = value;
        else if (target === "--receipt") receiptFile = value;
        else keyFile = value;
      } else {
        return { ok: false, error: `unknown option "${a}" for revoke` };
      }
    }
    return { ok: true, value: { command: "revoke", bundleDir, receiptFile, keyFile } };
  }
  if (first === "receipt") {
    if (rest.includes("--help") || rest.includes("-h")) {
      return { ok: true, value: { command: "help", topic: "receipt" } };
    }
    const [action, file, ...extra] = rest;
    if (action !== "verify") {
      return { ok: false, error: `unknown receipt action "${action ?? ""}" — usage: nephew receipt verify <file>` };
    }
    if (!file) return { ok: false, error: "missing <file> — usage: nephew receipt verify <file>" };
    if (file.startsWith("--")) return { ok: false, error: `unexpected option "${file}" for receipt verify` };
    if (extra.length > 0) return { ok: false, error: `unexpected extra argument "${extra[0]}"` };
    return { ok: true, value: { command: "receipt", action: "verify", file } };
  }
  if (first === "init" || first === "mcp" || first === "bridge" || first === "plan") {
    if (rest.includes("--help") || rest.includes("-h")) {
      return { ok: true, value: { command: "help", topic: first } };
    }
    if (rest.length > 0) return { ok: false, error: `unknown option "${rest[0]}" for ${first}` };
    return { ok: true, value: { command: first } };
  }
  if (first === "profiles") {
    if (rest.includes("--help") || rest.includes("-h")) {
      return { ok: true, value: { command: "help", topic: "profiles" } };
    }
    const [action, n, ...extra] = rest;
    if (action !== "add" && action !== "remove") {
      return { ok: false, error: `unknown profiles action "${action ?? ""}" — usage: nephew profiles add|remove [n]` };
    }
    let count = 1;
    if (n !== undefined) {
      if (!/^\d+$/.test(n) || Number(n) < 1 || Number(n) > MAX_EXTRA_PROFILES) {
        return { ok: false, error: `"${n}" is not a number of profiles from 1 to ${MAX_EXTRA_PROFILES} — usage: nephew profiles ${action} [n]` };
      }
      count = Number(n);
    }
    if (extra.length > 0) return { ok: false, error: `unexpected extra argument "${extra[0]}"` };
    return { ok: true, value: { command: "profiles", action, count } };
  }
  if (first === "login") {
    if (rest.includes("--help") || rest.includes("-h")) {
      return { ok: true, value: { command: "help", topic: "login" } };
    }
    let key: string | undefined;
    let forget = false;
    for (const a of rest) {
      if (a === "--forget") forget = true;
      else if (a.startsWith("--")) return { ok: false, error: `unknown option "${a}" for login` };
      else if (key === undefined) key = a;
      else return { ok: false, error: `unexpected extra argument "${a}"` };
    }
    if (forget && key !== undefined) return { ok: false, error: "--forget takes no key" };
    // No key: the stored one is re-checked, or asked for (cli/plan.ts).
    return { ok: true, value: { command: "login", key, forget } };
  }
  if (first === "capture") {
    if (rest.includes("--help") || rest.includes("-h")) {
      return { ok: true, value: { command: "help", topic: "capture" } };
    }
    let bundleDir: string | undefined;
    let name: string | undefined;
    let human: string | undefined;
    let sites: string[] = [];
    let seed: number | undefined;
    for (let i = 0; i < rest.length; i++) {
      const a = rest[i];
      const target = ["--bundle", "--name", "--human", "--sites", "--seed"].find(
        (f) => a === f || a.startsWith(f + "="),
      );
      if (!target) return { ok: false, error: `unknown option "${a}" for capture` };
      const { value, consumed } = flagValue(rest, i, target);
      i += consumed - 1;
      if (!value) return { ok: false, error: `${target} needs a value` };
      if (target === "--bundle") bundleDir = value;
      else if (target === "--name") name = value;
      else if (target === "--human") human = value;
      else if (target === "--sites") sites = value.split(",").map((s) => s.trim()).filter(Boolean);
      else {
        seed = Number(value);
        if (!Number.isInteger(seed) || seed < 0) return { ok: false, error: `--seed needs a non-negative integer, got "${value}"` };
      }
    }
    return { ok: true, value: { command: "capture", bundleDir, name, human, sites, seed } };
  }
  if (first !== "run") {
    return { ok: false, error: `unknown command "${first}"` };
  }
  if (rest.includes("--help") || rest.includes("-h")) {
    return { ok: true, value: { command: "help", topic: "run" } };
  }

  let job: string | undefined;
  let provider: ProviderName = "steel";
  let dryRun = false;
  let bundleDir: string | undefined;
  let handoff: { ttlMs?: number; port?: number } | undefined;

  for (let i = 0; i < rest.length; i++) {
    const a = rest[i];
    if (a === "--dry-run") {
      dryRun = true;
    } else if (a === "--handoff") {
      handoff ??= {};
    } else if (a === "--handoff-ttl" || a.startsWith("--handoff-ttl=")) {
      const { value, consumed } = flagValue(rest, i, "--handoff-ttl");
      i += consumed - 1;
      const secs = Number(value);
      if (!value || !Number.isInteger(secs) || secs <= 0) {
        return { ok: false, error: `--handoff-ttl needs a positive integer number of seconds, got "${value ?? ""}"` };
      }
      handoff = { ...handoff, ttlMs: secs * 1000 };
    } else if (a === "--handoff-port" || a.startsWith("--handoff-port=")) {
      const { value, consumed } = flagValue(rest, i, "--handoff-port");
      i += consumed - 1;
      const port = Number(value);
      if (!value || !Number.isInteger(port) || port < 0 || port > 65535) {
        return { ok: false, error: `--handoff-port needs a port number 0-65535, got "${value ?? ""}"` };
      }
      handoff = { ...handoff, port };
    } else if (a === "--provider" || a.startsWith("--provider=")) {
      const { value, consumed } = flagValue(rest, i, "--provider");
      i += consumed - 1;
      if (!value) return { ok: false, error: "--provider needs a value (steel|browseruse|modal|browserbase)" };
      if (!(PROVIDERS as readonly string[]).includes(value)) {
        return { ok: false, error: `unknown provider "${value}" (expected steel|browseruse|modal|browserbase)` };
      }
      provider = value as ProviderName;
    } else if (a === "--bundle" || a.startsWith("--bundle=")) {
      const { value, consumed } = flagValue(rest, i, "--bundle");
      i += consumed - 1;
      if (!value) return { ok: false, error: "--bundle needs a directory value" };
      bundleDir = value;
    } else if (a.startsWith("--")) {
      return { ok: false, error: `unknown option "${a}"` };
    } else if (job === undefined) {
      job = a;
    } else {
      return { ok: false, error: `unexpected extra argument "${a}"` };
    }
  }

  if (job === undefined) {
    return { ok: false, error: "missing <job> — usage: nephew run <job> --provider steel|browseruse|modal|browserbase" };
  }
  return { ok: true, value: { command: "run", job, provider, dryRun, bundleDir, ...(handoff ? { handoff } : {}) } };
}

/**
 * The Modal connection gate (CLI v0): Modal is env-supplied only — a token
 * pair, one secret per variable. Returns the single line to print when the
 * connection is absent, or null when both halves are present. Never logs
 * values, only names.
 */
export function modalConnectionProblem(env: NodeJS.ProcessEnv): string | null {
  if (env.MODAL_TOKEN_ID && env.MODAL_TOKEN_SECRET) return null;
  return "modal is not connected — set MODAL_TOKEN_ID and MODAL_TOKEN_SECRET in the environment and retry";
}

/**
 * CLI entry (npm scripts). The shipped CLI is src/nephew.ts; this shim
 * forwards the commands that exist there.
 *   npm run capture                     capture a bundle from a fresh login (test account)
 *   npm run run -- --provider <name>    load bundle, run workload, record metrics
 *   npm run revoke                      destroy the bundle (signed deletion receipt)
 */
const [cmd, ...rest] = process.argv.slice(2);

if (cmd === "capture" || cmd === "run" || cmd === "revoke" || cmd === "init" || cmd === "mcp" || cmd === "receipt") {
  const { main } = await import("./nephew.ts");
  process.exitCode = await main([cmd, ...rest]);
} else {
  console.error("usage: capture | init | run --provider <name> | revoke | mcp | receipt");
  process.exitCode = 1;
}

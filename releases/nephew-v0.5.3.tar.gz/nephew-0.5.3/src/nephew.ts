/**
 * nephew — the one-command CLI for the portable browser profile
 * (decision: ../2026-10-29-nephew-cli-decision.md).
 *
 *   nephew init                                                        connect your own provider accounts
 *   nephew capture [--name <id>] [--human <who>] [--bundle <dir>]      capture a profile in your local browser
 *   nephew run <job> --provider steel|browseruse|modal|browserbase [--dry-run] [--bundle <dir>] [--handoff]
 *   nephew revoke [--bundle <dir>] [--key-file <file>] [--receipt <file>]
 *   nephew receipt verify <file>                                       verify a signed run receipt
 *   nephew login [key] | --forget                                      turn on the BYO plan (no key: re-check the stored one; or go back to Free)
 *   nephew plan                                                        the plan you're on and its limits
 *   nephew mcp                                                         MCP server (stdio): profile_run
 *   nephew bridge                                                      Python bridge (stdio): with_profile sessions for the Python package
 *
 * Happy path asks ZERO questions: bundle defaults resolve from env /
 * the standard location, the trust receipt prints before anything starts,
 * and a fingerprint mismatch refuses the run before the job. Exit codes:
 * 0 ok · 1 run failed / refused · 2 usage error · 3 modal not connected.
 */
import { readFile } from "node:fs/promises";
import { createInterface } from "node:readline";
import { homedir } from "node:os";
import { join } from "node:path";
import { pathToFileURL } from "node:url";
import { loadBundle } from "./profile-store.ts";
import {
  parseCliArgs, modalConnectionProblem, USAGE, RUN_USAGE, REVOKE_USAGE, INIT_USAGE, CAPTURE_USAGE, MCP_USAGE, RECEIPT_USAGE, BRIDGE_USAGE,
  LOGIN_USAGE, PLAN_USAGE, PROFILES_USAGE,
  type RunCommand, type RevokeCommand, type InitCommand, type CaptureCommand, type ReceiptVerifyCommand, type LoginCommand,
} from "./cli/args.ts";
import { verifyRunReceiptFile } from "./receipts/run-receipt.ts";
import { revokeWithReceipt } from "./cli/revoke.ts";
import { formatReceipt, buildRunPlan, planHeader } from "./cli/receipt.ts";
import { runProfileJob, defaultBundleDir } from "./cli/run-core.ts";
import { runInit, type InitDeps } from "./cli/init.ts";
import { runCapture, type CaptureDeps } from "./cli/capture.ts";
import { runLogin, runPlanCommand, runProfilesCommand, type PlanDeps } from "./cli/plan.ts";
import { serveMcpStdio, type McpDeps } from "./mcp/server.ts";
import { servePythonBridgeStdio, type PythonBridgeDeps } from "./cli/python-bridge.ts";

export interface CliIo {
  out: (line: string) => void;
  err: (line: string) => void;
  env: NodeJS.ProcessEnv;
  /** Interactive prompt seam (init/capture). Default: readline on stdio. */
  ask?: (question: string) => Promise<string>;
  /** True once standard input has ended (capture refuses to start then). */
  inputEnded?: () => boolean | Promise<boolean>;
}

/** Test seams for the interactive / server commands. */
export interface MainDeps {
  init?: InitDeps;
  capture?: CaptureDeps;
  mcp?: McpDeps;
  bridge?: PythonBridgeDeps;
  /** Run-core seam (tests) — `nephew run` without a live provider. */
  run?: typeof runProfileJob;
  /** Plan seam (tests) — `nephew login` / `nephew plan` against a fake clock or fetch. */
  plan?: PlanDeps;
}

/**
 * The interactive asker: questions are served from a line queue fed by
 * stdin. A readline question() drops lines that arrive between questions
 * (and never resolves once stdin closes), which silently killed scripted
 * setup — an agent piping answers into `nephew init` got a dead process
 * (exit 13, "unsettled top-level await") at the second question. Here
 * every line is queued in arrival order; when input ends, remaining
 * questions resolve to "" (each prompt's printed default) instead of
 * hanging. A human at a terminal sees identical behaviour.
 */
export interface StdioAsk {
  (question: string): Promise<string>;
  /** True once the input ended (nothing more can be answered). */
  ended(): boolean;
  /**
   * Whether the input ends within `ms`: readline reports EOF
   * asynchronously, so a closed stdin (`< /dev/null`, a tool runner with
   * no input) is only known a tick later. A pipe that stays open (a
   * script feeding answers) is not ended.
   */
  endsSoon(ms?: number): Promise<boolean>;
  /** Release stdin so the process can exit once the command is done. */
  close(): void;
}

export function createStdioAsk(
  input: NodeJS.ReadableStream,
  write: (text: string) => void,
): StdioAsk {
  const queued: string[] = [];
  const waiters: Array<(line: string) => void> = [];
  let ended = false;
  const rl = createInterface({ input });
  rl.on("line", (line) => {
    const waiter = waiters.shift();
    if (waiter) waiter(line);
    else queued.push(line);
  });
  let onEnded: (() => void) | undefined;
  const whenEnded = new Promise<void>((resolve) => { onEnded = resolve; });
  rl.on("close", () => {
    ended = true;
    for (const waiter of waiters.splice(0)) waiter("");
    onEnded?.();
  });
  const ask = (question: string): Promise<string> => {
    write(question);
    if (queued.length > 0) return Promise.resolve(queued.shift()!);
    if (ended) return Promise.resolve("");
    return new Promise((resolve) => waiters.push(resolve));
  };
  const endsSoon = (ms = 150): Promise<boolean> => {
    if (ended) return Promise.resolve(true);
    return new Promise((resolve) => {
      const timer = setTimeout(() => resolve(false), ms);
      whenEnded.then(() => { clearTimeout(timer); resolve(true); });
    });
  };
  return Object.assign(ask, { ended: () => ended, endsSoon, close: () => { rl.close(); } });
}

let sharedAsk: StdioAsk | undefined;
function defaultAsk(question: string): Promise<string> {
  sharedAsk ??= createStdioAsk(process.stdin, (text) => { process.stdout.write(text); });
  return sharedAsk(question);
}
// Capture asks this before opening a browser: with stdin already closed
// nobody could press Enter, and the capture would seal an empty session.
function defaultInputEnded(): Promise<boolean> {
  if (process.stdin.isTTY) return Promise.resolve(false);
  sharedAsk ??= createStdioAsk(process.stdin, (text) => { process.stdout.write(text); });
  return sharedAsk.endsSoon();
}

const defaultIo: CliIo = {
  out: (line) => console.log(line),
  err: (line) => console.error(line),
  env: process.env,
  ask: defaultAsk,
  inputEnded: defaultInputEnded,
};

function firstLine(e: unknown): string {
  return (e instanceof Error ? e.message : String(e)).split("\n")[0];
}

async function runCommand(cmd: RunCommand, io: CliIo, deps: MainDeps = {}): Promise<number> {
  // Modal gate first: one clear line, nothing else, when the pair is absent.
  // A dry run creates no session, so it needs no connection.
  if (cmd.provider === "modal" && !cmd.dryRun) {
    const problem = modalConnectionProblem(io.env);
    if (problem) {
      io.err(problem);
      return 3;
    }
  }

  const bundleDir = cmd.bundleDir ?? defaultBundleDir(io.env);

  if (cmd.dryRun) {
    let bundle;
    try {
      bundle = await loadBundle(bundleDir);
    } catch (e) {
      io.err(`nephew: could not load a bundle at ${bundleDir} — ${firstLine(e)}`);
      return 1;
    }
    // Trust receipt — before anything starts, on every path.
    for (const line of formatReceipt(bundle)) io.out(line);
    const planInput = { job: cmd.job, provider: cmd.provider, bundle, bundleDir, dryRun: cmd.dryRun };
    io.out(planHeader(planInput));
    buildRunPlan(planInput).forEach((step, i) => io.out(`  ${i + 1}. ${step}`));
    return 0;
  }

  const outcome = await (deps.run ?? runProfileJob)(
    {
      job: cmd.job, provider: cmd.provider, bundleDir, env: io.env, log: io.out,
      ...(cmd.handoff ? { handoff: { enabled: true, ttlMs: cmd.handoff.ttlMs, port: cmd.handoff.port } } : {}),
    },
  );
  switch (outcome.kind) {
    case "not-connected":
      io.err(outcome.message);
      return 3;
    case "failed":
      io.err(outcome.message);
      return 1;
    case "plan-limit":
      // The plan's runs-at-a-time slot is taken: one kind line, nothing ran.
      io.err(outcome.message);
      return 1;
    case "refused":
      io.out(`stopped     fingerprint mismatch on: ${outcome.changed.join(", ")} — run refused before the job started`);
      return 1;
    case "login-required": {
      io.out(`✗ failed    state restore did not verify in the ${cmd.provider} session`);
      if (outcome.handoffUnavailable && cmd.handoff) {
        io.out(`handoff     unavailable — ${outcome.handoffUnavailable}; re-capture with \`nephew capture\` instead`);
      }
      if (outcome.handoff && outcome.handoffSession) {
        // The handoff lines (URL, token, deadline) were already printed
        // by run-core as it started; the CLI stays with the pause until
        // the human hands back, ends it, or the deadline expires it.
        io.out(`handoff     waiting — this run is paused until ${outcome.handoff.designatedHuman} hands control back or the deadline passes`);
        const rec = await outcome.handoffSession.waitForOutcome();
        if (rec.outcome === "resumed") {
          io.out(`handoff     resumed by ${rec.designatedHuman} — the fixed login is sealed in the bundle; re-run the job to continue`);
        } else if (rec.outcome === "ended") {
          io.out(`handoff     ended by ${rec.designatedHuman} — nothing was captured back`);
        } else if (rec.outcome === "expired") {
          io.out(`handoff     expired at ${rec.expiresAt} — nothing was captured back; re-capture with \`nephew capture\``);
        } else {
          io.out(`handoff     aborted — nothing was captured back`);
        }
      }
      return 1;
    }
    case "completed":
      io.out(`✓ done      ${cmd.job} · logged in the whole run · 0 prompts · ${(outcome.latencyMs / 1000).toFixed(1)}s in-session`);
      return 0;
  }
}

async function revokeCommand(cmd: RevokeCommand, io: CliIo): Promise<number> {
  const bundleDir = cmd.bundleDir ?? defaultBundleDir(io.env);
  const signingKeyFile = receiptSigningKeyFile(io.env);
  try {
    const { signed, receiptPath } = await revokeWithReceipt({
      bundleDir,
      signingKeyFile,
      keyFile: cmd.keyFile,
      receiptCopyPath: cmd.receiptFile,
    });
    io.out(`revoked     ${signed.receipt.bundleId} · bundle destroyed at ${bundleDir}`);
    for (const copy of signed.receipt.copies) {
      io.out(`destroyed   ${copy.kind} · ${copy.location}`);
    }
    io.out(`receipt     signed deletion receipt: ${cmd.receiptFile ?? receiptPath}`);
    return 0;
  } catch (e) {
    io.err(`nephew: revoke failed — ${firstLine(e)}`);
    return 1;
  }
}

async function initCommand(_cmd: InitCommand, io: CliIo, deps: MainDeps): Promise<number> {
  try {
    const outcome = await runInit(
      { out: io.out, err: io.err, ask: io.ask ?? defaultAsk },
      { env: io.env, ...(deps.init ?? {}) },
    );
    return outcome.code;
  } catch (e) {
    io.err(`nephew: init failed — ${firstLine(e)}`);
    return 1;
  }
}

async function loginCommand(cmd: LoginCommand, io: CliIo, deps: MainDeps): Promise<number> {
  try {
    // cli/plan.ts: the key on the command line, else the stored one, else asked for.
    return await runLogin(
      cmd,
      { out: io.out, err: io.err, ask: io.ask ?? defaultAsk },
      { env: io.env, ...(deps.plan ?? {}) },
    );
  } catch (e) {
    io.err(`nephew: login failed — ${firstLine(e)}`);
    return 1;
  }
}

async function captureCommand(cmd: CaptureCommand, io: CliIo, deps: MainDeps): Promise<number> {
  try {
    await runCapture(cmd, { out: io.out, err: io.err, ask: io.ask ?? defaultAsk, inputEnded: io.inputEnded }, { env: io.env, ...(deps.capture ?? {}) });
    return 0;
  } catch (e) {
    io.err(`nephew: capture failed — ${firstLine(e)}`);
    return 1;
  }
}

function receiptSigningKeyFile(env: NodeJS.ProcessEnv): string {
  return env.NEPHEW_RECEIPT_SIGNING_KEY_FILE ?? join(homedir(), ".nephew", "receipt-signing-key.json");
}

/**
 * A receipt carries the public key it was signed with, so the signature
 * alone only proves "signed by whoever holds that key". On the owner's
 * machine the receipt must be signed by the owner's own key: anyone can
 * mint a receipt with a fresh key, and it must not read PASS here.
 */
async function receiptVerifyCommand(cmd: ReceiptVerifyCommand, io: CliIo): Promise<number> {
  const verdict = await verifyRunReceiptFile(cmd.file);
  if (!verdict.ok) {
    io.out(`FAIL        ${cmd.file} — ${verdict.reason}`);
    return 1;
  }
  let ownerKey: { publicKeySpki?: string } | null = null;
  try { ownerKey = JSON.parse(await readFile(receiptSigningKeyFile(io.env), "utf8")); } catch { ownerKey = null; }
  if (ownerKey?.publicKeySpki) {
    let signer = "";
    try { signer = String(JSON.parse(await readFile(cmd.file, "utf8")).signingPublicKey ?? ""); } catch { /* verifyRunReceiptFile already parsed it */ }
    if (signer !== ownerKey.publicKeySpki) {
      io.out(`FAIL        ${cmd.file} — signed by a key that is not this machine's receipt-signing key (the signature itself is valid)`);
      return 1;
    }
    io.out(`PASS        ${cmd.file} — signature valid, all fields intact, signed by this machine's receipt-signing key`);
    return 0;
  }
  io.out(`PASS        ${cmd.file} — signature valid, all fields intact`);
  io.out(`note        no receipt-signing key on this machine (${receiptSigningKeyFile(io.env)}): the signature was checked against the key the receipt names, not the owner's`);
  return 0;
}

const HELP_TEXT: Record<string, string> = {
  run: RUN_USAGE, revoke: REVOKE_USAGE, init: INIT_USAGE, capture: CAPTURE_USAGE, mcp: MCP_USAGE, receipt: RECEIPT_USAGE, bridge: BRIDGE_USAGE,
  login: LOGIN_USAGE, plan: PLAN_USAGE, profiles: PROFILES_USAGE,
};

export async function main(
  argv: string[] = process.argv.slice(2),
  io: CliIo = defaultIo,
  deps: MainDeps = {},
): Promise<number> {
  const parsed = parseCliArgs(argv);
  if (!parsed.ok) {
    io.err(`nephew: ${parsed.error}`);
    io.err(parsed.error.startsWith("unknown command") ? USAGE : HELP_TEXT[argv[0]] ?? RUN_USAGE);
    return 2;
  }
  if (parsed.value.command === "help") {
    io.out(parsed.value.topic ? HELP_TEXT[parsed.value.topic] : USAGE);
    return 0;
  }
  if (parsed.value.command === "revoke") return revokeCommand(parsed.value, io);
  if (parsed.value.command === "receipt") return receiptVerifyCommand(parsed.value, io);
  if (parsed.value.command === "init") return initCommand(parsed.value, io, deps);
  if (parsed.value.command === "login") return loginCommand(parsed.value, io, deps);
  if (parsed.value.command === "capture") return captureCommand(parsed.value, io, deps);
  if (parsed.value.command === "plan") {
    return runPlanCommand({ out: io.out, err: io.err }, { env: io.env, ...(deps.plan ?? {}) });
  }
  if (parsed.value.command === "profiles") {
    try {
      return await runProfilesCommand(parsed.value, { out: io.out, err: io.err }, { env: io.env, ...(deps.plan ?? {}) });
    } catch (e) {
      io.err(`nephew: profiles failed — ${firstLine(e)}`);
      return 1;
    }
  }
  if (parsed.value.command === "mcp") {
    await serveMcpStdio({ env: io.env, ...(deps.mcp ?? {}) });
    return 0;
  }
  if (parsed.value.command === "bridge") {
    return servePythonBridgeStdio({ env: io.env, ...(deps.bridge ?? {}) });
  }
  return runCommand(parsed.value, io, deps);
}

const isMain = process.argv[1] !== undefined && import.meta.url === pathToFileURL(process.argv[1]).href;
if (isMain) {
  main().then(
    (code) => { process.exitCode = code; },
    (e) => { console.error(`nephew: ${firstLine(e)}`); process.exitCode = 1; },
  ).finally(() => {
    // The readline interface on stdin keeps the process alive at a
    // terminal: an interactive init or capture used to print its last
    // line and then wait for Ctrl-C.
    sharedAsk?.close();
  });
}

/**
 * providers — one adapter per execution environment, one interface.
 *
 * Hard rule (AGENTS.md #2): an adapter must NEVER fall back to a provider's
 * native persistent profile. That would fake the portability proof.
 * Adapters receive the bundle per run and hold nothing between runs.
 *
 * Only own-stack lives behind this interface. The managed providers
 * (steel, browseruse, browserbase, modal) are not adapters here: their
 * sessions are opened by src/cli/run-baseline.ts and src/cli/run-modal.ts
 * through src/cli/provider-api.ts, because their run paths carry the
 * fingerprint gate, capture-back, residue checks, and receipts inline.
 */
import type { ProfileBundle } from "../profile-store.ts";

export interface Session {
  /** CDP websocket endpoint for Playwright connectOverCDP. */
  cdpUrl: string;
  provider: string;
  close(): Promise<void>;
}

export interface ProviderAdapter {
  name: "own-stack";
  start(bundle: ProfileBundle): Promise<Session>;
}

export async function getAdapter(name: ProviderAdapter["name"]): Promise<ProviderAdapter> {
  switch (name) {
    case "own-stack":
      return (await import("./own-stack.ts")).ownStackAdapter;
  }
}

/**
 * cli/chrome — where capture's fingerprint-chromium comes from.
 *
 * v0.4.0 required OWN_STACK_CHROME_PATH and nothing installed the
 * binary, so an outside user's first capture died at configuration.
 * The fix is an acquisition path with the same pinning discipline as
 * the Modal image (tools/modal_bridge.py): the pinned
 * fingerprint-chromium release, downloaded on first use into the
 * user's own ~/.nephew/browsers, sha256-verified twice — the release
 * tarball against the pin below, then the extracted `chrome` binary
 * against the build this project measured (docs/SPIKE_RESULTS.md) —
 * before it is ever opened.
 *
 * Resolution order:
 *   1. OWN_STACK_CHROME_PATH / NEPHEW_CHROME_PATH (the user's own
 *      binary always wins, trusted as-is, exactly as before).
 *   2. The nephew-managed install at ~/.nephew/browsers.
 *   3. First-run download of the pinned release (Linux x86_64 — the
 *      platform the pinned build is proven on). Other platforms get
 *      the instruction, not a path error.
 *
 * The download lands inside ~/.nephew (never /tmp: a small tmpfs
 * would fill mid-download) and is staged + verified before an atomic
 * rename into place, so an interrupted fetch leaves nothing usable
 * behind.
 */
import { createHash } from "node:crypto";
import { execFile } from "node:child_process";
import { createReadStream, createWriteStream } from "node:fs";
import { chmod, mkdir, rename, rm, stat } from "node:fs/promises";
import { homedir } from "node:os";
import { join } from "node:path";
import { Readable } from "node:stream";
import { pipeline } from "node:stream/promises";
import { promisify } from "node:util";

const execFileP = promisify(execFile);

export const FINGERPRINT_CHROMIUM_VERSION = "150.0.7871.186";
export const FINGERPRINT_CHROMIUM_TARBALL =
  `ungoogled-chromium-${FINGERPRINT_CHROMIUM_VERSION}-1-x86_64_linux.tar.xz`;
export const FINGERPRINT_CHROMIUM_URL =
  `https://github.com/adryfish/fingerprint-chromium/releases/download/` +
  `${FINGERPRINT_CHROMIUM_VERSION}/${FINGERPRINT_CHROMIUM_TARBALL}`;
/** sha256 of the release tarball, measured at the v0.4.1 build (2026-10-31). */
export const FINGERPRINT_CHROMIUM_TARBALL_SHA256 =
  "48eff860053efd9ad498d51370f0a1f59f983df39c02a72ad2a8682cdead4055";
/** sha256 of the extracted `chrome` binary — the measured pinned build. */
export const FINGERPRINT_CHROMIUM_BINARY_SHA256 =
  "ada6fa284fa1e4cbc6279c63fcf8fa1068d7df0e337ef4889314da1f0fbfc9ae";

export interface CaptureChrome {
  path: string;
  source: "env" | "managed" | "downloaded";
  /** One human line: which browser this is and where it came from. */
  detail: string;
}

export interface ChromeDeps {
  env?: NodeJS.ProcessEnv;
  home?: string;
  platform?: NodeJS.Platform;
  arch?: string;
  log?: (line: string) => void;
  /** Test seams — production callers use the real network/tar/hashes. */
  download?: (url: string, dest: string) => Promise<void>;
  extract?: (tarball: string, destDir: string) => Promise<void>;
  expectedHashes?: { tarball: string; binary: string };
}

export function managedBrowsersRoot(home: string): string {
  return join(home, ".nephew", "browsers");
}

export function managedChromeDir(home: string): string {
  return join(managedBrowsersRoot(home), `fingerprint-chromium-${FINGERPRINT_CHROMIUM_VERSION}`);
}

export function managedChromePath(home: string): string {
  return join(managedChromeDir(home), "chrome");
}

async function exists(p: string): Promise<boolean> {
  try { await stat(p); return true; } catch { return false; }
}

export async function sha256File(path: string): Promise<string> {
  const hash = createHash("sha256");
  await pipeline(createReadStream(path), hash);
  return hash.digest("hex");
}

async function defaultDownload(url: string, dest: string): Promise<void> {
  const res = await fetch(url);
  if (!res.ok || !res.body) {
    throw new Error(`download of the fingerprint-chromium release failed (HTTP ${res.status})`);
  }
  await pipeline(Readable.fromWeb(res.body as any), createWriteStream(dest));
}

async function defaultExtract(tarball: string, destDir: string): Promise<void> {
  await mkdir(destDir, { recursive: true });
  await execFileP("tar", ["-xJf", tarball, "-C", destDir, "--strip-components=1", "--no-same-owner"], {
    timeout: 600_000,
  });
}

/**
 * Resolve the browser capture opens, installing the pinned build on
 * first use. See the module header for the order and the guarantees.
 */
export async function resolveCaptureChrome(deps: ChromeDeps = {}): Promise<CaptureChrome> {
  const env = deps.env ?? process.env;
  const home = deps.home ?? homedir();
  const log = deps.log ?? (() => {});

  const fromEnv = env.OWN_STACK_CHROME_PATH ?? env.NEPHEW_CHROME_PATH;
  if (fromEnv) {
    return {
      path: fromEnv,
      source: "env",
      detail: `fingerprint-chromium from ${env.OWN_STACK_CHROME_PATH ? "OWN_STACK_CHROME_PATH" : "NEPHEW_CHROME_PATH"} (${fromEnv})`,
    };
  }

  const managed = managedChromePath(home);
  const expected = deps.expectedHashes ?? {
    tarball: FINGERPRINT_CHROMIUM_TARBALL_SHA256,
    binary: FINGERPRINT_CHROMIUM_BINARY_SHA256,
  };
  if (await exists(managed)) {
    if (await sha256File(managed) !== expected.binary) throw new Error("The installed capture browser failed sha256 verification; refusing to launch it. Remove this managed browser install and retry to download the pinned release.");
    return {
      path: managed,
      source: "managed",
      detail: `fingerprint-chromium ${FINGERPRINT_CHROMIUM_VERSION} (nephew-managed, ${managed})`,
    };
  }

  const platform = deps.platform ?? process.platform;
  const arch = deps.arch ?? process.arch;
  if (platform !== "linux" || arch !== "x64") {
    throw new Error(
      `no capture browser is installed and the pinned fingerprint-chromium ${FINGERPRINT_CHROMIUM_VERSION} ` +
      `auto-install covers Linux x86_64 (this machine is ${platform}/${arch}) — install fingerprint-chromium ` +
      `${FINGERPRINT_CHROMIUM_VERSION} from github.com/adryfish/fingerprint-chromium and set ` +
      `OWN_STACK_CHROME_PATH to its chrome binary`,
    );
  }

  const root = managedBrowsersRoot(home);
  const staging = join(root, `.staging-${process.pid}`);
  const tarballPath = join(staging, FINGERPRINT_CHROMIUM_TARBALL);
  const extractDir = join(staging, "x");
  await rm(staging, { recursive: true, force: true });
  await mkdir(staging, { recursive: true });
  try {
    log(`browser     downloading fingerprint-chromium ${FINGERPRINT_CHROMIUM_VERSION} (pinned release)`);
    log(`            from ${FINGERPRINT_CHROMIUM_URL}`);
    await (deps.download ?? defaultDownload)(FINGERPRINT_CHROMIUM_URL, tarballPath);
    const tarballHash = await sha256File(tarballPath);
    if (tarballHash !== expected.tarball) {
      throw new Error(
        `the downloaded fingerprint-chromium tarball failed sha256 verification ` +
        `(expected ${expected.tarball}, got ${tarballHash}) — refusing to use it`,
      );
    }
    await (deps.extract ?? defaultExtract)(tarballPath, extractDir);
    const chromePath = join(extractDir, "chrome");
    if (!(await exists(chromePath))) {
      throw new Error("the fingerprint-chromium tarball did not contain a chrome binary where expected");
    }
    const binaryHash = await sha256File(chromePath);
    if (binaryHash !== expected.binary) {
      throw new Error(
        `the extracted chrome binary is not the pinned build ` +
        `(expected sha256 ${expected.binary}, got ${binaryHash}) — refusing to use it`,
      );
    }
    await chmod(chromePath, 0o755);
    if (await exists(managedChromeDir(home))) {
      // Another capture installed it while we downloaded — keep theirs.
      if (await sha256File(managed) !== expected.binary) throw new Error("The concurrently installed capture browser failed sha256 verification");
      await rm(staging, { recursive: true, force: true });
    } else {
      await rename(extractDir, managedChromeDir(home));
      await rm(staging, { recursive: true, force: true });
    }
    log(`            sha256 verified (tarball + chrome binary) — installed at ${managed}`);
    return {
      path: managed,
      source: "downloaded",
      detail: `fingerprint-chromium ${FINGERPRINT_CHROMIUM_VERSION} (downloaded + sha256-verified, ${managed})`,
    };
  } catch (e) {
    await rm(staging, { recursive: true, force: true });
    throw e;
  }
}

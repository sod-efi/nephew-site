/**
 * cli/plan — plans and their limits: `nephew login`, `nephew plan`, and the
 * gates the limits are enforced at (new profiles in capture; runs at a
 * time in run-core AND in openProfileSession — src/with-profile.ts, the
 * entry behind the TS helper and the Python bridge, which mirrors
 * run-core's lock + rank semantics exactly so every surface counts
 * every other surface's runs).
 *
 * Two plans. Free ($0) needs no key: 2 profiles, 1 run at a time. BYO
 * ($19/mo, plus extra profiles at $3/mo each through `nephew profiles
 * add|remove`, which the service puts on the same subscription and answers
 * with the new limits) comes with a licence key (NPW-BYO-XXXX-XXXX-XXXX-XXXX) from the
 * welcome page / email; `nephew login <key>` checks it with the billing
 * service and caches the answer in ~/.nephew/licence.json (mode 0600, the
 * house pattern for anything under ~/.nephew; path override NEPHEW_LICENCE
 * like NEPHEW_CONFIG). Free never calls the service — no licence file, no
 * network, exactly the CLI as it was.
 *
 * Refresh rules (currentPlan): a cached BYO answer is trusted for 24 hours;
 * older than that, one check per command, silently on network failure and
 * never slower than the 8 s timeout. 200 refreshes the file; 402/404 mean
 * the plan is off — the file goes and the person is told once (the
 * returned `note`). When the service has been unreachable and the last
 * good check is older than 7 days, the CLI runs as Free with a note until
 * nephew.ai answers again.
 *
 * Runs at a time are counted with one lock file per live run under
 * ~/.nephew/runs/locks/ — its own folder beside the run records and the
 * handoffs/ records in the runs dir (NEPHEW_RUNS_DIR moves all of it), so
 * sweeping dead locks can never touch a record: pid + startedAt + bundle
 * dir, written whole (temp file + rename) so a racing reader never sees a
 * half lock. A lock is dead when its pid is gone, it is older than 24 h, or it
 * predates this boot (a reused pid after a reboot is not that run); a run
 * removes its own lock on exit, including SIGINT/SIGTERM and errors.
 * Admission is by rank, not by count: the live locks sorted by (startedAt,
 * path) are the queue, and a run proceeds when its own lock sits within
 * the plan's slots — two runs starting in the same instant agree on
 * exactly which one runs instead of both being refused.
 *
 * Nothing here ever prints or stores more than the key itself (which the
 * person already holds) — no payment details, no account identity.
 */
import { randomBytes } from "node:crypto";
import { unlinkSync } from "node:fs";
import { chmod, mkdir, readFile, readdir, rename, rm, stat, unlink, writeFile } from "node:fs/promises";
import { protectPrivatePath, writePrivateFile } from "../private-files.ts";
import { createRequire } from "node:module";
import { homedir, uptime } from "node:os";
import { dirname, join, resolve } from "node:path";
import { defaultRunsDir } from "../measure.ts";
import { MAX_EXTRA_PROFILES, type LoginCommand, type ProfilesCommand } from "./args.ts";

export type PlanName = "free" | "byo";

export interface PlanLimits {
  profiles: number;
  runs: number;
}

export const FREE_LIMITS: PlanLimits = { profiles: 2, runs: 1 };
export const BYO_LIMITS: PlanLimits = { profiles: 10, runs: 3 };
export const PRICING_URL = "https://nephew.ai/#pricing";
export const DEFAULT_BILLING_URL = "https://nephew-billing-production.up.railway.app";
export const LICENCE_CHECK_TIMEOUT_MS = 8_000;
/** A cached BYO answer is trusted this long before the service is asked again. */
export const REFRESH_AFTER_MS = 24 * 60 * 60 * 1000;
/** Unreachable for longer than this since the last good check → run as Free. */
export const CONFIRM_WITHIN_MS = 7 * 24 * 60 * 60 * 1000;
/** A run lock older than this is dead whatever its pid says. */
export const LOCK_STALE_MS = 24 * 60 * 60 * 1000;
/** An unreadable lock younger than this may still be being written; leave it alone. */
export const UNREADABLE_GRACE_MS = 5_000;
/** How far before this boot a lock may be stamped and still count as this boot (uptime is coarse). */
export const BOOT_TOLERANCE_MS = 5_000;
/** The line when the service answered in a shape this CLI does not know. */
export const UPDATE_LINE = "nephew.ai didn't understand this version of Nephew. Update it: curl -fsSL https://nephew.ai/install | sh";

export interface CurrentPlan {
  plan: PlanName;
  limits: PlanLimits;
  /** Extra BYO profiles on the subscription (inside limits.profiles already). */
  extraProfiles?: number;
  /** What one extra profile costs a month, in cents, as the service last said. */
  extraMonthlyCents?: number;
  /** ISO date the BYO plan renews, when the service said so. */
  renewsAt?: string | null;
  /** Said once: why the plan just changed, or why BYO could not be confirmed. */
  note?: string;
}

const FREE: CurrentPlan = { plan: "free", limits: FREE_LIMITS };

// ------------------------------------------------------------ paths + env

export function licencePath(env: NodeJS.ProcessEnv = process.env): string {
  return env.NEPHEW_LICENCE ?? join(homedir(), ".nephew", "licence.json");
}

/** Where live-run locks live: <runs dir>/locks (~/.nephew/runs/locks, or under NEPHEW_RUNS_DIR). */
export function runLocksDir(env: NodeJS.ProcessEnv = process.env): string {
  return join(defaultRunsDir(env), "locks");
}

export function billingBaseUrl(env: NodeJS.ProcessEnv = process.env): string {
  return (env.NEPHEW_BILLING_URL ?? DEFAULT_BILLING_URL).replace(/\/+$/, "");
}

/** Where named profiles live — the parent of the default bundle dir. */
export function defaultProfilesRoot(): string {
  return join(homedir(), ".nephew", "profiles");
}

let cliVersionCache: string | undefined;
/** The CLI version the service is told about (package.json; "unknown" when unreadable). */
export function cliVersion(): string {
  if (cliVersionCache === undefined) {
    try {
      cliVersionCache = String((createRequire(import.meta.url)("../../package.json") as { version?: string }).version ?? "unknown");
    } catch {
      cliVersionCache = "unknown";
    }
  }
  return cliVersionCache;
}

// --------------------------------------------------------------- the key

const KEY_RE = /^NPW-BYO-[A-Z0-9]{4}-[A-Z0-9]{4}-[A-Z0-9]{4}-[A-Z0-9]{4}$/;

/** Trim, uppercase, and accept the key typed with spaces instead of dashes. */
export function normaliseLicenceKey(raw: string): string {
  return raw.trim().toUpperCase().replace(/\s+/g, "-");
}

/** The one line to print when a key cannot be a Nephew key, or null when its shape is right. */
export function licenceKeyProblem(key: string): string | null {
  if (KEY_RE.test(key)) return null;
  return "That doesn't look like a Nephew key. Keys look like NPW-BYO-XXXX-XXXX-XXXX-XXXX (letters and digits). Check the email from Nephew or your welcome page.";
}

// ------------------------------------------------------- the licence file

export interface LicenceFile {
  key: string;
  plan: "byo";
  status: string;
  limits: PlanLimits;
  /** Extra profiles on the subscription (inside limits.profiles already). */
  extraProfiles?: number;
  /** Cents a month for one extra profile, as the service last said. */
  extraMonthlyCents?: number;
  renewsAt: string | null;
  /** ISO time of the last answer from the service (200). */
  checkedAt: string;
}

function parseLimits(raw: unknown): PlanLimits | null {
  const l = raw as { profiles?: unknown; runs?: unknown } | null;
  if (!l || typeof l !== "object") return null;
  const profiles = Number(l.profiles);
  const runs = Number(l.runs);
  if (!Number.isInteger(profiles) || profiles < 0 || !Number.isInteger(runs) || runs < 0) return null;
  return { profiles, runs };
}

/** A non-negative integer from the service, or undefined when absent or odd. */
function parseCount(raw: unknown): number | undefined {
  const n = Number(raw);
  return raw !== undefined && raw !== null && Number.isInteger(n) && n >= 0 ? n : undefined;
}

export const DEFAULT_EXTRA_MONTHLY_CENTS = 300;

/** "$3" / "$2.50" from cents. */
export function dollars(cents: number): string {
  return `$${(cents / 100).toFixed(cents % 100 ? 2 : 0)}`;
}

export async function loadLicence(path: string): Promise<LicenceFile | null> {
  try {
    await protectPrivatePath(path);
    const parsed = JSON.parse(await readFile(path, "utf8")) as Partial<LicenceFile> | null;
    if (!parsed || parsed.plan !== "byo" || typeof parsed.key !== "string" || typeof parsed.checkedAt !== "string") return null;
    const limits = parseLimits(parsed.limits) ?? BYO_LIMITS;
    const extraProfiles = parseCount(parsed.extraProfiles);
    const extraMonthlyCents = parseCount(parsed.extraMonthlyCents);
    return {
      key: parsed.key,
      plan: "byo",
      status: typeof parsed.status === "string" ? parsed.status : "active",
      limits,
      ...(extraProfiles !== undefined ? { extraProfiles } : {}),
      ...(extraMonthlyCents !== undefined ? { extraMonthlyCents } : {}),
      renewsAt: typeof parsed.renewsAt === "string" ? parsed.renewsAt : null,
      checkedAt: parsed.checkedAt,
    };
  } catch {
    return null;
  }
}

/** Write the licence mode 0600 — including tightening a pre-existing looser file. */
export async function saveLicence(path: string, licence: LicenceFile): Promise<void> {
  await writePrivateFile(path, JSON.stringify(licence, null, 2) + "\n");
}

export async function forgetLicence(path: string): Promise<void> {
  await rm(path, { force: true });
}

// ------------------------------------------------------ the service call

type FetchFn = (
  url: string,
  init?: { method?: string; headers?: Record<string, string>; body?: string; signal?: AbortSignal },
) => Promise<{ status: number; text: () => Promise<string> }>;

export type LicenceCheck =
  | { kind: "active"; status: string; limits: PlanLimits; renewsAt: string | null; extraProfiles?: number; extraMonthlyCents?: number }
  | { kind: "inactive"; status: string; limits: PlanLimits }
  | { kind: "unknown-key" }
  | { kind: "try-later" }
  | { kind: "unreachable" }
  /** The service answered, but not in a shape this CLI knows (an old CLI, most likely). */
  | { kind: "incompatible" };

export interface PlanDeps {
  env?: NodeJS.ProcessEnv;
  /** Clock seam (tests). */
  now?: () => Date;
  /** HTTP seam (tests); default: global fetch. */
  fetchFn?: FetchFn;
  /** Service timeout, ms (default 8 s). */
  timeoutMs?: number;
  /** CLI version sent to the service (default: package.json). */
  cliVersion?: string;
}

/**
 * POST /licence/check. Never throws: every way the service can answer —
 * or fail to — is one of the six kinds above. Response bodies beyond
 * the documented fields are not kept.
 */
export async function checkLicenceKey(key: string, deps: PlanDeps = {}): Promise<LicenceCheck> {
  const env = deps.env ?? process.env;
  const fetchFn = deps.fetchFn ?? (fetch as unknown as FetchFn);
  let res: { status: number; text: () => Promise<string> };
  try {
    res = await fetchFn(`${billingBaseUrl(env)}/licence/check`, {
      method: "POST",
      headers: { "Content-Type": "application/json", Accept: "application/json" },
      body: JSON.stringify({ key, cli: deps.cliVersion ?? cliVersion() }),
      signal: AbortSignal.timeout(deps.timeoutMs ?? LICENCE_CHECK_TIMEOUT_MS),
    });
  } catch {
    return { kind: "unreachable" };
  }
  if (res.status === 429) return { kind: "try-later" };
  if (res.status >= 500) return { kind: "unreachable" };
  let body: { ok?: unknown; status?: unknown; limits?: unknown; renewsAt?: unknown; extraProfiles?: unknown; extraMonthlyCents?: unknown } = {};
  try {
    body = JSON.parse(await res.text()) ?? {};
  } catch {
    body = {};
  }
  if (res.status === 200 && body.ok === true) {
    const extraProfiles = parseCount(body.extraProfiles);
    const extraMonthlyCents = parseCount(body.extraMonthlyCents);
    return {
      kind: "active",
      status: typeof body.status === "string" ? body.status : "active",
      limits: parseLimits(body.limits) ?? BYO_LIMITS,
      renewsAt: typeof body.renewsAt === "string" ? body.renewsAt : null,
      ...(extraProfiles !== undefined ? { extraProfiles } : {}),
      ...(extraMonthlyCents !== undefined ? { extraMonthlyCents } : {}),
    };
  }
  if (res.status === 402) {
    return {
      kind: "inactive",
      status: typeof body.status === "string" ? body.status : "inactive",
      limits: parseLimits(body.limits) ?? FREE_LIMITS,
    };
  }
  if (res.status === 404) return { kind: "unknown-key" };
  // The service answered (a 200 with a body we don't know, 400/401/403,
  // any other status): the request shape is the problem, not the network.
  return { kind: "incompatible" };
}

// ------------------------------------------------------------- wording

/** "10 profiles, 3 runs at a time" / "2 profiles, 1 run at a time". */
export function limitsPhrase(limits: PlanLimits): string {
  return `${limits.profiles} profile${limits.profiles === 1 ? "" : "s"}, ${limits.runs} run${limits.runs === 1 ? "" : "s"} at a time`;
}

/**
 * The BYO line's limits: "12 profiles (2 extra at $3/mo each), 3 runs at a
 * time" when there are extras, else the plain phrase.
 */
export function byoPhrase(limits: PlanLimits, extraProfiles?: number, extraMonthlyCents?: number): string {
  if (!extraProfiles) return limitsPhrase(limits);
  const each = dollars(extraMonthlyCents ?? DEFAULT_EXTRA_MONTHLY_CENTS);
  return `${limits.profiles} profiles (${extraProfiles} extra at ${each}/mo each), ${limits.runs} run${limits.runs === 1 ? "" : "s"} at a time`;
}

export function planLabel(plan: PlanName): string {
  return plan === "byo" ? "BYO" : "Free";
}

const MONTHS = ["Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"];

/** "Dec 1" from an ISO date (UTC), or null when the date is unknown or unreadable. */
export function formatRenewal(iso: string | null | undefined): string | null {
  if (!iso) return null;
  const t = Date.parse(iso);
  if (!Number.isFinite(t)) return null;
  const d = new Date(t);
  return `${MONTHS[d.getUTCMonth()]} ${d.getUTCDate()}`;
}

function statusWords(status: string): string {
  return status.replace(/_/g, " ");
}

function inactiveLine(status: string, limits: PlanLimits): string {
  return `That plan is ${statusWords(status)}, so you're on Free: ${limitsPhrase(limits)}. Reactivate at ${PRICING_URL}`;
}

// --------------------------------------------------------- currentPlan

/**
 * The plan the CLI runs under right now. Free when there is no licence
 * file (no service call, ever). Otherwise the cached BYO limits, refreshed
 * by the rules in the header; `note` carries the one-time explanation
 * when the answer moved the person to Free.
 */
export async function currentPlan(deps: PlanDeps = {}): Promise<CurrentPlan> {
  const env = deps.env ?? process.env;
  const now = (deps.now ?? (() => new Date()))();
  const path = licencePath(env);
  const licence = await loadLicence(path);
  if (!licence) return FREE;
  // Only the extras the service actually named: an answer without them adds no keys.
  const extras = (src: { extraProfiles?: number; extraMonthlyCents?: number }): Pick<CurrentPlan, "extraProfiles" | "extraMonthlyCents"> => ({
    ...(src.extraProfiles !== undefined ? { extraProfiles: src.extraProfiles } : {}),
    ...(src.extraMonthlyCents !== undefined ? { extraMonthlyCents: src.extraMonthlyCents } : {}),
  });

  const cached: CurrentPlan = { plan: "byo", limits: licence.limits, renewsAt: licence.renewsAt, ...extras(licence) };
  const age = now.getTime() - Date.parse(licence.checkedAt);
  if (Number.isFinite(age) && age >= 0 && age < REFRESH_AFTER_MS) return cached;

  const check = await checkLicenceKey(licence.key, { ...deps, env });
  switch (check.kind) {
    case "active":
      await saveLicence(path, {
        key: licence.key, plan: "byo", status: check.status, limits: check.limits,
        ...(check.extraProfiles !== undefined ? { extraProfiles: check.extraProfiles } : {}),
        ...(check.extraMonthlyCents !== undefined ? { extraMonthlyCents: check.extraMonthlyCents } : {}),
        renewsAt: check.renewsAt, checkedAt: now.toISOString(),
      });
      return { plan: "byo", limits: check.limits, renewsAt: check.renewsAt, ...extras(check) };
    case "inactive":
      await forgetLicence(path);
      return { ...FREE, note: inactiveLine(check.status, check.limits) };
    case "unknown-key":
      await forgetLicence(path);
      return {
        ...FREE,
        note: `That key isn't recognised any more, so you're on Free: ${limitsPhrase(FREE_LIMITS)}. Check the email from Nephew or your welcome page.`,
      };
    case "try-later":
    case "unreachable":
      if (!Number.isFinite(age) || age >= CONFIRM_WITHIN_MS) {
        return { ...FREE, note: "Couldn't confirm your BYO plan for 7 days; running as Free until nephew.ai answers." };
      }
      return cached;
    case "incompatible":
      // The service is up but this CLI no longer speaks its language: the
      // cached plan stands for the same 7 days, and the way out is an update.
      if (!Number.isFinite(age) || age >= CONFIRM_WITHIN_MS) return { ...FREE, note: UPDATE_LINE };
      return cached;
  }
}

// ------------------------------------------------- login + plan commands

export interface PlanIo {
  out: (line: string) => void;
  err: (line: string) => void;
  /** Prompt seam: `nephew login` with no key and none stored asks for one. */
  ask?: (question: string) => Promise<string>;
}

/**
 * `nephew login [key]` / `nephew login --forget`. The key: the one on the
 * command line, else the stored one (re-checked now, without asking),
 * else asked for. Exit 0 on success, 1 when refused or unreachable, 2
 * when there is no key anywhere. The key is never printed.
 */
export async function runLogin(cmd: LoginCommand, io: PlanIo, deps: PlanDeps = {}): Promise<number> {
  const env = deps.env ?? process.env;
  const path = licencePath(env);
  if (cmd.forget) {
    await forgetLicence(path);
    io.out(`You're on Free: ${limitsPhrase(FREE_LIMITS)}.`);
    return 0;
  }
  let raw = cmd.key?.trim() ?? "";
  if (!raw) raw = (await loadLicence(path))?.key ?? "";
  if (!raw && io.ask) raw = (await io.ask("Licence key: ")).trim();
  if (!raw) {
    io.err("nephew: no licence key given — usage: nephew login <key> (or nephew login --forget)");
    return 2;
  }
  const key = normaliseLicenceKey(raw);
  const shape = licenceKeyProblem(key);
  if (shape) {
    io.err(shape);
    return 1;
  }
  const now = (deps.now ?? (() => new Date()))();
  const check = await checkLicenceKey(key, { ...deps, env });
  switch (check.kind) {
    case "active": {
      await saveLicence(path, {
        key, plan: "byo", status: check.status, limits: check.limits,
        ...(check.extraProfiles !== undefined ? { extraProfiles: check.extraProfiles } : {}),
        ...(check.extraMonthlyCents !== undefined ? { extraMonthlyCents: check.extraMonthlyCents } : {}),
        renewsAt: check.renewsAt, checkedAt: now.toISOString(),
      });
      const renews = formatRenewal(check.renewsAt);
      io.out(`You're on BYO: ${byoPhrase(check.limits, check.extraProfiles, check.extraMonthlyCents)}.${renews ? ` Renews ${renews}.` : ""}`);
      return 0;
    }
    case "inactive": {
      // The key exists but the plan is off: nothing is saved, and a cached
      // copy of this same key stops claiming BYO.
      const existing = await loadLicence(path);
      if (existing?.key === key) await forgetLicence(path);
      io.err(inactiveLine(check.status, check.limits));
      return 1;
    }
    case "unknown-key":
      io.err("That key isn't recognised. Check the email from Nephew or your welcome page.");
      return 1;
    case "try-later":
      io.err("nephew.ai is busy right now. Try again in a minute.");
      return 1;
    case "unreachable":
      io.err("Couldn't reach nephew.ai to check the key. Try again in a minute.");
      return 1;
    case "incompatible":
      io.err(UPDATE_LINE);
      return 1;
  }
}

/** One line for the plan the CLI is running under. */
export function describePlan(current: CurrentPlan): string {
  if (current.plan === "byo") {
    const renews = formatRenewal(current.renewsAt);
    return `BYO: ${byoPhrase(current.limits, current.extraProfiles, current.extraMonthlyCents)}.${renews ? ` Renews ${renews}.` : ""}`;
  }
  return `Free: ${limitsPhrase(current.limits)}. More at ${PRICING_URL}`;
}

/** `nephew plan`: the current plan from the cache, refreshed first when it is stale. */
export async function runPlanCommand(io: PlanIo, deps: PlanDeps = {}): Promise<number> {
  const current = await currentPlan(deps);
  if (current.note) io.out(current.note);
  io.out(describePlan(current));
  return 0;
}

// ------------------------------------------------ extra profiles (BYO)

export type ProfilesChange =
  | { kind: "ok"; extraProfiles: number; limits: PlanLimits; monthlyCents: number; extraMonthlyCents: number; renewsAt: string | null }
  | { kind: "too-few"; extraProfiles: number }
  | { kind: "too-many"; extraProfiles: number; max: number }
  /** The service's Stripe key cannot change subscriptions yet. */
  | { kind: "closed" }
  | { kind: "inactive"; status: string; limits: PlanLimits }
  | { kind: "unknown-key" }
  | { kind: "try-later" }
  | { kind: "unreachable" }
  | { kind: "incompatible" };

/** POST /profiles {key, change}. Never throws. */
export async function changeExtraProfiles(key: string, change: number, deps: PlanDeps = {}): Promise<ProfilesChange> {
  const env = deps.env ?? process.env;
  const fetchFn = deps.fetchFn ?? (fetch as unknown as FetchFn);
  let res: { status: number; text: () => Promise<string> };
  try {
    res = await fetchFn(`${billingBaseUrl(env)}/profiles`, {
      method: "POST",
      headers: { "Content-Type": "application/json", Accept: "application/json" },
      body: JSON.stringify({ key, change, cli: deps.cliVersion ?? cliVersion() }),
      signal: AbortSignal.timeout(deps.timeoutMs ?? LICENCE_CHECK_TIMEOUT_MS),
    });
  } catch {
    return { kind: "unreachable" };
  }
  if (res.status === 429) return { kind: "try-later" };
  let body: { ok?: unknown; error?: unknown; status?: unknown; limits?: unknown; renewsAt?: unknown; extraProfiles?: unknown; extraMonthlyCents?: unknown; monthlyCents?: unknown; max?: unknown } = {};
  try {
    body = JSON.parse(await res.text()) ?? {};
  } catch {
    body = {};
  }
  if (res.status === 503 && body.error === "closed") return { kind: "closed" };
  if (res.status >= 500) return { kind: "unreachable" };
  if (res.status === 200 && body.ok === true) {
    const limits = parseLimits(body.limits);
    const extraProfiles = parseCount(body.extraProfiles);
    const monthlyCents = parseCount(body.monthlyCents);
    if (!limits || extraProfiles === undefined || monthlyCents === undefined) return { kind: "incompatible" };
    return {
      kind: "ok", extraProfiles, limits, monthlyCents,
      extraMonthlyCents: parseCount(body.extraMonthlyCents) ?? DEFAULT_EXTRA_MONTHLY_CENTS,
      renewsAt: typeof body.renewsAt === "string" ? body.renewsAt : null,
    };
  }
  if (res.status === 400 && body.error === "too_few") return { kind: "too-few", extraProfiles: parseCount(body.extraProfiles) ?? 0 };
  if (res.status === 400 && body.error === "too_many") return { kind: "too-many", extraProfiles: parseCount(body.extraProfiles) ?? 0, max: parseCount(body.max) ?? MAX_EXTRA_PROFILES };
  if (res.status === 402) {
    return { kind: "inactive", status: typeof body.status === "string" ? body.status : "inactive", limits: parseLimits(body.limits) ?? FREE_LIMITS };
  }
  if (res.status === 404) return { kind: "unknown-key" };
  return { kind: "incompatible" };
}

/**
 * `nephew profiles add|remove [n]`. BYO only (Free has no extras). On
 * success the licence file gets the new limits at once, so the next
 * capture counts them. Exit 0 changed, 1 refused or unreachable.
 */
export async function runProfilesCommand(cmd: ProfilesCommand, io: PlanIo, deps: PlanDeps = {}): Promise<number> {
  const env = deps.env ?? process.env;
  const path = licencePath(env);
  const licence = await loadLicence(path);
  if (!licence) {
    io.err(`Extra profiles come with BYO. You're on Free: ${limitsPhrase(FREE_LIMITS)}. Get BYO at ${PRICING_URL}`);
    return 1;
  }
  const change = cmd.action === "add" ? cmd.count : -cmd.count;
  const now = (deps.now ?? (() => new Date()))();
  const result = await changeExtraProfiles(licence.key, change, { ...deps, env });
  switch (result.kind) {
    case "ok": {
      await saveLicence(path, {
        ...licence, limits: result.limits, extraProfiles: result.extraProfiles, extraMonthlyCents: result.extraMonthlyCents,
        renewsAt: result.renewsAt ?? licence.renewsAt, checkedAt: now.toISOString(),
      });
      const renews = formatRenewal(result.renewsAt ?? licence.renewsAt);
      const from = renews ? `from ${renews}` : "from your next bill";
      const have = result.extraProfiles ? `${result.limits.profiles} profiles (${result.extraProfiles} extra)` : `${result.limits.profiles} profiles, no extras`;
      const days = change > 0 ? "the days until then go on that bill, prorated" : "the unused days come off that bill";
      io.out(`Done: ${have}. ${dollars(result.monthlyCents)}/mo ${from}; ${days}.`);
      return 0;
    }
    case "too-few":
      io.err(result.extraProfiles === 0
        ? "You have no extra profiles to remove."
        : `You have ${result.extraProfiles} extra profile${result.extraProfiles === 1 ? "" : "s"}, so you can't remove ${cmd.count}.`);
      return 1;
    case "too-many":
      io.err(`BYO takes up to ${result.max} extra profiles and you have ${result.extraProfiles}. For more, Enterprise: ${PRICING_URL}`);
      return 1;
    case "closed":
      io.err("Adding profiles isn't open yet. Write to efibendor@gmail.com and we'll add them for you.");
      return 1;
    case "inactive": {
      const existing = await loadLicence(path);
      if (existing?.key === licence.key) await forgetLicence(path);
      io.err(inactiveLine(result.status, result.limits));
      return 1;
    }
    case "unknown-key":
      await forgetLicence(path);
      io.err("That key isn't recognised any more. Check the email from Nephew or your welcome page.");
      return 1;
    case "try-later":
      io.err("nephew.ai is busy right now. Try again in a minute.");
      return 1;
    case "unreachable":
      io.err("Couldn't reach nephew.ai to change your profiles. Try again in a minute.");
      return 1;
    case "incompatible":
      io.err(UPDATE_LINE);
      return 1;
  }
}

// ---------------------------------------------------- profiles gate

async function isDir(p: string): Promise<boolean> {
  try { return (await stat(p)).isDirectory(); } catch { return false; }
}

async function exists(p: string): Promise<boolean> {
  try { await stat(p); return true; } catch { return false; }
}

/**
 * How many profile bundles live under these roots: directories that hold
 * a bundle (a manifest.json), never stray files, tombstones, or capture's
 * .staging tree. The same directory named twice counts once.
 */
export async function countProfileBundles(roots: string[]): Promise<number> {
  const seenRoots = new Set<string>();
  let count = 0;
  for (const root of roots) {
    const key = resolve(root);
    if (seenRoots.has(key)) continue;
    seenRoots.add(key);
    let names: string[];
    try {
      names = await readdir(root);
    } catch {
      continue;
    }
    for (const name of names) {
      const dir = join(root, name);
      if (!(await isDir(dir))) continue;
      if (await exists(join(dir, "manifest.json"))) count += 1;
    }
  }
  return count;
}

function displayRoot(profilesRoot: string): string {
  return resolve(profilesRoot) === resolve(defaultProfilesRoot()) ? "~/.nephew/profiles" : profilesRoot;
}

/** The line that refuses a NEW profile at the plan's limit, or null when there is room. */
export function profileLimitProblem(current: CurrentPlan, have: number, profilesRoot: string): string | null {
  if (have < current.limits.profiles) return null;
  const freeOne = `free one up: nephew revoke --bundle ${displayRoot(profilesRoot)}/<profile>`;
  if (current.plan === "free") {
    return `Free includes ${current.limits.profiles} profiles and you have ${have}. BYO has ${BYO_LIMITS.profiles}: ${PRICING_URL}. Or ${freeOne}`;
  }
  const each = dollars(current.extraMonthlyCents ?? DEFAULT_EXTRA_MONTHLY_CENTS);
  return `BYO includes ${current.limits.profiles} profiles and you have ${have}. Add one for ${each}/mo: nephew profiles add. Or ${freeOne}`;
}

// --------------------------------------------------------- run locks

export interface RunLockRecord {
  pid: number;
  startedAt: string;
  bundleDir: string;
  job?: string;
  provider?: string;
}

export interface RunLock {
  path: string;
  record: RunLockRecord;
  /** Remove the lock (idempotent). Also runs on process exit / SIGINT / SIGTERM. */
  release: () => Promise<void>;
}

export interface RunLockDeps {
  env?: NodeJS.ProcessEnv;
  /** Lock directory; default runLocksDir(env). */
  runsDir?: string;
  now?: () => Date;
  pid?: number;
  /** Liveness seam (tests); default: process.kill(pid, 0). */
  isPidAlive?: (pid: number) => boolean;
  /** When this machine booted, epoch ms (tests); default: now − os.uptime(). */
  bootTime?: () => number;
  /** Install the exit/SIGINT/SIGTERM cleanup (default true; tests may turn it off). */
  signals?: boolean;
}

function defaultIsPidAlive(pid: number): boolean {
  try {
    process.kill(pid, 0);
    return true;
  } catch (e) {
    // EPERM: the process exists but is not ours — still alive.
    return (e as NodeJS.ErrnoException).code === "EPERM";
  }
}

/** Write this run's lock. The file is removed by release(), or on exit. */
export async function acquireRunLock(
  details: { bundleDir: string; job?: string; provider?: string },
  deps: RunLockDeps = {},
): Promise<RunLock> {
  const dir = deps.runsDir ?? runLocksDir(deps.env ?? process.env);
  const now = (deps.now ?? (() => new Date()))();
  const pid = deps.pid ?? process.pid;
  const record: RunLockRecord = {
    pid, startedAt: now.toISOString(), bundleDir: details.bundleDir,
    ...(details.job ? { job: details.job } : {}),
    ...(details.provider ? { provider: details.provider } : {}),
  };
  await mkdir(dir, { recursive: true });
  const path = join(dir, `${pid}-${randomBytes(4).toString("hex")}.json`);
  // Written whole: a racing reader sees either the finished lock or no
  // lock (liveRunLocks skips the temp name), never a half-written one.
  const tmp = path + ".tmp";
  await writeFile(tmp, JSON.stringify(record, null, 2) + "\n", { mode: 0o600 });
  await rename(tmp, path);

  let released = false;
  const releaseSync = (): void => {
    if (released) return;
    released = true;
    try { unlinkSync(path); } catch { /* already gone */ }
    if (deps.signals !== false) {
      process.off("exit", releaseSync);
      process.off("SIGINT", onSignal);
      process.off("SIGTERM", onSignal);
    }
  };
  const onSignal = (signal: NodeJS.Signals): void => {
    releaseSync();
    // Our handler replaced Node's default exit for this signal: keep the
    // conventional exit code and let any other listener's exit hooks run.
    process.exit(signal === "SIGINT" ? 130 : 143);
  };
  if (deps.signals !== false) {
    process.once("exit", releaseSync);
    process.on("SIGINT", onSignal);
    process.on("SIGTERM", onSignal);
  }
  return { path, record, release: async () => { releaseSync(); } };
}

function defaultBootTime(): number {
  return Date.now() - uptime() * 1000;
}

/** Sweep a file nobody can use once it is old enough not to be mid-write (best effort). */
async function sweepWhenOld(path: string): Promise<void> {
  let ageMs: number;
  try {
    ageMs = Date.now() - (await stat(path)).mtimeMs;
  } catch {
    return; // already gone
  }
  if (ageMs >= UNREADABLE_GRACE_MS) await unlink(path).catch(() => { /* another run may have cleaned it */ });
}

/**
 * The runs alive right now: every lock whose pid still exists, that is
 * younger than 24 h, and that was started in this boot — a pid reused
 * after a reboot is not that run. Dead locks are removed on the way (best
 * effort). An unreadable lock, or a stray temp file, is swept only once it
 * is a few seconds old: a racing run may still be writing it.
 */
export async function liveRunLocks(deps: RunLockDeps = {}): Promise<Array<RunLockRecord & { path: string }>> {
  const dir = deps.runsDir ?? runLocksDir(deps.env ?? process.env);
  const now = (deps.now ?? (() => new Date()))();
  const isAlive = deps.isPidAlive ?? defaultIsPidAlive;
  const bootTime = (deps.bootTime ?? defaultBootTime)();
  let names: string[];
  try {
    names = await readdir(dir);
  } catch {
    return [];
  }
  const live: Array<RunLockRecord & { path: string }> = [];
  for (const name of names) {
    const path = join(dir, name);
    if (name.endsWith(".json.tmp")) {
      await sweepWhenOld(path);
      continue;
    }
    if (!name.endsWith(".json")) continue;
    let record: Partial<RunLockRecord> | null = null;
    try {
      record = JSON.parse(await readFile(path, "utf8")) as Partial<RunLockRecord> | null;
    } catch {
      record = null;
    }
    const pid = Number(record?.pid);
    const started = record ? Date.parse(String(record.startedAt)) : NaN;
    const readable = record !== null && typeof record === "object" && Number.isInteger(pid) && pid > 0 && Number.isFinite(started);
    if (!readable) {
      await sweepWhenOld(path);
      continue;
    }
    const alive =
      now.getTime() - started < LOCK_STALE_MS &&
      started >= bootTime - BOOT_TOLERANCE_MS &&
      isAlive(pid);
    if (alive) {
      live.push({ pid, startedAt: String(record!.startedAt), bundleDir: String(record!.bundleDir ?? ""), job: record!.job, provider: record!.provider, path });
    } else {
      await unlink(path).catch(() => { /* another run may have cleaned it */ });
    }
  }
  return live;
}

/**
 * This run's place in the queue of live locks sorted by (startedAt, path):
 * 0 is the oldest. Two runs that start in the same instant are told apart
 * by path, so both processes compute the same order and agree on who runs.
 * A lock missing from the list (swept by a racing reader) ranks last.
 */
export function runRank(live: ReadonlyArray<{ startedAt: string; path: string }>, ownPath: string): number {
  const sorted = [...live].sort((a, b) => {
    const ta = Date.parse(a.startedAt);
    const tb = Date.parse(b.startedAt);
    if (Number.isFinite(ta) && Number.isFinite(tb) && ta !== tb) return ta < tb ? -1 : 1;
    return a.path < b.path ? -1 : a.path > b.path ? 1 : 0;
  });
  const own = resolve(ownPath);
  const index = sorted.findIndex((l) => resolve(l.path) === own);
  return index === -1 ? sorted.length : index;
}

/**
 * The line that refuses a run when `liveCount` jobs (this one included)
 * would exceed the plan's runs at a time, or null when it fits.
 */
export function runLimitProblem(current: CurrentPlan, liveCount: number): string | null {
  if (liveCount <= current.limits.runs) return null;
  const running = current.limits.runs === 1 ? "one is running" : `${current.limits.runs} are running`;
  if (current.plan === "free") {
    return `Free runs ${current.limits.runs} job${current.limits.runs === 1 ? "" : "s"} at a time and ${running}. BYO runs ${BYO_LIMITS.runs}: ${PRICING_URL}`;
  }
  return `BYO runs ${current.limits.runs} jobs at a time and ${running}. Wait for one to finish, then try again.`;
}

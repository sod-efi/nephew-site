/**
 * cli/revoke — the owner revoke path behind `nephew revoke`
 * (delight brief §2.3 / §4.3, SECURITY_REVIEW rule 3, MISSION DONE MEANS #2).
 *
 * One command: destroy the owner-held bundle, destroy key material when a
 * key file is explicitly named, and leave a SIGNED deletion receipt next to
 * the (now deleted) bundle directory — <bundleDir>.deletion-receipt.json —
 * plus an optional copy at a caller-chosen path. The receipt lists every
 * copy that existed and when each was destroyed. Identifiers and hashes
 * only: never state, cookie values, or key material (AGENTS.md #3,
 * SECURITY_REVIEW rule 4).
 *
 * Signing identity: a dedicated Ed25519 keypair owned by the owner, kept
 * OUTSIDE the bundle (env NEPHEW_RECEIPT_SIGNING_KEY_FILE, else
 * ~/.nephew/receipt-signing-key.json, mode 0600). It survives the revoke so
 * the receipt stays verifiable afterwards; it can decrypt nothing.
 */
import { createHash, generateKeyPairSync, sign, verify, createPrivateKey, createPublicKey } from "node:crypto";
import { lstat, mkdir, readFile, readdir, stat, unlink, writeFile } from "node:fs/promises";
import { protectPrivatePath, writePrivateFile } from "../private-files.ts";
import { randomBytes } from "node:crypto";
import { dirname, join, relative } from "node:path";
import { revokeBundle } from "../profile-store.ts";
import { fingerprintHash } from "./receipt.ts";

export interface DeletedCopy {
  location: string;
  kind: "owner-held-bundle" | "key-material";
  destroyedAt: string;
  method: string;
}

export interface DeletionReceipt {
  type: "nephew.deletion-receipt";
  version: 1;
  bundleId: string;
  bundleDir: string;
  fingerprint: string | null;
  /** Pre-deletion inventory of the bundle directory: path, size, sha256 of contents (ciphertext for state.enc). */
  inventory: { path: string; bytes: number; sha256: string }[];
  copies: DeletedCopy[];
  /** What the bundle's encryption key was, by reference — never the value. */
  encryptionKey: {
    reference: string;
    keyFileDestroyed: boolean;
    /** sha256 of the key bytes, recorded only when a key file was destroyed — a commitment, not the key. */
    keyFileSha256: string | null;
  };
  providerSessions: string;
  revokedAt: string;
}

export interface SignedDeletionReceipt {
  receipt: DeletionReceipt;
  /** Ed25519 public key (SPKI, base64) the signature verifies against. */
  signingPublicKey: string;
  /** Ed25519 signature over the canonical receipt JSON (base64). */
  signature: string;
}

export interface ReceiptSigningKey {
  privateKeyPkcs8: string; // base64
  publicKeySpki: string; // base64
  createdAt: string;
}

/** Canonical form: the receipt's fields in a fixed construction order. */
export function canonicalReceiptJson(receipt: DeletionReceipt): string {
  return JSON.stringify({
    type: receipt.type,
    version: receipt.version,
    bundleId: receipt.bundleId,
    bundleDir: receipt.bundleDir,
    fingerprint: receipt.fingerprint,
    inventory: receipt.inventory,
    copies: receipt.copies,
    encryptionKey: receipt.encryptionKey,
    providerSessions: receipt.providerSessions,
    revokedAt: receipt.revokedAt,
  });
}

async function exists(p: string): Promise<boolean> {
  try { await stat(p); return true; } catch { return false; }
}

/** Load the owner's receipt-signing keypair, creating it (0600) on first use. */
export async function loadOrCreateReceiptSigningKey(keyFile: string): Promise<ReceiptSigningKey> {
  let raw: string;
  try {
    await protectPrivatePath(keyFile);
    raw = await readFile(keyFile, "utf8");
  } catch (e) {
    // Only a missing file gets a fresh keypair. An unreadable or damaged one
    // is the owner's problem to look at, never silently replaced (every
    // receipt signed so far verifies against the old key).
    if ((e as NodeJS.ErrnoException).code !== "ENOENT") throw e;
    const { privateKey, publicKey } = generateKeyPairSync("ed25519");
    const key: ReceiptSigningKey = {
      privateKeyPkcs8: privateKey.export({ type: "pkcs8", format: "der" }).toString("base64"),
      publicKeySpki: publicKey.export({ type: "spki", format: "der" }).toString("base64"),
      createdAt: new Date().toISOString(),
    };
    await writePrivateFile(keyFile, JSON.stringify(key, null, 2));
    return key;
  }
  const key = JSON.parse(raw) as ReceiptSigningKey;
  if (typeof key?.privateKeyPkcs8 !== "string" || typeof key?.publicKeySpki !== "string") {
    throw new Error(`${keyFile} is not a receipt-signing key file — move it aside to have a new key made`);
  }
  return key;
}

export function signDeletionReceipt(receipt: DeletionReceipt, key: ReceiptSigningKey): SignedDeletionReceipt {
  const priv = createPrivateKey({ key: Buffer.from(key.privateKeyPkcs8, "base64"), format: "der", type: "pkcs8" });
  const signature = sign(null, Buffer.from(canonicalReceiptJson(receipt), "utf8"), priv);
  return { receipt, signingPublicKey: key.publicKeySpki, signature: signature.toString("base64") };
}

/** Verify a signed receipt against the public key embedded in it. */
export function verifyDeletionReceipt(signed: SignedDeletionReceipt): boolean {
  try {
    const pub = createPublicKey({ key: Buffer.from(signed.signingPublicKey, "base64"), format: "der", type: "spki" });
    return verify(null, Buffer.from(canonicalReceiptJson(signed.receipt), "utf8"), pub, Buffer.from(signed.signature, "base64"));
  } catch {
    return false;
  }
}

async function inventoryDir(dir: string, base = dir): Promise<{ path: string; bytes: number; sha256: string }[]> {
  const out: { path: string; bytes: number; sha256: string }[] = [];
  for (const name of (await readdir(dir)).sort()) {
    const p = join(dir, name);
    const st = await lstat(p);
    if (st.isSymbolicLink() || (!st.isDirectory() && (!st.isFile() || st.nlink > 1))) {
      throw new Error('refusing to revoke a bundle containing linked or special files');
    }
    if (st.isDirectory()) {
      out.push(...await inventoryDir(p, base));
    } else {
      const body = await readFile(p);
      out.push({ path: relative(base, p), bytes: body.length, sha256: createHash("sha256").update(body).digest("hex") });
    }
  }
  return out;
}

/** Destroy a key file: overwrite with random bytes, then unlink. Returns its sha256 commitment. */
async function destroyKeyFile(keyFile: string): Promise<string> {
  const body = await readFile(keyFile);
  const sha = createHash("sha256").update(body).digest("hex");
  await writeFile(keyFile, randomBytes(body.length));
  await unlink(keyFile);
  return sha;
}

export interface RevokeOptions {
  bundleDir: string;
  signingKeyFile: string;
  /** Explicit key-material file to destroy with the bundle (never a default — the owner names it). */
  keyFile?: string;
  /** Extra copy of the signed receipt to write, beyond the canonical sibling path. */
  receiptCopyPath?: string;
}

export interface RevokeResult {
  signed: SignedDeletionReceipt;
  /** Canonical receipt location: <bundleDir>.deletion-receipt.json (survives the deletion). */
  receiptPath: string;
}

/**
 * Revoke one bundle end-to-end: inventory → destroy bundle (profile-store)
 * → destroy named key material → sign + persist the deletion receipt.
 * Refuses when there is nothing to revoke or the bundle was already revoked.
 */
export async function revokeWithReceipt(opts: RevokeOptions): Promise<RevokeResult> {
  const { bundleDir } = opts;
  if ((await lstat(bundleDir).catch(() => null))?.isSymbolicLink()) throw new Error('refusing to revoke a linked bundle directory');
  if (opts.keyFile) {
    const st = await lstat(opts.keyFile);
    if (!st.isFile() || st.nlink > 1) throw new Error('refusing to overwrite linked key material');
  }
  if (await exists(bundleDir + ".revoked.json")) {
    throw new Error(`bundle at ${bundleDir} was already revoked`);
  }
  if (!(await exists(bundleDir))) {
    throw new Error(`no bundle found at ${bundleDir} — nothing to revoke`);
  }
  // Only a bundle is destroyed: a directory without the sealed state and
  // its manifest is somebody's folder (a typo'd --bundle, a stray
  // NEPHEW_BUNDLE_DIR), not a profile.
  if (!(await exists(join(bundleDir, "state.enc"))) || !(await exists(join(bundleDir, "manifest.json")))) {
    throw new Error(`${bundleDir} is not a profile bundle (no state.enc + manifest.json) — nothing was deleted`);
  }

  // Inventory + identity BEFORE anything is destroyed.
  let bundleId = "unknown";
  let fingerprint: string | null = null;
  try {
    const manifest = JSON.parse(await readFile(join(bundleDir, "manifest.json"), "utf8"));
    bundleId = String(manifest.id ?? "unknown");
    const fp = JSON.parse(await readFile(join(bundleDir, "fingerprint.json"), "utf8"));
    fingerprint = fingerprintHash({
      manifest, fingerprint: fp, network: {}, encryptedState: "",
    } as Parameters<typeof fingerprintHash>[0]);
  } catch { /* identity fields stay best-effort; destruction proceeds */ }
  const inventory = await inventoryDir(bundleDir);

  const copies: DeletedCopy[] = [];
  await revokeBundle(bundleDir);
  copies.push({
    location: bundleDir,
    kind: "owner-held-bundle",
    destroyedAt: new Date().toISOString(),
    method: "state.enc overwritten with random bytes, bundle directory recursively deleted (profile-store.revokeBundle)",
  });

  let keyFileSha256: string | null = null;
  if (opts.keyFile) {
    keyFileSha256 = await destroyKeyFile(opts.keyFile);
    copies.push({
      location: opts.keyFile,
      kind: "key-material",
      destroyedAt: new Date().toISOString(),
      method: "overwritten with random bytes, then unlinked",
    });
  }

  const receipt: DeletionReceipt = {
    type: "nephew.deletion-receipt",
    version: 1,
    bundleId,
    bundleDir,
    fingerprint,
    inventory,
    copies,
    encryptionKey: {
      reference: opts.keyFile
        ? "per-profile key file named on the revoke command"
        : "PROFILE_ENCRYPTION_KEY (environment / owner vault) — never stored in the bundle",
      keyFileDestroyed: Boolean(opts.keyFile),
      keyFileSha256,
    },
    providerSessions:
      "none registered — CLI v0 keeps no provider session registry and never uses provider-native profiles; any live session from an earlier run is closed by that run's own teardown",
    revokedAt: new Date().toISOString(),
  };

  const key = await loadOrCreateReceiptSigningKey(opts.signingKeyFile);
  const signed = signDeletionReceipt(receipt, key);
  const receiptPath = bundleDir + ".deletion-receipt.json";
  await writeFile(receiptPath, JSON.stringify(signed, null, 2));
  if (opts.receiptCopyPath) {
    await mkdir(dirname(opts.receiptCopyPath), { recursive: true });
    await writeFile(opts.receiptCopyPath, JSON.stringify(signed, null, 2));
  }
  return { signed, receiptPath };
}

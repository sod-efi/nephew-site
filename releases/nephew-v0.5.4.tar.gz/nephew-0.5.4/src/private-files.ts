/** Sensitive local files: POSIX modes or a verified Windows DACL, before data is written. */
import { execFile } from "node:child_process";
import { constants } from "node:fs";
import { chmod, lstat, mkdir, open } from "node:fs/promises";
import { dirname, join } from "node:path";
import { promisify } from "node:util";

const exec = promisify(execFile);
// Fixed script; the path is passed as data, never interpolated into PowerShell.
const ACL_SCRIPT = `
$ErrorActionPreference = 'Stop'
$ProgressPreference = 'SilentlyContinue'
$p = $env:NEPHEW_ACL_TARGET
$item = Get-Item -LiteralPath $p -Force
if ($item.Attributes -band [IO.FileAttributes]::ReparsePoint) { throw 'Linked path refused' }
$sid = [Security.Principal.WindowsIdentity]::GetCurrent().User
$acl = Get-Acl -LiteralPath $p
if ($acl.GetOwner([Security.Principal.SecurityIdentifier]) -ne $sid) { throw 'Private storage must be owned by the current user' }
$acl.SetAccessRuleProtection($true, $false)
foreach ($oldRule in @($acl.GetAccessRules($true, $true, [Security.Principal.SecurityIdentifier]))) { $acl.RemoveAccessRuleSpecific($oldRule) }
$inherit = if ($item.PSIsContainer) { [Security.AccessControl.InheritanceFlags]'ContainerInherit,ObjectInherit' } else { [Security.AccessControl.InheritanceFlags]::None }
$rule = New-Object Security.AccessControl.FileSystemAccessRule($sid, 'FullControl', $inherit, 'None', 'Allow')
$acl.AddAccessRule($rule)
if ($item.PSIsContainer) { [IO.Directory]::SetAccessControl($p, $acl) } else { [IO.File]::SetAccessControl($p, $acl) }
$check = Get-Acl -LiteralPath $p
$rules = @($check.GetAccessRules($true, $true, [Security.Principal.SecurityIdentifier]))
if (!$check.AreAccessRulesProtected -or $rules.Count -ne 1 -or $rules[0].IdentityReference -ne $sid -or $rules[0].AccessControlType -ne 'Allow' -or $rules[0].FileSystemRights -ne 'FullControl') { throw 'Private ACL verification failed' }
`;

export async function protectPrivatePath(path: string): Promise<void> {
  const info = await lstat(path);
  if (info.isSymbolicLink() || (!info.isDirectory() && (!info.isFile() || info.nlink !== 1))) {
    throw new Error("private storage requires an unlinked regular file or directory");
  }
  if (process.platform !== "win32") {
    await chmod(path, info.isDirectory() ? 0o700 : 0o600);
    return;
  }
  try {
    await exec(join(process.env.SystemRoot ?? "C:\\Windows", "System32", "WindowsPowerShell", "v1.0", "powershell.exe"),
      ["-NoLogo", "-NoProfile", "-NonInteractive", "-EncodedCommand", Buffer.from(ACL_SCRIPT, "utf16le").toString("base64")],
      { windowsHide: true, timeout: 20_000, env: { SystemRoot: process.env.SystemRoot, NEPHEW_ACL_TARGET: path } });
  } catch {
    throw new Error("Cannot establish owner-only Windows permissions; sensitive data was not written. Use a local NTFS directory with ACL support.");
  }
}

export async function privateDirectory(path: string): Promise<void> {
  await mkdir(path, { recursive: true, mode: 0o700 });
  await protectPrivatePath(path);
}

export async function writePrivateFile(path: string, data: string): Promise<void> {
  await mkdir(dirname(path), { recursive: true, mode: 0o700 });
  const existing = await lstat(path).catch((e: NodeJS.ErrnoException) => { if (e.code === "ENOENT") return null; throw e; });
  if (existing && (!existing.isFile() || existing.nlink !== 1)) throw new Error("private storage requires an unlinked regular file");
  // Open without truncation, then reject hardlinks and protect before writing.
  const file = await open(path, constants.O_WRONLY | constants.O_CREAT | (constants.O_NOFOLLOW ?? 0), 0o600);
  try {
    const info = await file.stat();
    if (!info.isFile() || info.nlink !== 1) throw new Error("private storage requires an unlinked regular file");
    await protectPrivatePath(path);
    await file.truncate(0);
    await file.writeFile(data, "utf8");
  } finally { await file.close(); }
}

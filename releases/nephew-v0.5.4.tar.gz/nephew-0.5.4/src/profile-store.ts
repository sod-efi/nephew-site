/**
 * profile-store — the owner-held bundle. The only component allowed to touch
 * plaintext profile data. See docs/SECURITY_REVIEW.md before changing anything.
 *
 * Bundle layout (ARCHITECTURE.md):
 *   profile/          Layer 1 stored state (cookies, localStorage, IndexedDB subset)
 *   fingerprint.json  Layer 2 recipe: seed + explicit config
 *   network.json      Layer 3 pinned proxy assignment (reference, not credentials)
 *   manifest.json     versions, checksums, revoke state
 */
import { createCipheriv, createDecipheriv, randomBytes } from "node:crypto";
import { chmod, lstat, mkdir, readFile, writeFile, rm, stat } from "node:fs/promises";
import { join } from "node:path";
import { privateDirectory, protectPrivatePath, writePrivateFile } from "./private-files.ts";

export interface FingerprintConfig {
  /** Seed for patched-Chromium builds (--fingerprint=<seed>). Stable per profile. */
  seed: number;
  userAgent?: string;
  /** --fingerprint-platform value: windows | linux | macos. */
  platform?: string;
  /** --fingerprint-brand value: Chrome | Edge | Opera | Vivaldi. */
  brand?: string;
  timezone?: string;
  locale?: string;
  viewport?: { width: number; height: number; deviceScaleFactor?: number };
  webglVendor?: string;
  webglRenderer?: string;
}

export interface ProfileBundle {
  manifest: {
    id: string;
    createdAt: string;
    updatedAt: string;
    revoked: boolean;
    /**
     * The designated human for this profile (product design, delight brief
     * §3): the one person a paused run routes its LOGIN_REQUIRED handoff to —
     * whoever receives this account's codes today. A name or handle the owner
     * chose at capture time; never a credential. Optional only so bundles
     * captured before the field existed still load.
     */
    designatedHuman?: string;
  };
  fingerprint: FingerprintConfig;
  network: { proxyRef: string; proxyUrl?: string; country?: string };
  /** Encrypted Layer-1 state payload (storageState JSON), never plaintext on disk. */
  encryptedState: string;
}

const ALGO = "aes-256-gcm";
const TAG_BYTES = 16;
/** Prefix of a state payload bound to its bundle's metadata (see sealAad). */
const BOUND_PREFIX = "v2.";

function keyFromEnv(): Buffer {
  const raw = process.env.PROFILE_ENCRYPTION_KEY;
  if (!raw) throw new Error("PROFILE_ENCRYPTION_KEY is not set — a 32-byte key, base64 (openssl rand -base64 32)");
  const key = Buffer.from(raw, "base64");
  if (key.length !== 32) {
    throw new Error(`PROFILE_ENCRYPTION_KEY must be 32 bytes, base64 (it decodes to ${key.length}) — openssl rand -base64 32`);
  }
  return key;
}

/**
 * The metadata a sealed state is bound to: the bundle id, the fingerprint
 * recipe and the network pin. Only state.enc is encrypted; binding these
 * as GCM additional data means an edit to fingerprint.json or network.json
 * (say, a swapped proxyUrl pointing the run's cookies and proxy
 * credentials at a stranger's proxy) fails decryption instead of taking
 * effect. Pure, order-stable: the files are written and read back by JSON
 * round-trips, which keep key order.
 */
export function sealAad(bundle: Pick<ProfileBundle, "manifest" | "fingerprint" | "network">): string {
  return JSON.stringify({ id: bundle.manifest.id, fingerprint: bundle.fingerprint, network: bundle.network });
}

/** Seal plaintext state. With `aad` (sealAad of its bundle) the payload is bound to that metadata. */
export function encryptState(plaintext: string, aad?: string): string {
  const iv = randomBytes(12);
  const cipher = createCipheriv(ALGO, keyFromEnv(), iv, { authTagLength: TAG_BYTES });
  if (aad !== undefined) cipher.setAAD(Buffer.from(aad, "utf8"));
  const body = Buffer.concat([cipher.update(plaintext, "utf8"), cipher.final()]);
  const parts = [iv.toString("base64"), cipher.getAuthTag().toString("base64"), body.toString("base64")].join(".");
  return aad !== undefined ? BOUND_PREFIX + parts : parts;
}

/**
 * Open a sealed state. A bound payload (v2.) needs the same `aad` it was
 * sealed with. Legacy payloads can be opened only through the low-level
 * no-metadata API for offline recovery; every runtime restoration supplies
 * metadata and refuses them. Recapture instead of trusting old metadata.
 */
export function decryptState(payload: string, aad?: string): string {
  const bound = payload.startsWith(BOUND_PREFIX);
  if (!bound && aad !== undefined) {
    throw new Error("Legacy profile metadata is not authenticated. Capture a new profile with this release before running it; the original bundle is unchanged.");
  }
  const parts = (bound ? payload.slice(BOUND_PREFIX.length) : payload).split(".");
  if (parts.length !== 3) throw new Error("state.enc is not a sealed state payload");
  const [iv, tag, body] = parts.map((s) => Buffer.from(s, "base64"));
  if (tag.length !== TAG_BYTES) throw new Error("state.enc has a damaged authentication tag");
  const decipher = createDecipheriv(ALGO, keyFromEnv(), iv, { authTagLength: TAG_BYTES });
  if (bound) {
    if (aad === undefined) throw new Error("this state is bound to its bundle metadata; open it through the bundle");
    decipher.setAAD(Buffer.from(aad, "utf8"));
  }
  decipher.setAuthTag(tag);
  try {
    return Buffer.concat([decipher.update(body), decipher.final()]).toString("utf8");
  } catch {
    throw new Error(bound
      ? "state.enc does not open: the key is wrong, or manifest.json / fingerprint.json / network.json were changed since the bundle was sealed"
      : "state.enc does not open: the key is wrong or the file was changed");
  }
}

async function exists(p: string): Promise<boolean> {
  try { await stat(p); return true; } catch { return false; }
}

/** Owner-only on disk: the directory 0700, every file 0600 (a bundle is a credential vault). */
export async function saveBundle(bundle: ProfileBundle, dir: string): Promise<void> {
  if (bundle.manifest.revoked) throw new Error("refusing to save a revoked bundle");
  await mkdir(dir, { recursive: true, mode: 0o700 });
  if ((await lstat(dir)).isSymbolicLink()) throw new Error('profile bundle directory must not be a symbolic link');
  for (const name of ['manifest.json', 'fingerprint.json', 'network.json', 'state.enc']) {
    const info = await lstat(join(dir, name)).catch((e) => { if (e.code === 'ENOENT') return null; throw e; });
    if (info && (!info.isFile() || info.nlink > 1)) throw new Error('profile bundle files must be regular, unshared files');
  }
  await privateDirectory(dir);
  const put = async (name: string, body: string) => {
    await writePrivateFile(join(dir, name), body);
  };
  await put("manifest.json", JSON.stringify(bundle.manifest, null, 2));
  await put("fingerprint.json", JSON.stringify(bundle.fingerprint, null, 2));
  await put("network.json", JSON.stringify(bundle.network, null, 2));
  await put("state.enc", bundle.encryptedState);
}

export async function loadBundle(dir: string): Promise<ProfileBundle> {
  if (await exists(dir + ".revoked.json")) {
    throw new Error(`bundle at ${dir} was revoked and destroyed`);
  }
  await protectPrivatePath(dir);
  for (const name of ["manifest.json", "fingerprint.json", "network.json", "state.enc"]) {
    await protectPrivatePath(join(dir, name));
  }
  const manifest = JSON.parse(await readFile(join(dir, "manifest.json"), "utf8"));
  if (manifest.revoked) throw new Error(`bundle ${manifest.id} is marked revoked`);
  const fingerprint = JSON.parse(await readFile(join(dir, "fingerprint.json"), "utf8"));
  const network = JSON.parse(await readFile(join(dir, "network.json"), "utf8"));
  const encryptedState = await readFile(join(dir, "state.enc"), "utf8");
  return { manifest, fingerprint, network, encryptedState };
}

export async function revokeBundle(dir: string): Promise<void> {
  // Destroy, don't flag: overwrite the encrypted state, remove the bundle
  // directory, and leave only a tombstone so a later load fails loudly.
  const statePath = join(dir, "state.enc");
  const directory = await lstat(dir);
  if (!directory.isDirectory() || directory.isSymbolicLink()) throw new Error('refusing to revoke a linked bundle directory');
  if (await exists(statePath)) {
    const info = await lstat(statePath);
    if (!info.isFile() || info.nlink > 1) throw new Error('refusing to overwrite linked profile state');
    // The whole file, not a short prefix (which would truncate and leave the
    // original blocks on disk). Best-effort by nature: an SSD may remap.
    const size = (await stat(statePath)).size;
    await writeFile(statePath, randomBytes(Math.max(size, 256)));
  }
  await rm(dir, { recursive: true, force: true });
  await writeFile(
    dir + ".revoked.json",
    JSON.stringify({ revokedAt: new Date().toISOString(), note: "bundle destroyed by owner revoke" }, null, 2),
  );
}
